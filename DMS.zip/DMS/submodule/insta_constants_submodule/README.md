
#  insta constants submodule

## Overview
This microservice is used as a common submodule for all the other microservice. It contains commonly used constants files by all micro
such as product, system configs, stage-page status-code, error-code, error messages and logger files

### Running the server

There is no pipeline present for this micro. Any changes present has to be added and pushed 

In the parents microservice changes in the submodules can be reflected using below command

sh ../checkout/checkout development