module.exports = {
    POOL_CONFIG: {
      TOO_LOW: { MAX: 30, MIN: 1 },
      LOW: { MAX: 50, MIN: 5 },
      MEDIUM: { MAX: 75, MIN: 10 },
      HIGH: { MAX: 100, MIN: 20 },
    },
    ACQUIRE:60000,
    IDLE:10000
  };