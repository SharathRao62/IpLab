const Logger = require('../insta_util_submodule/utils/logger');

const logger = new Logger();

const constant = require('../insta_main_submodule/constants');

const { writeEnv } = require('../insta_config_submodule/config/igniter.js')
const { writeEnvdb } = require('../insta_config_submodule/config/igniter.js')

const environment = process.env.NODE_ENV || 'development';
const isTig =  process.env.TIG || false
let ciphertextConfigFile = 'submodule/insta_config_submodule/config/config.dev.js.encrypted';
let ciphertextFile = 'submodule/insta_config_submodule/config/environConfig.dev.js.encrypted';
let project = constant.PROJECT_ID;
logger.debug(`ENVIRONMENT | ${JSON.stringify(environment)}`);
logger.info(`isTig main | ${JSON.stringify(isTig)}`);

switch (environment) {
  case 'development':
    break;
  case 'qa':
    ciphertextConfigFile = 'submodule/insta_config_submodule/config/config.qa.js.encrypted';
    ciphertextFile = 'submodule/insta_config_submodule/config/environConfig.qa.js.encrypted';
    break;
  case 'staging':
    ciphertextConfigFile = 'submodule/insta_config_submodule/config/config.staging.js.encrypted';
    ciphertextFile = 'submodule/insta_config_submodule/config/environConfig.staging.js.encrypted';
    break;
  default:
    ciphertextConfigFile = 'submodule/insta_config_submodule/config/config.production.js.encrypted';
    ciphertextFile = 'submodule/insta_config_submodule/config/environConfig.production.js.encrypted';
    break;
}
// [START kms_decrypt]

logger.debug(`ENVIRONMENT 2 ::| ${JSON.stringify(environment)} PROJECT ID | ${JSON.stringify(project)}`);

async function callKMS() {

  if (isTig == false || isTig == 'false') {
    await decrypt(project, constant.KEY_RING_ID, constant.CRYPTO_KEY_ID, 'submodule/insta_config_submodule/config/configfile.js', ciphertextConfigFile);
    await decrypt(project, constant.KEY_RING_ID, constant.CRYPTO_KEY_ID, 'submodule/insta_config_submodule/config/environConfig.js', ciphertextFile);
  }
  else{
    logger.info('Line 44', isTig);
    await writeEnv(false);
    await writeEnvdb(true);
    logger.info('Line 52', isTig);
  }
  require('../../index.js');

}

async function decrypt(
  projectId,
  keyRingId,
  cryptoKeyId,
  plaintextFileName,
  ciphertextFileName,
) {
  const fs = require('fs');
  const { promisify } = require('util');

  // Import the library and create a client
  const kms = require('@google-cloud/kms');
  const client = new kms.KeyManagementServiceClient();

  // The location of the crypto key's key ring, e.g. "global"
  let locationId = constant.LOCATION_ID; //116515

  // Reads the file to be decrypted
  const readFile = promisify(fs.readFile);
  const ciphertext = await readFile(ciphertextFileName);
  const name = client.cryptoKeyPath(
    projectId,
    locationId,
    keyRingId,
    cryptoKeyId,
  );

  // Decrypts the file using the specified crypto key
  const [result] = await client.decrypt({ name, ciphertext });

  // Writes the decrypted file to disk
  const writeFile = promisify(fs.writeFile);
  await writeFile(plaintextFileName, result.plaintext);
}
// [END kms_decrypt]

const args = process.argv.slice(2);
callKMS();
