# insta main submodule

## Overview
This microservice is used as a common submodule for all the other microservice. It contains main.js which is used to build the docker and for kms decryption of config and environment config file. 

Running node main.js will decrypt the config file and store it in /insta_config_submodule/config folder

### Running the server

There is no pipeline present for this micro. Any changes present has to be added and pushed 

In the parents microservice changes in the submodules can be reflected using below command

sh ../checkout/checkout development