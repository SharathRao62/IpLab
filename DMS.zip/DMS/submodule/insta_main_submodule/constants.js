
const environConfig = {
  development: {
    CRYPTO_KEY_ID: 'icici_bank_key',
    LOCATION_ID: 'global',
    KEY_RING_ID: 'account_opening',
    PROJECT_ID: 'tsg1-reactjs-uat',
    CONFIG_CIPHER_TEXT_FILE_NAME: '../../insta_config_submodule/config/config.dev.js.encrypted',
    CONFIG_PLAIN_TEXT_FILE_NAME: '../../insta_config_submodule/config/configfile.js',
    ENVIRONMENT_CONFIG_CIPHER_TEXT_FILE_NAME: '../insta_config_submodule/config/environConfig.dev.js.encrypted',
  },
  qa: {
    CRYPTO_KEY_ID: 'icici_bank_key',
    LOCATION_ID: 'global',
    KEY_RING_ID: 'account_opening',
    PROJECT_ID: 'tsg1-reactjs-uat',
    CONFIG_CIPHER_TEXT_FILE_NAME: '../../insta_config_submodule/config/config.qa.js.encrypted',
    CONFIG_PLAIN_TEXT_FILE_NAME: '../../insta_config_submodule/config/configfile.js',
    ENVIRONMENT_CONFIG_CIPHER_TEXT_FILE_NAME: '../insta_config_submodule/config/environConfig.qa.js.encrypted',

  },
  staging: {
    CRYPTO_KEY_ID: 'icici_bank_key',
    LOCATION_ID: 'global',
    KEY_RING_ID: 'account_opening',
    PROJECT_ID: 'buyicicibank-prod-263310',
    CONFIG_CIPHER_TEXT_FILE_NAME: '../../insta_config_submodule/config/config.staging.js.encrypted',
    CONFIG_PLAIN_TEXT_FILE_NAME: '../../insta_config_submodule/config/configfile.js',
    ENVIRONMENT_CONFIG_CIPHER_TEXT_FILE_NAME: '../insta_config_submodule/config/environConfig.staging.js.encrypted',

  },
  pre_prod: {
    CRYPTO_KEY_ID: 'icici_bank_key',
    LOCATION_ID: 'global',
    KEY_RING_ID: 'account_opening',
    PROJECT_ID: 'pwa-tsg1-4',
    CONFIG_CIPHER_TEXT_FILE_NAME: '../../insta_config_submodule/config/config.production.js.encrypted',
    CONFIG_PLAIN_TEXT_FILE_NAME: '../../insta_config_submodule/config/configfile.js',
    ENVIRONMENT_CONFIG_CIPHER_TEXT_FILE_NAME: '../insta_config_submodule/config/environConfig.production.js.encrypted',
  },
  production: {
    CRYPTO_KEY_ID: 'icici_bank_key',
    LOCATION_ID: 'global',
    KEY_RING_ID: 'account_opening',
    PROJECT_ID: 'pwa-tsg1-4',
    CONFIG_CIPHER_TEXT_FILE_NAME: '../../insta_config_submodule/config/config.production.js.encrypted',
    CONFIG_PLAIN_TEXT_FILE_NAME: '../../insta_config_submodule/config/configfile.js',
    ENVIRONMENT_CONFIG_CIPHER_TEXT_FILE_NAME: '../insta_config_submodule/config/environConfig.production.js.encrypted',
  },
};


const environment = process.env.NODE_ENV || 'development';
const config = environConfig[environment];

module.exports = config;
