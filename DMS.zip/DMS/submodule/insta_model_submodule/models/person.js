/* eslint-disable no-restricted-syntax */
/* eslint-disable no-await-in-loop */
/* eslint-disable func-names */
/* eslint-disable no-param-reassign */
const Sequelize = require('sequelize');
const { encrypt256, decrypt256 } = require('../../insta_util_submodule/utils/encryptDecryptAES256');

module.exports = function (sequelize, DataTypes) {
  const person = sequelize.define('person', {
    person_id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      comment: 'Primary Key. Unique key to identify a person.',
    },
    lead_id: {
      type: DataTypes.STRING(32),
      allowNull: false,
      comment: 'lead id of the user',
    },
    display_name: {
      type: DataTypes.STRING(256),
      allowNull: true,
      comment: 'Display name of the person',
    },
    first_name: {
      type: DataTypes.STRING(256),
      allowNull: true,
      comment: 'First name of the person',
    },
    middle_name: {
      type: DataTypes.STRING(256),
      allowNull: true,
      comment: 'Middle name of the person',
    },
    last_name: {
      type: DataTypes.STRING(256),
      allowNull: true,
      comment: 'Last name of the person',
    },
    gender: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Gender ID FK to master_genders table',
    },
    age: {
      type: DataTypes.STRING(32),
      allowNull: true,
      comment: 'Age of the person',
    },
    dob: {
      type: DataTypes.STRING(32),
      allowNull: true,
      comment: 'Date of birth of the person',
    },
    have_indian_address: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      comment: 'Flag to indicate if person has Indian Address. If user have indian address then 1 or else 0',
    },
    marital_status_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Marital Status ID of the person. FK to master_marital_statuses',
    },
    name_on_debit_card: {
      type: DataTypes.STRING(256),
      allowNull: true,
      comment: 'Name of the person on the debit card',
    },
    // resident_type_id: {
    //   type: DataTypes.INTEGER,
    //   allowNull: true,
    //   // references: {
    //   //   model: 'master_resident_type',
    //   //   key: 'id',
    //   // },
    // },
    religion_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'master_religions',
        key: 'id',
      },
    },
    caste_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    existing_bay_user_id: {
      type: DataTypes.STRING(128),
      allowNull: true,
      comment: 'old bay user id of the user', // 172704
    },
    new_bay_user_id: {
      type: DataTypes.STRING(128),
      allowNull: true,
      comment: 'new bay user id of the user', // 172704
    },
    experian_score: {
      type: DataTypes.STRING(32),
      allowNull: true,
      comment: 'experian score form name of the user',
    },
    experian_income: {
      type: DataTypes.STRING(32),
      allowNull: true,
      comment: 'experian income form name of the user',
    },
    cibil_score: {
      type: DataTypes.STRING(64),
      allowNull: true,
      comment: 'cibil score from bureau',
    },
    title: {
      type: DataTypes.STRING(32),
      allowNull: true,
    },
    source: {
      type: DataTypes.STRING(128),
      allowNull: true,
    },
    edu_person_disability: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    place_birth: {
      type: DataTypes.STRING(128),
      allowNull: true,
    },
    country_of_citizenship: {
      type: DataTypes.STRING(128),
      allowNull: true,
    },
    // isArchiveReady: {
    //   type: DataTypes.BOOLEAN,
    //   allowNull: false,
    //   defaultValue: 0,
    // },
    rent_amount: {
      type: DataTypes.STRING(128),
      allowNull: true,
    },
    kyc_flag: {
      type: DataTypes.STRING(64),
      allowNull: true,
    },
    resident_type_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    createdTime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    createdDate: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    updatedTime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    updateDate: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    migrationFlag: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: 0,
    },
    migratedDate: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    migratedTime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'person',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
    timestamps: true,
    indexes: [
      {
        name: 'PRIMARY',
        unique: true,
        using: 'BTREE',
        fields: [
          { name: 'person_id' },
        ],
      },
      {
        name: 'person_id',
        using: 'BTREE',
        fields: [
          { name: 'person_id' },
        ],
      },
      {
        name: 'lead_id',
        using: 'BTREE',
        fields: [
          { name: 'lead_id' },
        ],
      },
      // {
      //   name: 'isArchiveReady',
      //   using: 'BTREE',
      //   fields: [
      //     { name: 'isArchiveReady' },
      //   ],
      // },
      {
        name: 'migratedDate',
        using: 'BTREE',
        fields: [
          { name: 'migratedDate' },
        ],
      },
      {
        name: 'marital_status11',
        using: 'BTREE',
        fields: [
          { name: 'marital_status_id' },
        ],
      },
      // {
      //   name: 'religion_id',
      //   using: 'BTREE',
      //   fields: [
      //     { name: 'religion_id' },
      //   ],
      // },
      {
        name: 'gender',
        using: 'BTREE',
        fields: [
          { name: 'gender' },
        ],
      },
      // {
      //   name: 'resident_type_id8',
      //   using: 'BTREE',
      //   fields: [
      //     { name: 'resident_type_id' },
      //   ],
      // },
      {
        name: 'gender',
        using: 'BTREE',
        fields: [
          { name: 'gender' },
        ],
      },
      {
        name: 'createdDate',
        using: 'BTREE',
        fields: [
          { name: 'createdDate' },
        ],
      },
      {
        name: 'updateDate',
        using: 'BTREE',
        fields: [
          { name: 'updateDate' },
        ],
      },
    ],
  });


  person.beforeBulkCreate(async (personList) => {
    const columns = ['display_name','first_name','middle_name','last_name', 'dob', 'age', 'title', 'name_on_debit_card', 'place_birth', 'kyc_flag'];
    await Promise.all(personList.map(async (data) => {
      await Promise.all(columns.map(async (key) => {
        if (columns.includes(key) && data[key]) {
          data[key] = (await encrypt256(data[key].toString())).encryptedData;
        }
        return true;
      }));
    }));
  });

  person.beforeUpdate(async (personDetail) => {
    const columns = ['display_name','first_name','middle_name','last_name', 'dob', 'age', 'title', 'name_on_debit_card', 'experian_score', 'experian_income', 'cibil_score', 'source', 'place_birth', 'existing_bay_user_id', 'kyc_flag'];

    await Promise.all(columns.map(async (key) => {
      if (columns.includes(key) && personDetail.changed(key) && personDetail[key] && key != 'source') {
        personDetail[key] = (await encrypt256(personDetail[key].toString())).encryptedData;
      }
      return true;
    }));
  });

  person.beforeBulkUpdate(async (personDetail) => {
    if (personDetail && personDetail.attributes.country_of_citizenship) {
      const mobPersonal = await encrypt256(personDetail.attributes.country_of_citizenship);
      personDetail.attributes.country_of_citizenship = mobPersonal.encryptedData;
    }
  });

  // person.beforeBulkUpdate(async (personDetail) => {
  //   if (personDetail && personDetail.attributes.age) {
  //     const mobPersonal = await encrypt256(personDetail.attributes.age);
  //     personDetail.attributes.age = mobPersonal.encryptedData;
  //   }
  // });

  // person.beforeBulkUpdate(async (personDetail) => {
  //   if (personDetail && personDetail.attributes.place_birth) {
  //     const mobPersonal = await encrypt256(personDetail.attributes.place_birth);
  //     // eslint-disable-next-line no-param-reassign
  //     personDetail.attributes.place_birth = mobPersonal.encryptedData;
  //   }
  // });

  person.afterFind(async (personData) => {
    if (personData && personData[0] && personData[0].country_of_citizenship) {
      const countryOfCitizenship = await decrypt256(personData[0].country_of_citizenship);
      // eslint-disable-next-line no-param-reassign
      personData[0].country_of_citizenship = countryOfCitizenship.decryptedData;
    }
  });

  person.beforeCreate(async (personDetail) => {
    const columns = ['display_name','first_name','middle_name','last_name', 'dob', 'age', 'title', 'name_on_debit_card', 'place_birth', 'kyc_flag'];
    await Promise.all(columns.map(async (key) => {
      if (columns.includes(key) && personDetail[key]) {
        personDetail[key] = (await encrypt256(personDetail[key].toString())).encryptedData;
      }
      return true;
    }));
  });

  return person;
};