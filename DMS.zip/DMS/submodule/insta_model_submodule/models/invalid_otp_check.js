/* eslint-disable max-len */
/* eslint-disable camelcase */
/* eslint-disable no-param-reassign */
const datdecryptAES256 = require('../../insta_util_submodule/utils/encryptDecryptAES256');

module.exports = (sequelize, DataTypes) => {
  const invalidOtpCheck = sequelize.define('invalid_otp_check', {
    id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    mobile_no: DataTypes.STRING,
    secondary_contact_detail: DataTypes.STRING,
    account_type: DataTypes.STRING,
    source: DataTypes.STRING,
    trans_id: DataTypes.STRING,
    invalid_otp_count: DataTypes.STRING,
    timer: DataTypes.STRING,
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,
  }, {
    tableName: 'invalid_otp_check',
    createdAt: 'createdTime',
    updatedAt: 'updatedTime',
  });

  invalidOtpCheck.beforeCreate(async (invalidOtpCheckValue) => {
    if (invalidOtpCheckValue && invalidOtpCheckValue.mobile_no) {
      const mobile_no = await datdecryptAES256.encrypt256(invalidOtpCheckValue.mobile_no);
      invalidOtpCheckValue.mobile_no = mobile_no.encryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue.secondary_contact_detail) {
      const secondary_contact_detail = await datdecryptAES256.encrypt256(invalidOtpCheckValue.secondary_contact_detail);
      invalidOtpCheckValue.secondary_contact_detail = secondary_contact_detail.encryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue.account_type) {
      const account_type = await datdecryptAES256.encrypt256(invalidOtpCheckValue.account_type);
      invalidOtpCheckValue.account_type = account_type.encryptedData;
    }
  });

  invalidOtpCheck.beforeBulkUpdate(async (invalidOtpCheckValue) => {
    if (invalidOtpCheckValue && invalidOtpCheckValue.attributes.mobile_no) {
      const mobPersonal = await datdecryptAES256.encrypt256(invalidOtpCheckValue.attributes.mobile_no);
      invalidOtpCheckValue.attributes.mobile_no = mobPersonal.encryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue.attributes.secondary_contact_detail) {
      const secondary_contact_detail = await datdecryptAES256.encrypt256(invalidOtpCheckValue.attributes.secondary_contact_detail);
      invalidOtpCheckValue.attributes.secondary_contact_detail = secondary_contact_detail.encryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue.attributes.account_type) {
      const account_type = await datdecryptAES256.encrypt256(invalidOtpCheckValue.attributes.account_type);
      invalidOtpCheckValue.attributes.account_type = account_type.encryptedData;
    }
  });

  invalidOtpCheck.afterFind(async (invalidOtpCheckValue) => {
    if (invalidOtpCheckValue && invalidOtpCheckValue[0] && invalidOtpCheckValue[0].mobile_no) {
      const mobPersonal = await datdecryptAES256.decrypt256(invalidOtpCheckValue[0].mobile_no);
      invalidOtpCheckValue[0].mobile_no = mobPersonal.decryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue[0] && invalidOtpCheckValue[0].secondary_contact_detail) {
      const secondary_contact_detail = await datdecryptAES256.decrypt256(invalidOtpCheckValue[0].secondary_contact_detail);
      invalidOtpCheckValue[0].secondary_contact_detail = secondary_contact_detail.decryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue[0] && invalidOtpCheckValue[0].account_type) {
      const account_type = await datdecryptAES256.decrypt256(invalidOtpCheckValue[0].account_type);
      invalidOtpCheckValue[0].account_type = account_type.decryptedData;
    }
  });

  invalidOtpCheck.beforeFind(async (invalidOtpCheckValue) => {
    if (invalidOtpCheckValue && invalidOtpCheckValue.where && invalidOtpCheckValue.where.mobile_no) {
      const mobPersonal = await datdecryptAES256.encrypt256(invalidOtpCheckValue.where.mobile_no);
      invalidOtpCheckValue.where.mobile_no = mobPersonal.encryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue.where && invalidOtpCheckValue.where.secondary_contact_detail) {
      const secondary_contact_detail = await datdecryptAES256.encrypt256(invalidOtpCheckValue.where.secondary_contact_detail);
      invalidOtpCheckValue.where.secondary_contact_detail = secondary_contact_detail.encryptedData;
    }
    if (invalidOtpCheckValue && invalidOtpCheckValue.where && invalidOtpCheckValue.where.account_type) {
      const account_type = await datdecryptAES256.encrypt256(invalidOtpCheckValue.where.account_type);
      invalidOtpCheckValue.where.account_type = account_type.encryptedData;
    }
  });

  return invalidOtpCheck;
};
