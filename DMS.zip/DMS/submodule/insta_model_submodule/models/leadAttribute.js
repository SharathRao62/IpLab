module.exports = (sequelize, DataTypes) => {
  const leadAttribute = sequelize.define('lead_attribute', {
    lead_attribute_id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    lead_id: DataTypes.STRING,
    person_id: DataTypes.INTEGER,
    mobile_no: DataTypes.STRING,
    attribute_name: DataTypes.STRING,
    attribute_value: DataTypes.STRING,
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,

  }, {
    tableName: 'lead_attribute',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });
  return leadAttribute;
};
