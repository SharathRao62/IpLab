module.exports = (sequelize, DataTypes) => {
  const systemConfiguration = sequelize.define('system_configuration', {
    id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    configuration_name: DataTypes.STRING,
    value: DataTypes.STRING,
    product_list: DataTypes.STRING,
    enviornment_list: DataTypes.STRING,
    journey_list: DataTypes.STRING,
  }, {
    tableName: 'system_configuration',
  });

  return systemConfiguration;
};
