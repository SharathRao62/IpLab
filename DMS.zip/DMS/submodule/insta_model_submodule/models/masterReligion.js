
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('master_religion', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
    product_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'products',
        key: 'product_id',
      },
    },
    religions: {
      type: DataTypes.STRING(128),
      allowNull: false,
    },
    religion_id: {
      type: DataTypes.STRING(128),
      allowNull: true,
    },
    rcas_code: {
      type: DataTypes.STRING(128),
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'master_religion',
    timestamps: true,
    indexes: [
      {
        name: 'PRIMARY',
        unique: true,
        using: 'BTREE',
        fields: [
          { name: 'id' },
        ],
      },
      {
        name: 'product_id',
        using: 'BTREE',
        fields: [
          { name: 'product_id' },
        ],
      },
    ],
  });
};
