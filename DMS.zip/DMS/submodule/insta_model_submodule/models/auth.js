/* eslint-disable camelcase */
/* eslint-disable no-param-reassign */
const datdecryptAES256 = require('../../insta_util_submodule/utils/encryptDecryptAES256');

module.exports = (sequelize, DataTypes) => {
  const auth = sequelize.define('auth', {
    auth_id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    lead_id: DataTypes.STRING,
    jwt_token: DataTypes.STRING,
    is_delete_ready: DataTypes.BOOLEAN,
    updatedTime: DataTypes.DATE,
    createdTime: DataTypes.DATE,

  }, {
    tableName: 'auth',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });


  return auth;
};
