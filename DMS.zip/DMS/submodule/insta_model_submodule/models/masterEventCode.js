module.exports = (sequelize, DataTypes) => {
  const masterEventCode = sequelize.define('master_event_code', {
    master_event_code_id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    event_code: DataTypes.STRING,
    event_description: DataTypes.STRING,
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,
  }, {
    tableName: 'master_event_code',
    timestamps: false,
  });

  return masterEventCode;
};
