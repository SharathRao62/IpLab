/* 128225 RASHNI JAN 4 2022 BEGIN */

module.exports = (sequelize, DataTypes) => {
  const fetchErrorCode = sequelize.define('master_error_code', {
    id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    error_short_desc: DataTypes.STRING,
    error_code: DataTypes.STRING,
    description: DataTypes.STRING,
    header_message: DataTypes.STRING,
    api_service: DataTypes.STRING,
    api_name: DataTypes.STRING,
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,
    act_code: DataTypes.STRING,
    act_code_desc: DataTypes.STRING,

  }, {
    tableName: 'master_error_code',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });
  return fetchErrorCode;
};
