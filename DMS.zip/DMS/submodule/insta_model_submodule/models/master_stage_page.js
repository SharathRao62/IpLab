module.exports = (sequelize, DataTypes) => {
    const master_stage_page = sequelize.define('master_stage_page', {
        id: {
            primaryKey: true,
            allowNull: false,
            type: DataTypes.INTEGER,
        },
        product_id: DataTypes.STRING,
        stage: {
            allowNull: false,
            type: DataTypes.STRING,
        },
        stage_description: DataTypes.STRING,
        page: {
            allowNull: false,
            type: DataTypes.STRING,
        },
        page_description: DataTypes.STRING,
        next_action: DataTypes.STRING,
        isActive: DataTypes.BOOLEAN,
        createdTime: DataTypes.DATE,
        updatedTime: DataTypes.DATE,
    }, {
        freezeTableName: true,
    });
    return master_stage_page;
};