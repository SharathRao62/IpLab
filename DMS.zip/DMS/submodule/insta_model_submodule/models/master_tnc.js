
module.exports = function (sequelize, DataTypes) {
  const MasterTnc = sequelize.define('master_tnc', {
    master_tnc_id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    product_id: {
      type: DataTypes.INTEGER,
      defaultValue: null,
    },
    journey_id: {
      type: DataTypes.STRING(8),
      defaultValue: null,
    },
    addon_product_id: {
      type: DataTypes.INTEGER,
      defaultValue: null,
    },
    decider: {
      type: DataTypes.STRING(256),
      defaultValue: null,
    },
    tnc_content: {
      type: DataTypes.STRING(256),
      defaultValue: null,
    },
    createdTime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    updatedTime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
      onUpdate: DataTypes.NOW,
    },
  }, {
    tableName: 'master_tnc',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });

  return MasterTnc;
};
