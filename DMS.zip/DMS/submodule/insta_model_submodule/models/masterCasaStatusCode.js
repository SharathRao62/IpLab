module.exports = (sequelize, DataTypes) => sequelize.define('master_casa_status_code', {
  id: {
    autoIncrement: true,
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
  },
  product_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  journey_id: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  status_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  application_score_band: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  fund_gte_95k: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_age: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  decider: {
    type: DataTypes.JSON,
    allowNull: true,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: true,
  },
}, {
  sequelize,
  tableName: 'master_casa_status_code',
  updatedAt: 'updatedTime',
  createdAt: 'createdTime',
  timestamps: true,
  indexes: [
    {
      name: 'PRIMARY',
      unique: true,
      using: 'BTREE',
      fields: [
        { name: 'id' },
      ],
    },
  ],
});
