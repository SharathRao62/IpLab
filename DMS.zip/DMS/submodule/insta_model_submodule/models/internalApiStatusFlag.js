
module.exports = (sequelize, DataTypes) => {
  const internalApiStatusFlag = sequelize.define('internal_api_status', {
    id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    lead_id: DataTypes.STRING,
    person_id: DataTypes.INTEGER,
    api_name: DataTypes.STRING,
    mobile_no: DataTypes.STRING,
    flag: DataTypes.INTEGER,
    updatedTime: DataTypes.DATE,
    createdTime: DataTypes.DATE,
  }, {
    tableName: 'internal_api_status',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });


  return internalApiStatusFlag;
};
