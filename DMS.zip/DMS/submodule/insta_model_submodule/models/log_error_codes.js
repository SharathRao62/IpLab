module.exports = (sequelize, DataTypes) => {
  const logErrorCode = sequelize.define('log_error_code', {
    id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    lead_id: DataTypes.STRING,
    person_id: DataTypes.INTEGER,
    mobile_no: DataTypes.STRING,
    error_id: DataTypes.INTEGER,
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,
  }, {
    tableName: 'log_error_code',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });
  return logErrorCode;
};
