
module.exports = (sequelize, DataTypes) => {
  const role = sequelize.define('role', {
    role_id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
    person_id: DataTypes.INTEGER,
    lead_id: DataTypes.STRING,
    role_code: DataTypes.STRING,
    is_esign_done: DataTypes.BOOLEAN,
    esign_done_at: DataTypes.DATE,
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,
    migrationFlag: DataTypes.BOOLEAN,
    migratedDate: DataTypes.DATEONLY,
    migratedTime: DataTypes.DATE,
  }, {
    tableName: 'role',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });
  return role;
};
