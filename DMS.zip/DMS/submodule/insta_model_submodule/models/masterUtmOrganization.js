module.exports = (sequelize, DataTypes) => {
  const masterUtmOrganization = sequelize.define('master_utm_organization', {
    id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    org_id: DataTypes.STRING,
    utm_product_id: DataTypes.STRING,
    utm_source_id: DataTypes.STRING,
    product_id: DataTypes.STRING,
    product_check_enable: DataTypes.STRING,
    page: DataTypes.STRING,
    utm_source: DataTypes.STRING,
    company_list: DataTypes.STRING,
    company_logo: DataTypes.STRING,
    company_url: DataTypes.STRING,
    aes_key: DataTypes.STRING,
    configuration_bypass: DataTypes.STRING,
    casa_status_code: DataTypes.STRING,
    card_type: DataTypes.STRING,
    cloudpush_status_code: DataTypes.STRING,
    is_funding: DataTypes.BOOLEAN,
    thank_you_page_shown: DataTypes.BOOLEAN,
    is_freeze_code_enabled: DataTypes.BOOLEAN,
    loa: DataTypes.STRING,
    reverse_api_push: DataTypes.STRING,
    reverse_api_push_count: DataTypes.STRING,
    reverse_feed_querry: DataTypes.STRING,
  });

  return masterUtmOrganization;
};
