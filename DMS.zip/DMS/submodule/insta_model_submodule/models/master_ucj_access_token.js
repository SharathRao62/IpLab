const datdecryptAES256 = require('../../insta_util_submodule/utils/encryptDecryptAES256');

module.exports = (sequelize, DataTypes) => {
  const master_ucj_access_token = sequelize.define(
    "master_ucj_access_token",
    {
      id: {
        primaryKey: true,
        allowNull: false,
        type: DataTypes.INTEGER,
        autoIncrement: true,
      },
      access_token: DataTypes.STRING,
      apiKey: DataTypes.STRING,
      apiSecret: DataTypes.STRING,
      status: DataTypes.STRING,
      api_response_code: DataTypes.STRING,
      expiryTime: DataTypes.STRING,
      createdTime: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      updatedTime: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      tableName: "master_ucj_access_token",
      updatedAt: "updatedTime",
      createdAt: "createdTime",
    }
  );

  let columns = ['access_token']

  master_ucj_access_token.afterFind(async (accessData) => {
    if (accessData) {
      await Promise.all(columns.map(async (key) => {
        if (accessData[key]) {
          const data = await datdecryptAES256.decrypt256(accessData[key]);
          accessData[key] = data.decryptedData;
        }
        return '';
      }));
    }
  });

  return master_ucj_access_token;
};
