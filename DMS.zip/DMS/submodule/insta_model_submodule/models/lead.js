/* eslint-disable no-await-in-loop */
/* eslint-disable camelcase */
/* eslint-disable no-param-reassign */
/* eslint-disable no-shadow */
const datdecryptAES256 = require('../../insta_util_submodule/utils/encryptDecryptAES256');


module.exports = (sequelize, DataTypes) => {
  const lead = sequelize.define('lead', {
    lead_id: {
      allowNull: false,
      type: DataTypes.STRING,
      primaryKey: true,
    },
    journey_id: DataTypes.STRING,
    application_no: DataTypes.INTEGER,
    environment: DataTypes.STRING,
    platform: DataTypes.STRING,
    user_ip: DataTypes.STRING,
    latitude: DataTypes.STRING,
    longitude: DataTypes.STRING,
    location: DataTypes.STRING,
    // flow: DataTypes.STRING,
    account_type: DataTypes.INTEGER,
    qs: DataTypes.STRING,
    utm_source: DataTypes.STRING,
    utm_product: DataTypes.STRING,
    reference_id: DataTypes.STRING,
    geo_city: DataTypes.STRING,
    geo_state: DataTypes.STRING,
    geo_country: DataTypes.STRING,
    geo_pincode: DataTypes.STRING,
    application_form_version: DataTypes.INTEGER,
    // new_form_config_flag: DataTypes.INTEGER,
    is_funding_enabled_in_utm: DataTypes.BOOLEAN,
    crm_lead: DataTypes.STRING,
    start_time: DataTypes.INTEGER,
    end_time: DataTypes.INTEGER,
    track_time: DataTypes.INTEGER,
    stage_page_id: DataTypes.INTEGER,
    client_id: DataTypes.STRING,
    is_assisted_flow: DataTypes.BOOLEAN,
    // ucj_esign: DataTypes.BOOLEAN,
    // is_delete_ready: DataTypes.BOOLEAN,
    is_shortlink: {
      type: DataTypes.BOOLEAN,
      defaultValue: 0,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: 1,
    },
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,
  }, {
    tableName: 'lead',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
    // timestamps: false,
  });

  lead.associate = (models) => { // 100231
    // associations can be defined here
    if (models && models.contact) {
      lead.belongsTo(models.contact, {
        // Reference: https://sequelize.org/master/class/lib/model.js~Model.html#static-method-belongsTo
        foreignKey: 'lead_id', // <--- name of field in source table
        targetKey: 'lead_id', // <--- name of field in target table
      });
    }
    if (models && models.pan) {
      lead.belongsTo(models.pan, {
        // Reference: https://sequelize.org/master/class/lib/model.js~Model.html#static-method-belongsTo
        foreignKey: 'lead_id', // <--- name of field in source table
        targetKey: 'lead_id', // <--- name of field in target table
      });
    }
    if (models && models.savings_account) {
      lead.belongsTo(models.savings_account, {
        // Reference: https://sequelize.org/master/class/lib/model.js~Model.html#static-method-belongsTo
        foreignKey: 'lead_id', // <--- name of field in source table
        targetKey: 'lead_id', // <--- name of field in target table
      });
    }
    if (models && models.products) {
      lead.belongsTo(models.products, {
        // Reference: https://sequelize.org/master/class/lib/model.js~Model.html#static-method-belongsTo
        foreignKey: 'account_type', // <--- name of field in source table
        targetKey: 'product_name', // <--- name of field in target table
      });
    }
    if (models && models.payment_references) {
      lead.belongsTo(models.payment_references, {
        // Reference: https://sequelize.org/master/class/lib/model.js~Model.html#static-method-belongsTo
        foreignKey: 'lead_id', // <--- name of field in source table
        targetKey: 'lead_id', // <--- name of field in target table
      });
    }
  };

  lead.beforeCreate(async (leadValue) => {
    if (leadValue && leadValue.platform) {
      const platform = await datdecryptAES256.encrypt256(leadValue.platform);
      leadValue.platform = platform.encryptedData;
    }
    if (leadValue && leadValue.geo_city) {
      const geo_city = await datdecryptAES256.encrypt256(leadValue.geo_city);
      leadValue.geo_city = geo_city.encryptedData;
    }
    if (leadValue && leadValue.geo_state) {
      const geo_state = await datdecryptAES256.encrypt256(leadValue.geo_state);
      leadValue.geo_state = geo_state.encryptedData;
    }
    if (leadValue && leadValue.geo_country) {
      const geo_country = await datdecryptAES256.encrypt256(leadValue.geo_country);
      leadValue.geo_country = geo_country.encryptedData;
    }
    if (leadValue && leadValue.geo_pincode) {
      const geo_pincode = await datdecryptAES256.encrypt256(leadValue.geo_pincode);
      leadValue.geo_pincode = geo_pincode.encryptedData;
    }
    if (leadValue && leadValue.user_ip) {
      const user_ip = await datdecryptAES256.encrypt256(leadValue.user_ip);
      leadValue.user_ip = user_ip.encryptedData;
    }
    if (leadValue && leadValue.latitude) {
      const latitude = await datdecryptAES256.encrypt256(leadValue.latitude);
      leadValue.latitude = latitude.encryptedData;
    }
    if (leadValue && leadValue.longitude) {
      const longitude = await datdecryptAES256.encrypt256(leadValue.longitude);
      leadValue.longitude = longitude.encryptedData;
    }
    if (leadValue && leadValue.location) {
      const location = await datdecryptAES256.encrypt256(leadValue.location);
      leadValue.location = location.encryptedData;
    }
    // if (leadValue && leadValue.flow) {
    //   const flow = await datdecryptAES256.encrypt256(leadValue.flow);
    //   leadValue.flow = flow.encryptedData;
    // }
    // if (leadValue && leadValue.salary_range) {
    //   const salary_range = await datdecryptAES256.encrypt256(leadValue.salary_range);
    //   leadValue.salary_range = salary_range.encryptedData;
    // }
    if (leadValue && leadValue.qs) {
      const qs = await datdecryptAES256.encrypt256(leadValue.qs);
      leadValue.qs = qs.encryptedData;
    }
    if (leadValue && leadValue.utm_source) {
      const utm_source = await datdecryptAES256.encrypt256(leadValue.utm_source);
      leadValue.utm_source = utm_source.encryptedData;
    }
    if (leadValue && leadValue.utm_product) {
      const utm_product = await datdecryptAES256.encrypt256(leadValue.utm_product);
      leadValue.utm_product = utm_product.encryptedData;
    }
    if (leadValue && leadValue.crm_lead) {
      const crm_lead = await datdecryptAES256.encrypt256(leadValue.crm_lead);
      leadValue.crm_lead = crm_lead.encryptedData;
    }
  });
  lead.beforeBulkUpdate(async (leadValue) => {
    if (leadValue && leadValue.attributes.platform) {
      const platform = await datdecryptAES256.encrypt256(leadValue.attributes.platform);
      leadValue.attributes.platform = platform.encryptedData;
    }
    if (leadValue && leadValue.attributes.user_ip) {
      const user_ip = await datdecryptAES256.encrypt256(leadValue.attributes.user_ip);
      leadValue.attributes.user_ip = user_ip.encryptedData;
    }
    if (leadValue && leadValue.attributes.latitude) {
      const latitude = await datdecryptAES256.encrypt256(leadValue.attributes.latitude);
      leadValue.attributes.latitude = latitude.encryptedData;
    }
    if (leadValue && leadValue.attributes.longitude) {
      const longitude = await datdecryptAES256.encrypt256(leadValue.attributes.longitude);
      leadValue.attributes.longitude = longitude.encryptedData;
    }
    if (leadValue && leadValue.attributes.geo_city) {
      const geo_city = await datdecryptAES256.encrypt256(leadValue.attributes.geo_city);
      leadValue.attributes.geo_city = geo_city.encryptedData;
    }
    if (leadValue && leadValue.attributes.geo_state) {
      const geo_state = await datdecryptAES256.encrypt256(leadValue.attributes.geo_state);
      leadValue.attributes.geo_state = geo_state.encryptedData;
    }
    if (leadValue && leadValue.attributes.geo_country) {
      const geo_country = await datdecryptAES256.encrypt256(leadValue.attributes.geo_country);
      leadValue.attributes.geo_country = geo_country.encryptedData;
    }
    if (leadValue && leadValue.attributes.geo_pincode) {
      const geo_pincode = await datdecryptAES256.encrypt256(leadValue.attributes.geo_pincode);
      leadValue.attributes.geo_pincode = geo_pincode.encryptedData;
    }
    if (leadValue && leadValue.attributes.location) {
      const location = await datdecryptAES256.encrypt256(leadValue.attributes.location);
      leadValue.attributes.location = location.encryptedData;
    }
    // if (leadValue && leadValue.attributes.flow) {
    //   const flow = await datdecryptAES256.encrypt256(leadValue.attributes.flow);
    //   leadValue.attributes.flow = flow.encryptedData;
    // }
    if (leadValue && leadValue.attributes.qs) {
      const qs = await datdecryptAES256.encrypt256(leadValue.attributes.qs);
      leadValue.attributes.qs = qs.encryptedData;
    }
    if (leadValue && leadValue.attributes.utm_source) {
      const utm_source = await datdecryptAES256.encrypt256(leadValue.attributes.utm_source);
      leadValue.attributes.utm_source = utm_source.encryptedData;
    }
    if (leadValue && leadValue.attributes.utm_product) {
      const utm_product = await datdecryptAES256.encrypt256(leadValue.attributes.utm_product);
      leadValue.attributes.utm_product = utm_product.encryptedData;
    }
    if (leadValue && leadValue.attributes.crm_lead) {
      const crm_lead = await datdecryptAES256.encrypt256(leadValue.attributes.crm_lead);
      leadValue.attributes.crm_lead = crm_lead.encryptedData;
    }
  });
  lead.afterFind(async (leadValue) => {
    if (leadValue && leadValue.pan_no) {
      const pan_no = await datdecryptAES256.decrypt256(leadValue.pan_no);
      leadValue.pan_no = pan_no.decryptedData;
    }
    if (leadValue && leadValue.account_number) {
      const account_number = await datdecryptAES256.decrypt256(leadValue.account_number);
      leadValue.account_number = account_number.decryptedData;
    }
    if (leadValue && leadValue.cust_id) {
      const cust_id = await datdecryptAES256.decrypt256(leadValue.cust_id);
      leadValue.cust_id = cust_id.decryptedData;
    }
    if (leadValue && leadValue.mobile_personal) {
      const mobile_personal = await datdecryptAES256.decrypt256(leadValue.mobile_personal);
      leadValue.mobile_personal = mobile_personal.decryptedData;
    }
    if (leadValue && leadValue.email_personal) {
      const email_personal = await datdecryptAES256.decrypt256(leadValue.email_personal);
      leadValue.email_personal = email_personal.decryptedData;
    }
    if (leadValue && leadValue.length >= 1) {
      for (let i = 0; i <= leadValue.length - 1; i += 1) {
        if (leadValue && leadValue[i] && leadValue[i].platform) {
          const platform = await datdecryptAES256.decrypt256(leadValue[i].platform);
          leadValue[i].platform = platform.decryptedData;
        }
        if (leadValue && leadValue[i] && leadValue[i].user_ip) {
          const user_ip = await datdecryptAES256.decrypt256(leadValue[i].user_ip);
          leadValue[i].user_ip = user_ip.decryptedData;
        }
        if (leadValue && leadValue[i] && leadValue[i].latitude) {
          const latitude = await datdecryptAES256.decrypt256(leadValue[i].latitude);
          leadValue[i].latitude = latitude.decryptedData;
        }
        if (leadValue && leadValue[i] && leadValue[i].longitude) {
          const longitude = await datdecryptAES256.decrypt256(leadValue[i].longitude);
          leadValue[i].longitude = longitude.decryptedData;
        }
        if (leadValue && leadValue[i] && leadValue[i].location) {
          const location = await datdecryptAES256.decrypt256(leadValue[i].location);
          leadValue[i].location = location.decryptedData;
        }
        // if (leadValue && leadValue[i] && leadValue[i].flow) {
        //   const flow = await datdecryptAES256.decrypt256(leadValue[i].flow);
        //   leadValue[i].flow = flow.decryptedData;
        // }
        if (leadValue && leadValue[i] && leadValue[i].qs) {
          const qs = await datdecryptAES256.decrypt256(leadValue[i].qs);
          leadValue[i].qs = qs.decryptedData;
        }
        if (leadValue && leadValue[i] && leadValue[i].utm_source) {
          const utm_source = await datdecryptAES256.decrypt256(leadValue[i].utm_source);
          leadValue[i].utm_source = utm_source.decryptedData;
        }
        if (leadValue && leadValue[i] && leadValue[i].utm_product) {
          const utm_product = await datdecryptAES256.decrypt256(leadValue[i].utm_product);
          leadValue[i].utm_product = utm_product.decryptedData;
        }
        if (leadValue && leadValue[i] && leadValue[i].crm_lead) {
          const crm_lead = await datdecryptAES256.decrypt256(leadValue[i].crm_lead);
          leadValue[i].crm_lead = crm_lead.decryptedData;
        }
      }
    } else {
      if (leadValue && leadValue.platform) {
        const platform = await datdecryptAES256.decrypt256(leadValue.platform);
        leadValue.platform = platform.decryptedData;
      }
      if (leadValue && leadValue.user_ip) {
        const user_ip = await datdecryptAES256.decrypt256(leadValue.user_ip);
        leadValue.user_ip = user_ip.decryptedData;
      }
      if (leadValue && leadValue.latitude) {
        const latitude = await datdecryptAES256.decrypt256(leadValue.latitude);
        leadValue.latitude = latitude.decryptedData;
      }
      if (leadValue && leadValue.longitude) {
        const longitude = await datdecryptAES256.decrypt256(leadValue.longitude);
        leadValue.longitude = longitude.decryptedData;
      }
      if (leadValue && leadValue.location) {
        const location = await datdecryptAES256.decrypt256(leadValue.location);
        leadValue.location = location.decryptedData;
      }
      // if (leadValue && leadValue.flow) {
      //   const flow = await datdecryptAES256.decrypt256(leadValue.flow);
      //   leadValue.flow = flow.decryptedData;
      // }
      if (leadValue && leadValue.qs) {
        const qs = await datdecryptAES256.decrypt256(leadValue.qs);
        leadValue.qs = qs.decryptedData;
      }
      if (leadValue && leadValue.utm_source) {
        const utm_source = await datdecryptAES256.decrypt256(leadValue.utm_source);
        leadValue.utm_source = utm_source.decryptedData;
      }
      if (leadValue && leadValue.utm_product) {
        const utm_product = await datdecryptAES256.decrypt256(leadValue.utm_product);
        leadValue.utm_product = utm_product.decryptedData;
      }
      if (leadValue && leadValue.crm_lead) {
        const crm_lead = await datdecryptAES256.decrypt256(leadValue.crm_lead);
        leadValue.crm_lead = crm_lead.decryptedData;
      }
    }
  });
  lead.beforeFind(async (leadValue) => {
    if (leadValue && leadValue.where && leadValue.where.platform) {
      const platform = await datdecryptAES256.encrypt256(leadValue.where.platform);
      leadValue.where.platform = platform.encryptedData;
    }
    if (leadValue && leadValue.where && leadValue.where.user_ip) {
      const user_ip = await datdecryptAES256.encrypt256(leadValue.where.user_ip);
      leadValue.where.user_ip = user_ip.encryptedData;
    }
    if (leadValue && leadValue.where && leadValue.where.latitude) {
      const latitude = await datdecryptAES256.encrypt256(leadValue.where.latitude);
      leadValue.where.latitude = latitude.encryptedData;
    }
    if (leadValue && leadValue.where && leadValue.where.longitude) {
      const longitude = await datdecryptAES256.encrypt256(leadValue.where.longitude);
      leadValue.where.longitude = longitude.encryptedData;
    }
    if (leadValue && leadValue.where && leadValue.where.location) {
      const location = await datdecryptAES256.encrypt256(leadValue.where.location);
      leadValue.where.location = location.encryptedData;
    }
    // if (leadValue && leadValue.where && leadValue.where.flow) {
    //   const flow = await datdecryptAES256.encrypt256(leadValue.where.flow);
    //   leadValue.where.flow = flow.encryptedData;
    // }
    if (leadValue && leadValue.where && leadValue.where.qs) {
      const qs = await datdecryptAES256.encrypt256(leadValue.where.qs);
      leadValue.where.qs = qs.encryptedData;
    }
    if (leadValue && leadValue.where && leadValue.where.utm_source) {
      const utm_source = await datdecryptAES256.encrypt256(leadValue.where.utm_source);
      leadValue.where.utm_source = utm_source.encryptedData;
    }
    if (leadValue && leadValue.where && leadValue.where.utm_product) {
      const utm_product = await datdecryptAES256.encrypt256(leadValue.where.utm_product);
      leadValue.where.utm_product = utm_product.encryptedData;
    }
    if (leadValue && leadValue.where && leadValue.where.crm_lead) {
      const crm_lead = await datdecryptAES256.encrypt256(leadValue.where.crm_lead);
      leadValue.where.crm_lead = crm_lead.encryptedData;
    }
  });
  return lead;
};
