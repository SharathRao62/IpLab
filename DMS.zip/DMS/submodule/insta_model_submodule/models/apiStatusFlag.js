/* eslint-disable max-len */
/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
const datdecryptAES256 = require('../../insta_util_submodule/utils/encryptDecryptAES256');
const Logger = require('../../insta_util_submodule/utils/logger');

const logger = new Logger();
module.exports = (sequelize, DataTypes) => {
  const externalApiStatusFlag = sequelize.define(
    'external_api_status',
    {
      id: {
        primaryKey: true,
        allowNull: false,
        type: DataTypes.INTEGER,
        autoIncrement: true,
      },
      lead_id: DataTypes.STRING,
      person_id: DataTypes.INTEGER,
      api_name: DataTypes.STRING,
      mobile_no: DataTypes.STRING,
      flag: DataTypes.INTEGER,
      retry_count: DataTypes.INTEGER,
      updatedTime: DataTypes.DATE,
      createdTime: DataTypes.DATE,
    },
    {
      tableName: 'external_api_status',
      updatedAt: 'updatedTime',
      createdAt: 'createdTime',
    },
  );
  externalApiStatusFlag.beforeCreate(async (leadValue) => {
    const columns = ['mobile_no'];

    await Promise.all(
      columns.map(async (key) => {
        if (columns.includes(key) && leadValue[key]) {
          leadValue[key] = (
            await datdecryptAES256.encrypt256(leadValue[key].toString())
          ).encryptedData;
        }
        return true;
      }),
    );
  });


  externalApiStatusFlag.beforeUpdate(async (leadValue) => {
    const columns = ['mobile_no'];

    await Promise.all(
      columns.map(async (key) => {
        if (columns.includes(key) && leadValue.changed(key) && leadValue[key]) {
          leadValue[key] = (
            await datdecryptAES256.encrypt256(leadValue[key].toString())
          ).encryptedData;
        }
        return true;
      }),
    );
  });
  return externalApiStatusFlag;
};

//Encryption Added for mobile_No
