/* eslint-disable camelcase */
/* eslint-disable no-param-reassign */
const datdecryptAES256 = require('../../insta_util_submodule/utils/encryptDecryptAES256');

module.exports = (sequelize, DataTypes) => {
  const miscronstatus = sequelize.define('mis_cron_status', {
    mis_cron_status_id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    product_id: DataTypes.INTEGER,
    cron_start_time: DataTypes.DATE,
    cron_end_time: DataTypes.DATE,
    status: {
      type:   DataTypes.ENUM,
      values: ['SUCCESS','IN_PROGRESS','FAILED','STARTED']
    }
  ,
    description: DataTypes.STRING,
    updatedTime: DataTypes.DATE,
    createdTime: DataTypes.DATE,
    source: DataTypes.STRING,
  },
   {
    tableName: 'mis_cron_status',
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
  });


  return miscronstatus;
};
