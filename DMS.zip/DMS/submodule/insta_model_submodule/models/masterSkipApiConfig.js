/* eslint-disable no-restricted-syntax */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-param-reassign */
/* eslint-disable max-len */
const datdecryptAES256 = require('../../insta_util_submodule/utils/encryptDecryptAES256');

module.exports = (sequelize, DataTypes) => {
  const masterSkipApiConfig = sequelize.define('master_skip_apis_config', {
    id: {
      primaryKey: true,
      allowNull: false,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    product_id: DataTypes.STRING,
    api_name: DataTypes.STRING,
    mobile_no: DataTypes.STRING,
    email_id: DataTypes.STRING,
    pan: DataTypes.STRING,
    user_ip: DataTypes.STRING,
    start_date: DataTypes.DATE,
    end_date: DataTypes.DATE,
    is_account_creation: DataTypes.STRING,
    is_active: DataTypes.STRING,
    environment: DataTypes.STRING,
    createdTime: DataTypes.DATE,
    updatedTime: DataTypes.DATE,
  }, {
    tableName: 'master_skip_apis_config',
    timestamps: false,
  });

  masterSkipApiConfig.beforeCreate(async (masterSkipApiConfigDetail) => {
    if (masterSkipApiConfigDetail) {
      const columns = ['mobile_no', 'email_id', 'pan', 'user_ip'];

      for (const key of columns) {
        if (masterSkipApiConfigDetail[key]) {
          masterSkipApiConfigDetail[key] = (await datdecryptAES256.encrypt256(masterSkipApiConfigDetail[key])).encryptedData;
        }
      }
    }
  });

  masterSkipApiConfig.beforeUpdate(async (masterSkipApiConfigDetail) => {
    if (masterSkipApiConfigDetail) {
      const columns = ['mobile_no', 'email_id', 'pan', 'user_ip'];

      for (const key of columns) {
        if (masterSkipApiConfigDetail[key]) {
          masterSkipApiConfigDetail[key] = (await datdecryptAES256.encrypt256(masterSkipApiConfigDetail[key])).encryptedData;
        }
      }
    }
  });

  masterSkipApiConfig.beforeFind(async (masterSkipApiConfigDetail) => {
    if (masterSkipApiConfigDetail) {
      const columns = ['mobile_no', 'email_id', 'pan', 'user_ip'];

      for (const key of columns) {
        if (masterSkipApiConfigDetail.where[key]) {
          masterSkipApiConfigDetail.where[key] = (await datdecryptAES256.encrypt256(masterSkipApiConfigDetail.where[key])).encryptedData;
        }
      }
    }
  });

  masterSkipApiConfig.afterFind(async (masterSkipApiConfigDetail) => {
    if (masterSkipApiConfigDetail) {
      const columns = ['mobile_no', 'email_id', 'pan', 'user_ip'];

      for (const key of columns) {
        if (masterSkipApiConfigDetail[key]) {
          masterSkipApiConfigDetail[key] = (await datdecryptAES256.decrypt256(masterSkipApiConfigDetail[key])).decryptedData;
        }
      }
    }
  });

  return masterSkipApiConfig;
};
