class Repository {
  constructor(model) {
    this.$model = model;
  }

  #rawQuery(query, replacements, type) {
    return this.$model.sequelize.query(query, {
      replacements,
      type,
    });
  }

  /**
   *
   * @param {Object} condition Where condition
   * @param {Array} attributes Columns to be fetched
   * @returns {Promise}
   */
  findOne(condition, attributes = ['*'], raw = true, order = []) {
    return this.$model.findOne({
      attributes,
      where: condition,
      raw,
      order,
    });
  }

  /**
   *
   * @param {Object} condition Where condition
   * @param {Array} attributes Columns to be fetched
   * @returns {Promise}
   */
  findAll(condition = null, attributes = ['*'], raw = true, order = []) {
    if (condition) {
      return this.$model.findAll({
        attributes,
        where: condition,
        raw,
        order,
      });
    }
    return this.$model.findAll();
  }

  /**
   *
   * @param {Object} query Query
   * @param {Object} replacements Replacements for above query
   * @returns {Promise}
   */
  findByQuery(query, replacements = {}) {
    return this.#rawQuery(query, replacements, this.$model.sequelize.QueryTypes.SELECT);
  }

  /**
   *
   * @param {Object} updateData Data to be updated
   * @param {Object} condition Where condition
   * @returns {Promise}
   */
  update(updateData, condition) {
    return this.$model.update(
      updateData,
      {
        where: condition,
      },
    );
  }

  /**
   *
   * @param {Object} query Query
   * @param {Object} replacements Replacements for query
   * @returns {Promise}
   */
  updateByQuery(query, replacements = {}) {
    return this.#rawQuery(query, replacements, this.$model.sequelize.QueryTypes.UPDATE);
  }

  /**
   *
   * @param {Object} data To be updated or created
   * @param {Array} attributes Columns
   * @param {Object} condition Where condition
   * @param {String} primaryParameter Primary key name
   * @param {Array} order order by for findOne
   * @returns
   */
  async createOrUpdate(data, attributes, condition, primaryParameter, order = []) {
    // Check if the record exists
    const response = await this.findOne(condition, attributes, true, order);

    // If the record exists, update it, else create a new record
    if (response) {
      // Ensure primaryParameter is set to the value from response before update
      // eslint-disable-next-line no-param-reassign
      condition[primaryParameter] = response[primaryParameter];
      return this.update(data, condition);
    }

    // Create a new record if not found
    return this.create(data);
  }

  /**
   *
   * @param {Object} data Data to be created
   * @returns {Promise}
   */
  async create(data) {
    return this.$model.create(data);
  }
}

module.exports = Repository;
