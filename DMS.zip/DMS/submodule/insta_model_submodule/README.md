# insta_model_submodule

## Overview
This microservice is used as a common submodule for all the other microservice. It contains model file of table that will be used by sub_module. 

Developer need to add the model file of table inside model folder ,if they are using it in submodule.

## Step to add this submodule to the main microservices
1. Excute the command
 git submodule add git@gitlab.niveussolutions.com:icici/insta/insta-new/common/insta_model_submodule.git submodule/insta_model_submodule
2. Go to parent repository(main microservice).
3. Commit the changes that’s currently staged and push the changes
git commit -m ’add insta_util submodule’
git push

# Code changes to be made in index.js (under model folder) in main microservices.

const modelFilesOfSubmodel = require('../submodule/insta_model_submodule/models/index.js');

const dbSubmodule = modelFilesOfSubmodel.indexModel();

A sample file is attached in this microservice(sampleFIleOfMainMicro).

###Note: The model file in this submodule is given preference if same model file is present in the main micro

### Running the server

There is no pipeline present for this micro. Any changes present has to be added and pushed 

In the parent microservice changes in the submodules can be reflected using below command

sh ../checkout/checkout development 
(Note: checkout micro to be cloned and present in your local system in the folder where this micro is cloned)

