
'use strict';

const Logger = require('../../insta_util_submodule/utils/logger');

const logger = new Logger();

const constant = require('../../insta_main_submodule/constants');

// [START kms_decrypt]
async function decrypt(
  projectId = constant.PROJECT_ID, // Your GCP projectId
  keyRingId = constant.KEY_RING_ID, // Name of the crypto key's key ring
  cryptoKeyId = constant.CRYPTO_KEY_ID, // Name of the crypto key, e.g. "my-key"
  plaintextFileName = '../../insta_config_submodule/config/config1.json',
  ciphertextFileName = '../../insta_config_submodule/config/config.json.encrypted'
) {
  const fs = require('fs');
  const { promisify } = require('util');

  // Import the library and create a client
  const kms = require('@google-cloud/kms');
  const client = new kms.KeyManagementServiceClient();

  // The location of the crypto key's key ring, e.g. "global"
  const locationId = constant.LOCATION_ID;


  // Reads the file to be decrypted
  const readFile = promisify(fs.readFile);
  const ciphertext = await readFile(ciphertextFileName);
  const name = client.cryptoKeyPath(
    projectId,
    locationId,
    keyRingId,
    cryptoKeyId,
  );
  logger.debug(`CIPHER TEXT | ${JSON.stringify(ciphertext)} | ${ciphertext}`);

  // Decrypts the file using the specified crypto key
  const [result] = await client.decrypt({ name, ciphertext });

  // Writes the decrypted file to disk
  logger.debug(`PLAIN TEXT | ${JSON.stringify(result.plaintext)} | ${result.plaintext}`);
  const writeFile = promisify(fs.writeFile);
  await writeFile(plaintextFileName, result.plaintext);
  logger.debug(`Decrypted ${ciphertextFileName} | ${JSON.stringify(ciphertextFileName)} , result saved to ${plaintextFileName} | ${JSON.stringify(plaintextFileName)}.`);
}
// [END kms_decrypt]

const args = process.argv.slice(2);
decrypt(...args).catch(console.error);
