// Copyright 2018 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

'use strict';

const Logger = require('../../insta_util_submodule/utils/logger');

const logger = new Logger();
const constant = require('../../insta_main_submodule/constants');

// [START kms_encrypt]
async function encrypt(
  projectId = constant.PROJECT_ID, // Your GCP projectId
  keyRingId = constant.KEY_RING_ID, // Name of the crypto key's key ring
  cryptoKeyId = constant.CRYPTO_KEY_ID, // Name of the crypto key, e.g. "my-key"
  plaintextFileName = constant.CONFIG_PLAIN_TEXT_FILE_NAME,
  ciphertextFileName = constant.CONFIG_CIPHER_TEXT_FILE_NAME,
) {
  const fs = require('fs');
  const { promisify } = require('util');

  // Import the library and create a client
  const kms = require('@google-cloud/kms');
  const client = new kms.KeyManagementServiceClient();

  // The location of the crypto key's key ring, e.g. "global"
  const locationId = constant.LOCATION_ID;

  // Reads the file to be encrypted
  const readFile = promisify(fs.readFile);
  const plaintext = await readFile(plaintextFileName);
  const name = client.cryptoKeyPath(
    projectId,
    locationId,
    keyRingId,
    cryptoKeyId,
  );

  // Encrypts the file using the specified crypto key
  const [result] = await client.encrypt({ name, plaintext });
  const writeFile = promisify(fs.writeFile);
  await writeFile(ciphertextFileName, result.ciphertext);
  logger.debug(`Encrypted ${plaintextFileName} | ${JSON.stringify(plaintextFileName)} using ${result.name}.`);
  logger.debug(`Result saved to ${ciphertextFileName} | ${JSON.stringify(ciphertextFileName)}.`);
}
// [END kms_encrypt]

// enviroment wise change the configfile
const environment = process.env.NODE_ENV || 'staging';
logger.debug(`ENVIRONMENT | ${JSON.stringify(environment)}`);
const projectId = constant.PROJECT_ID;// Your GCP projectId
const keyRingId = constant.KEY_RING_ID; // Name of the crypto key's key ring
const cryptoKeyId = constant.CRYPTO_KEY_ID; // Name of the crypto key, e.g. "my-key"
const plaintextFileName = constant.CONFIG_PLAIN_TEXT_FILE_NAME;
let ciphertextFileName = constant.CONFIG_CIPHER_TEXT_FILE_NAME;

switch (environment) {
  case 'development':
    break;
  case 'qa':
    ciphertextFileName = '../../insta_config_submodule/config/config.qa.js.encrypted';
    break;
  case 'staging':
    ciphertextFileName = '../../insta_config_submodule/config/config.staging.js.encrypted';
    break;
  default:
    ciphertextFileName = '../../insta_config_submodule/config/config.production.js.encrypted';
    break;
}
encrypt(projectId,
  keyRingId,
  cryptoKeyId,
  plaintextFileName,
  ciphertextFileName).catch(console.error);
