# insta_vault

## Overview
This microservice is used as a common submodule for all the other microservice. It contains encrypt-decrypt files which is used to encrypt the environment config files and is also used for kms changes of config and environment config file. 

Encryption of environment config file can be performed but by adding this submodule into the parent micro and running the below commands
sh ../checkout/checkout development
cd submodule
cd ao_insta_vault
cd vault
for dev - node encrypt_dev.js
for qa - node encrypt_qa.js
for staging - node encrypt_staging.js
for pre-prod/prod encryption - node encrypt_prod.js

### Running the server

There is no pipeline present for this micro. Any changes present has to be added and pushed 

In the parents microservice changes in the submodules can be reflected using below command

sh ../checkout/checkout development