const Logger = require('../utils/logger');
const properties = require("../../../package.json");
const jwt = require('../utils/jwt');
const leadService = require('../api/service/leadService');
const {
  METHOD, SUCCESS_MESSAGE, ERROR_MESSAGE,
} = require('../../insta_constants_submodule/constants/constantLogger');
const {
  STATUS_CODE, TOKEN_EXIPRED_ERROR, ERROR_CODE,
} = require('../../insta_constants_submodule/constants/constant');


const verifyToken = async (req, res, next) => {
  const logger = new Logger(`${METHOD.VERIFY_TOKEN}`, 'AUTHORIZATION', ` ${JSON.stringify(req.headers.authorization)}`);
  try {
    const { authorization } = req.headers;
    logger.debug(`REQUEST HEADER ${JSON.stringify(req.headers)} `);
    if (authorization && authorization.startsWith('Bearer') && authorization.split(' ')[1]) {
      const response = await jwt.jwtVerify(authorization.split(' ')[1]);
      if (!response || !response.partner) {
        logger.debug('INVALID USER');
        res.status(STATUS_CODE.FORBIDDEN);
        res.send();
      }else{
        req.body.domain = response.partner
        next();
      }
    } else {
      logger.debug('INVALID HEADER');
      res.status(STATUS_CODE.FORBIDDEN);
      res.send();
    }
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | VERIFY | ${ERROR_MESSAGE.VERIFY_TOKEN} | ${JSON.stringify(error)} | ${error}`);
    if (error.name === TOKEN_EXIPRED_ERROR) {
      res.status(STATUS_CODE.JWT_TOKEN_EXPIRED);
      res.send();
    } else {
      res.status(STATUS_CODE.FORBIDDEN);
      res.send();
    }
  }
};

module.exports = { verifyToken,};
