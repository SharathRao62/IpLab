/* eslint-disable consistent-return */
const Logger = require('../utils/logger');

const {
  MIDDLEWARE, METHOD,
} = require('../../insta_constants_submodule/constants/constantLogger');
const { STATUS_CODE, ERROR_CODE } = require('../../insta_constants_submodule/constants/constant');
const { errorFormat } = require('../utils/errorFormat');

const sanitizeData = (req) => {
  const logger = new Logger(`${METHOD.SANITIZE_DATA}`, `${MIDDLEWARE}`, '');
  try {
    const keys = Object.keys(req.body);
    const { url } = req;
    if (!keys.length) {
      return req.body;
    }
    logger.debug(`URL | ${errorFormat(url)}`);
    if (url.includes('/saveBasicInfo')) {
      logger.debug(`URL INCLUDES BASIC INFO | ${errorFormat(url)}`);
      keys.forEach((key, index) => {
        if ((typeof req.body[key]) === 'string' && req.body[key]) {
          req.body[key] = req.sanitize(req.body[key])
            .replace(/ NULL /g, ' ')
            .replace(/NULL /g, ' ')
            .replace(/ NULL/g, ' ')
            .replace(/ +(?= )/g, '')
            .trim();
        }
        if (index === keys.length - 1) {
          return req.body;
        }
      });
    } else if (url.includes('/utmValidation')){
      keys.forEach((key, index) => {
        console.log('req.body[key]',req.body[key]);
        if ((typeof req.body[key]) === 'string' && req.body[key] && key !== 'prm' && key !== 'iparam') {
          req.body[key] = req.sanitize(req.body[key])
            .replace(/ NULL /g, ' ')
            .replace(/[\u{0080}-\u{FFFF}]/gu, '')
            .replace(/NULL /g, ' ')
            .replace(/ NULL/g, ' ')
            .replace(/ +(?= )/g, '')
            .replace('&AMP;', '&')
            .replace(/[^\w]/g,'')
            .toUpperCase()
            .trim();
        }
        if ((typeof req.body[key]) === 'string' && req.body[key] && (key == 'prm' || key == 'iparam')) {
          req.body[key] = req.sanitize(req.body[key])
            .replace(/ NULL /g, ' ')
            .replace(/[\u{0080}-\u{FFFF}]/gu, '')
            .replace(/NULL /g, ' ')
            .replace(/ NULL/g, ' ')
            .replace(/ +(?= )/g, '')
            .replace('&AMP;', '&')
            .replace(/[\(\)\%\$\#\@\!\^\*\'\~\`]/, '')
            .trim();
        }
        console.log('after req.body[key]',req.body[key]);
        if (index === keys.length - 1) {
          return req.body;
        }
        
      });      
    } else {
      logger.debug(`URL DOES NOT INCLUDES BASIC INFO | ${errorFormat(url)}`);
      keys.forEach((key, index) => {
        if ((typeof req.body[key]) === 'string' && req.body[key] && key !== 'jwtToken' && key !== 'qp' && key !== 'entity_proof_base64_pdfurl' && key !== 'prm' && key !== 'captcha_solution' && key !== 'reCaptcha') {
          req.body[key] = req.sanitize(req.body[key])
            .replace(/ NULL /g, ' ')
            .replace(/[\u{0080}-\u{FFFF}]/gu, '')
            .replace(/NULL /g, ' ')
            .replace(/ NULL/g, ' ')
            .replace(/ +(?= )/g, '')
            .toUpperCase()
            .replace('&AMP;', '&')
            .trim();
        } else if ((typeof req.body[key]) === 'string' && req.body[key] && key !== 'prm') {
          req.body[key] = req.sanitize(req.body[key])
            .replace(/ NULL /g, ' ')
            .replace(/[\u{0080}-\u{FFFF}]/gu, '')
            .replace(/NULL /g, ' ')
            .replace(/ NULL/g, ' ')
            .trim();
        }
        if (index === keys.length - 1) {
          return req.body;
        }
      });
    }
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | SANITIZE DATA | catch | error | ${JSON.stringify(error)} | ${error}`);
    const err = { status: STATUS_CODE.BAD_REQUEST };
    throw err;
  }
};


module.exports = {
  sanitizeData,
};
