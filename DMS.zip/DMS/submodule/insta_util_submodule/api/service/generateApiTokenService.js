const Logger = require('../../utils/logger');
const { log_generate_api_token } = require('../../../../models');


const logGenerateApiToken = async (condition, updateData, data) => {
    const logger = new Logger(`logGenerateApiToken | lead_id | ${condition.lead_id}`);
    try {
      logger.debug(`Update status | ${JSON.stringify(updateData)}`);
      logger.debug(`DATA | ${JSON.stringify(data)}`);
      return log_generate_api_token.findOne({
        where: condition,
        order: [['log_generate_api_token_id', 'DESC']],
        raw: true,
      }).then(async (logData) => {
        logger.debug(`logData | ${JSON.stringify(logData)}`);
        if (logData && logData.log_generate_api_token_id && logData.status !== 'FAILED') {
          logger.debug('Update');
          return log_generate_api_token.update(
            updateData,
            {
              where: {
                lead_id: logData.lead_id,
                log_generate_api_token_id: logData.log_generate_api_token_id,
              },
              order: [['log_generate_api_token_id', 'DESC']],
              limit: 1,
              raw: true,
            },
          );
        } else if (!logData || !logData.status == 'SUCCESS') {
            logger.debug('Create logGenerateApiToken');
            return log_generate_api_token.create(data);
        }
      });
    } catch (err) {
      const error = { error: `error  ${err}` };
      logger.error(`GENERATE API TOKEN UPDATE SERVICE | catch | error | ${JSON.stringify(error)}`);
      return Promise.reject({ status: 500 });
    }
  };

module.exports = {
    logGenerateApiToken
}