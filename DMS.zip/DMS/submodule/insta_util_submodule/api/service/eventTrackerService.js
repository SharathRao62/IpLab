/* eslint-disable consistent-return */
const Logger = require('../../utils/logger');

// const logger = new Logger();
const CONSTANTS = require('../../../../constants/constant');

const { master_event_code: masterEventCode, lead_attribute: leadAttribute } = require('../../../../models');
const {
  STATUS_CODE,
} = require('../../../insta_constants_submodule/constants/constant.js');
const { maskdata } = require('../../utils/logMasking');

const validateEventCode = (eventCode) => {
  const logger = new Logger(`ENTERING INTO VALIDATE EVENT CODE SERVICE  | ${eventCode}`);
  try {
    return masterEventCode.findAll({
      where: eventCode,
      raw: true,
    });
  } catch (error) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EVENT TRACKER SERVICE | CATCH ERROR | ${JSON.stringify(error)}`);
  }
};


const createEventTrackerLog = (data) => {
  const logger = new Logger('createEventTrackerLog', maskdata(data), 'DATA');

  if (data) {
    try {
      const condition = {
        attribute_name: data.attribute_name,
      };
      if (data.lead_id) {
        condition.lead_id = data.lead_id;
      } else if (data.mobile_no) {
        condition.mobile_no = data.mobile_no;
        condition.lead_id = null;
      } else {
        return { status: STATUS_CODE.INTERNAL_ERROR };
      }
      logger.debug(` CONDITION | ${maskdata(JSON.stringify(condition))} `);
      const columns = ['lead_attribute_id', 'attribute_name'];
      return leadAttribute.findOne({
        attributes: columns,
        where: condition,
        order: [['lead_attribute_id', 'DESC']],
        raw: true,
      }).then((logData) => {
        logger.debug(` logData | ${JSON.stringify(logData)} `);
        if (!logData || !logData.lead_attribute_id || !logData.attribute_name) {
          logger.debug(`ENTERING INTO CREATE EVENT TRACKER LOG SERVICE |  logData | ${JSON.stringify(logData)}`);
          return leadAttribute.create(data).catch((error) => error);
        }
        logger.debug('Update');
        return leadAttribute.update(
          { attribute_value: data.attribute_value },
          {
            where: { lead_attribute_id: logData.lead_attribute_id },
            order: [['lead_attribute_id', 'DESC']],
            limit: 1,
            raw: true,
          },
        );
      }).then((value) => {
        logger.debug(` value | ${maskdata(JSON.stringify(value))} `);
        if (!value[0] && (!value || !value.lead_attribute_id)) {
          logger.debug('not updated');
          return { status: STATUS_CODE.INTERNAL_ERROR };
        }
        return { status: STATUS_CODE.SUCCESS };
      });
    } catch (err) {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EVENT TRACKER SERVICE | catch | error | ${JSON.stringify(err)} |`);
      const error = { status: STATUS_CODE.INTERNAL_ERROR, error: `error  ${err}` };
      return error;
    }
  }
};


module.exports = {
  validateEventCode, createEventTrackerLog,
};
