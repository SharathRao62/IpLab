/* eslint-disable no-else-return */
const Logger = require('../../utils/logger');

const logger = new Logger();
const {
  person, auth, lead, master_utm_organization: utmOrganization,products,
} = require('../../../../models');
const { ENTERING_TO, SERVICE_METHOD } = require('../../../insta_constants_submodule/constants/constantLogger');
const { decryptColumns } = require('../../utils/sequelize');

const getAllData = (columns, condition, limitVal) => {
  if (limitVal) {
    logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getLeadData`);
    return auth.findAll({
      attributes: columns,
      where: condition,
      raw: true,
      limit: limitVal,
    });
  } else {
    logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getLeadData`);
    return auth.findAll({
      attributes: columns,
      where: condition,
      raw: true,
    });
  }
};

const getPersonData = (columns, condition, limitVal) => {
  if (limitVal) {
    logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getPersonData`);
    return person.findAll({
      attributes: columns,
      where: condition,
      raw: true,
      limit: limitVal,
    });
  } else {
    logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getPersonData`);
    return person.findAll({
      attributes: columns,
      where: condition,
      raw: true,
    });
  }
};

const getALLDetails = (sqlQuery, leadData) => lead.sequelize.query(
  sqlQuery,
  {
    replacements: leadData,
    type: lead.sequelize.QueryTypes.SELECT,
  },
);

const fetchEventLogsDetails = async (tableData, headerVal) => {
  if (!tableData.lead_id) {
    return null;
  }
  const leadTable = '`lead`';
  let query = 'SELECT lead.application_no, contact.mobile_personal, role.person_id ';

  if (!headerVal.ProductID) {
    query += ', products.product_name ';
  }

  query += `FROM ${leadTable} `;

  if (!headerVal.ProductID) {
    query += 'INNER JOIN products ON lead.account_type = products.product_id ';
  }

  query += `INNER JOIN contact ON contact.lead_id = lead.lead_id
      INNER JOIN role ON role.lead_id = lead.lead_id
      INNER JOIN master_role ON role.role_code = master_role.id
      WHERE lead.lead_id =:lead_id AND master_role.role_name =:roleName LIMIT 1`;

  const leadDetail = await getALLDetails(query, {
    lead_id: tableData.lead_id,
    roleName: 'PRIMARY',
  });

  await decryptColumns(['mobile_personal'], leadDetail, logger, tableData.lead_id);

  return leadDetail;
};

const getJouneyId = (leadId) => {
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getJouneyId`);
  return lead.findAll({
    attributes: ['journey_id'],
    where: { lead_id: leadId },
    raw: true,
    limit: 1,
  });
};

const getProductId = (leadId) => {
  logger.info(`${ENTERING_TO} ${SERVICE_METHOD} getProductId`);
  return lead.findAll({
    attributes: ['account_type'],
    where: { lead_id: leadId },
    raw: true,
    limit: 1,
  });
};

const getProductName = (productId) => {
  logger.info(`${ENTERING_TO} ${SERVICE_METHOD} getProductName`);
  return products.findAll({
    attributes: ['product_name'],
    where: { product_id: productId },
    raw: true,
    limit: 1,
  });
};

const update = (sqlQuery) => lead.sequelize.query(
  sqlQuery,
  {
    type: lead.sequelize.QueryTypes.UPDATE,
  },
);

const getJourneyAndProductData = (leadId) => {
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getJourneyAndProductData`);
  return lead.findAll({
    attributes: ['journey_id', 'account_type'],
    where: { lead_id: leadId },
    raw: true,
    limit: 1,
  });
};

const getDataService = (query, condition) => lead.sequelize.query(query, {
  replacements: condition,
  type: lead.sequelize.QueryTypes.SELECT,
});

const utmFindOne = (columns, where) => utmOrganization.findOne({
  attributes: columns,
  where,
  raw: true,
  limit: 1,
});

const leadFindOne = (columns, where) => lead.findOne({
  attributes: columns,
  where,
  raw: true,
  limit: 1,
});

const fetchPrimaryPersonId = async(leadId)=>{
  const logger = new Logger(`fetchPrimaryPersonId - ${leadId}`)

  const sqlQuery = `SELECT person.person_id FROM \`lead\` l JOIN person person ON person.lead_id = l.lead_id JOIN role r ON r.lead_id = person.lead_id AND r.person_id = person.person_id JOIN master_role mr ON mr.id = r.role_code AND mr.role_code = \'PR\' WHERE l.lead_id = '${leadId}'`;

  const result = await getALLDetails(sqlQuery);
  logger.info(`fetchPrimaryPersonId fetched successfully|result|${JSON.stringify(result)}`)
  if(result && result[0] && result[0].person_id){
      return Promise.resolve(result[0].person_id)
  }
  return null;
}


module.exports = {
  getAllData,
  getPersonData,
  getALLDetails,
  fetchEventLogsDetails,
  getJouneyId,
  update,
  getJourneyAndProductData,
  getProductId,
  getProductName,
  getDataService,
  utmFindOne,
  leadFindOne,
  fetchPrimaryPersonId,
};
