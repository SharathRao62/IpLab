const Logger = require('../../utils/logger');
const { invalid_otp_check: invalidOtpCheck, lead } = require('../../../../models');
const { STATUS_CODE, ERROR_CODE } = require('../../../insta_constants_submodule/constants/constant');
const { errorFormat } = require('../..//utils/errorFormat');
const { maskdata } = require('../../utils/logMasking');


const fecthOtpStatus = async (condition) => {
  const logger = new Logger('fecthOtpStatus Service', maskdata(JSON.stringify(condition)));
  try {
    return await invalidOtpCheck.findOne({
      attributes: ['id', 'invalid_otp_count', 'timer'],
      where: condition,
      raw: true,
      order: [['id', 'DESC']],
    });
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | fecthOtpStatus catch | error | ${errorFormat(err)}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    throw error;
  }
};

const createOtpStatus = async (createData) => {
  const logger = new Logger('createOtpStatus Service', maskdata(JSON.stringify(createData)));
  try {
    return await invalidOtpCheck.create(createData);
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | createOtpStatus catch | error | ${errorFormat(err)}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    throw error;
  }
};

const updateOtpCount = async (updateData, condition) => {
  const logger = new Logger('updateOtpCount Service', maskdata(JSON.stringify(condition)));
  try {
    return invalidOtpCheck.update(
      updateData,
      {
        where: condition,
      },
    );
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | updateOtpCount catch | error | ${errorFormat(err)}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    throw error;
  }
};

const getData = (sqlQuery, leadData) => {
  const logger = new Logger('getData Service', leadData.leadId);
  logger.debug(`sqlQuery | ${sqlQuery}`);
  try {
    return lead.sequelize.query(
      sqlQuery,
      {
        replacements: leadData,
        type: lead.sequelize.QueryTypes.SELECT,
      },
    );
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | getData catch | error | ${errorFormat(err)}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    throw error;
  }
};


module.exports = {
  fecthOtpStatus,
  createOtpStatus,
  updateOtpCount,
  getData,
};
