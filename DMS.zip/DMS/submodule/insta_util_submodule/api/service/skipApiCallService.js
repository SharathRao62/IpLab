
const Sequelize = require('sequelize');
const { master_skip_apis_config: masterSkipApiConfig, lead } = require('../../../../models');
const Logger = require('../../utils/logger');

const environment = process.env.NODE_ENV || 'development';
const { STATUS_CODE, ERROR_CODE } = require('../../../insta_constants_submodule/constants/constant');
const { errorFormat } = require('../..//utils/errorFormat');
const { maskdata } = require('../../utils/logMasking');

const { Op } = Sequelize;


const fetchMasterSkipApiConfig = async (param) => {
  const logger = new Logger('fetchMasterSkipApiConfig Service', maskdata(JSON.stringify(param)));
  try {
    const condition = {
      mobile_no: `${param.mobile_no}`,
      email_id: `${param.email_id}`,
      pan: `${param.pan}`,
      product_id: { [Op.like]: `%${param.product_id}%` },
      api_name: { [Op.like]: `%${param.apiName}%` },
      is_active: 1,
      environment: { [Op.like]: `%${environment}%` },
    };
    const configRes = await masterSkipApiConfig.findOne({
      attributes: ['mobile_no', 'email_id', 'pan', 'user_ip', 'start_date', 'end_date', 'is_account_creation'],
      where: condition,
      raw: true,
    });
    logger.debug(`product_id | ${param.product_id} | Result: ${maskdata(JSON.stringify(configRes))}`);
    return configRes;
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | fetchMasterSkipApiConfig catch | error | ${errorFormat(err)}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    return error;
  }
};

const getUserData = (sqlQuery, replacements) => {
  const logger = new Logger('getUserData Service', replacements);
  logger.debug(`sqlQuery | ${sqlQuery}`);
  try {
    return lead.sequelize.query(
      sqlQuery,
      {
        replacements,
        type: lead.sequelize.QueryTypes.SELECT,
      },
    );
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | getUserData catch | error | ${errorFormat(err)}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    return error;
  }
};

module.exports = {
  fetchMasterSkipApiConfig,
  getUserData,
};
