const { DIFM_JOURNEY } = require('../../../insta_constants_submodule/constants/constant');
const { decrypt256 } = require('../../utils/encryptDecryptAES256');
const Logger = require('../../utils/logger')
const leadService = require('./leadService')


const DifmJourneyIdCheck = async(leadId, journeyId)=>{
    const logger = new Logger(`journeyIdCheck - leadId ${leadId}-`);

    if(!journeyId){
        const leadData = await leadService.getJouneyId(leadId);
        logger.debug(`leadData | ${JSON.stringify(leadData)}`);
        journeyId = leadData[0].journey_id || '';
    }
    logger.debug(`journeyId | ${journeyId}`);
    
    if(DIFM_JOURNEY.JOURNEY_ID === journeyId.toUpperCase()){
        return true;
    }
    return false;

}

const getAge = (dob)=>{
    const today = new Date();
    const birthDate = new Date(dob);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;

}

const fetchAge = async(leadId)=>{
    const logger = new Logger(`ageCheck |DIFM JOURNEY | lead-${leadId}`)
    const query = `select p.dob,p.age from person p join role r on r.lead_id= p.lead_id and r.person_id=p.person_id JOIN master_role mr ON mr.id = r.role_code AND role_name='PRIMARY' where p.lead_id ='${leadId}' LIMIT 1`
    const personData = await leadService.getALLDetails(query)
    logger.debug(`personData - ${JSON.stringify(personData)}`)
    const dob_data = personData[0].dob || null;
    let age_data = personData[0].age || null
    let age = null
    try {
        const dob = dob_data && (await decrypt256(dob_data)).decryptedData;
        age_data = age_data && (await decrypt256(age_data)).decryptedData;
        logger.debug(`age_data - ${age_data},dob -${dob}`) 
        age = age_data   
        if(!age_data || age_data === null){
            age = getAge(dob);
        } 
         
    } catch (error) {
        logger.error(`error in decrypting dob ${JSON.stringify(error)}`)
    }
    return age;    
}


const masterJourneyRelation = async(leadId, tableAlias)=>{
    const logger = new Logger(`masterJourneyRelation |DIFM JOURNEY | leadId, ${leadId}`);
    
    let journeyId;
    const journeyData = await leadService.getJouneyId(leadId);
    logger.info(`journeyData | ${JSON.stringify(journeyData)}`);
    journeyId = journeyData[0].journey_id || '';

    let productId;
    const productData = await leadService.getProductId(leadId);
    logger.info(`productData | ${JSON.stringify(productData)}`);
    productId = productData[0].account_type || '';

    let condition;
    if(journeyId){
        condition = `${tableAlias}.journey_id = '${journeyId}'`;
        logger.info(`condition`, `${condition}`);
    }else if(!journeyId && productId){
        condition = `${tableAlias}.product_id = '${productId}' AND ${tableAlias}.journey_id IS NULL`;
        logger.info(`condition`, `${condition}`);
    }
    return condition;
}

module.exports = {
    DifmJourneyIdCheck,
    fetchAge,
    masterJourneyRelation,
}