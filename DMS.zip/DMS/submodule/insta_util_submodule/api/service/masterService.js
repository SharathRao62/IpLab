const Logger = require('../../utils/logger');
const { master_religion: masterReligion, master_caste: masterCaste, products } = require('../../../../models');
const Sequelize = require('sequelize');
const { Op } = Sequelize;
const {SERVICE_METHOD} = require('../../../insta_constants_submodule/constants/constantLogger');



const getReligionId = (condition) => {
  const logger = new Logger('getReligionId');
  logger.debug(`condition | ${condition}`);
  return masterReligion.findOne({
    attributes: ['id'],
    where: condition,
    raw: true,
  }).catch((error) => Promise.reject(error));
};

const getCasteId = (condition) => {
  const logger = new Logger('getCasteId');
  logger.debug(`condition | ${condition}`);
  return masterCaste.findOne({
    attributes: ['id'],
    where: condition,
    raw: true,
  }).catch((error) => Promise.reject(error));
};

// 209585 Panchami Journeywise
const getProductName = (condition) => {
  const logger = new Logger('getProductName', `${SERVICE_METHOD}`);
  logger.info(`condition | ${JSON.stringify(condition)}`);
  return products.findOne({
    attributes: ['product_id'],
    where: condition,
    raw: true,

  });
};


module.exports = {
  getReligionId,
  getCasteId,
  getProductName,
};
