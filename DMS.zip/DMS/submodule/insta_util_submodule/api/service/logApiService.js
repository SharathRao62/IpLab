/* eslint-disable no-param-reassign */
/* eslint-disable no-lonely-if */
/* eslint-disable consistent-return */
/* eslint-disable max-len */
const Logger = require('../../utils/logger');

const logger = new Logger();
const { auth, role } = require('../../../../models');
const datdecryptAES256 = require('../../utils/encryptDecryptAES256');
const { maskdata } = require('../../utils/logMasking');
const { mask } = require('../../utils/logMasking');
const CONSTANTS = require('../../../../constants/constant');

const insertUpdateTable = async (tableData, request, status, response = null, responseCode, logRequest = true) => {
  if (logRequest) {
    logger.debug(` LOG TABLE REQUEST ${JSON.stringify(request)} `);
  } else {
    logger.debug(` LOG TABLE REQUEST`);
  }
  let encMob;
  logger.debug(` TABLE DATA ${(JSON.stringify(tableData))} `);
  if (tableData && tableData.lead_id && (!tableData.person_id || tableData.person_id === '')) {
    const result = await role.findOne({
      attributes: ['person_id'],
      where: {
        lead_id: tableData.lead_id,
      },
      raw: true,
    });
    logger.debug(` TABLE DATA PERSON ID ${maskdata(JSON.stringify(result))}`);
    if (result && result.person_id) {
      tableData.person_id = result.person_id;
    }
  }

  if (tableData.logReplace && tableData.logReplace.searchValue && tableData.logReplace.replaceValue) {
    const jsonString = JSON.stringify(request);
    const maskedString = jsonString.replace(tableData.logReplace.searchValue, tableData.logReplace.replaceValue);
    request = JSON.parse(maskedString);
  }

  const reqPayload = {};
  let encryptRequest;
  let insertDataForlogTableQuery;
  const logData = { status };
  if (response && response !== '') {
    const encryptResponse = (await datdecryptAES256.encrypt256(JSON.stringify(response))).encryptedData;
    if (status) {
      // if there is a multiple hit, based on createdtime it updates to the wrong row, hence update condition is kept based on id.
      // id column of log table should be tablename_id
      insertDataForlogTableQuery = `UPDATE ${tableData.tableName} SET response =:response ,api_response_code =:responseCode,status=:status where lead_id ='${tableData.lead_id}'`;
    } else {
      insertDataForlogTableQuery = `UPDATE ${tableData.tableName} SET response =:response ,api_response_code =:responseCode where lead_id ='${tableData.lead_id}'`;
    }

    // Check service_type to avoid updation in wrong row
    if(tableData && tableData.service_type) {
      insertDataForlogTableQuery += ` and service_type='${tableData.service_type}'`;
    }
    // Order by condition
    insertDataForlogTableQuery += ` ORDER BY ${tableData.tableName}_id DESC limit 1`;

    if (tableData && tableData.isEotpTable && !tableData.enableLogStore) {
      logData.response = null;
    } else {
      logData.response = encryptResponse;
    }
    logData.responseCode = responseCode;
  } else {
    const dateVal = new Date();
    if (tableData && tableData.isSensitive) {
      reqPayload.data = request;
      if (request && reqPayload && reqPayload.data && reqPayload.data.OTP) {
        reqPayload.data.OTP = mask(reqPayload.data.OTP);
      }
      if (request && reqPayload && reqPayload.data && reqPayload.data.aadharOtp) {
        reqPayload.data.aadharOtp = mask(reqPayload.data.aadharOtp);
      }
      encryptRequest = (await datdecryptAES256.encrypt256(JSON.stringify(reqPayload.data))).encryptedData;
    } else {
      encryptRequest = (await datdecryptAES256.encrypt256(JSON.stringify(request))).encryptedData;
    }
    if (tableData && tableData.mobile_no) {
      if (!tableData.service_type) {
        if (typeof tableData.mobile_no === 'object') {
          encMob = (await datdecryptAES256.encrypt256(JSON.stringify(tableData.mobile_no))).encryptedData;
        } else {
          encMob = (await datdecryptAES256.encrypt256(tableData.mobile_no)).encryptedData;
        }
        insertDataForlogTableQuery = `INSERT INTO ${tableData.tableName} (lead_id,request,person_id,mobile_no,source,status,createdTime,updatedTime) 
        VALUES ('${tableData.lead_id}',:request,:person_id,:mobile_no, :source,:status,:createdTime,:updatedTime)`;
        logData.mobile_no = encMob;
      } else {
        if (typeof tableData.mobile_no === 'object') {
          encMob = (await datdecryptAES256.encrypt256(JSON.stringify(tableData.mobile_no))).encryptedData;
        } else {
          encMob = (await datdecryptAES256.encrypt256(tableData.mobile_no)).encryptedData;
        }
        insertDataForlogTableQuery = `INSERT INTO ${tableData.tableName} (lead_id,request,person_id,mobile_no,source,service_type,status,createdTime,updatedTime) 
        VALUES ('${tableData.lead_id}',:request,:person_id,:mobile_no,:source,:service_type,:status,:createdTime,:updatedTime)`;
        logData.mobile_no = encMob;
      }
    } else {
      if (!tableData.service_type) {
        insertDataForlogTableQuery = `INSERT INTO ${tableData.tableName} (lead_id,request,person_id,source,status,createdTime,updatedTime) 
        VALUES ('${tableData.lead_id}',:request,:person_id,:source,:status,:createdTime,:updatedTime)`;
      } else {
        insertDataForlogTableQuery = `INSERT INTO ${tableData.tableName} (lead_id,request,person_id,source,service_type,status,createdTime,updatedTime) 
        VALUES ('${tableData.lead_id}',:request,:person_id,:source,:service_type,:status,:createdTime,:updatedTime)`;
      }
    }
    if (tableData && tableData.isEotpTable && !tableData.enableLogStore) {
      logData.request = null;
    } else {
      logData.request = encryptRequest;
    }
    logData.person_id = tableData.person_id;
    logData.source = tableData.source;
    logData.service_type = tableData.service_type;
    logData.createdTime = dateVal;
    logData.updatedTime = dateVal;
  }
    if (logRequest) {
      logger.debug(` LOG DATA ${maskdata(JSON.stringify(logData))} | QUERY | insertDataForlogTableQuery | ${JSON.stringify(insertDataForlogTableQuery)}`);
    } else {
      logger.debug(` LOG DATA | QUERY | insertDataForlogTableQuery |`);
    }
    try {
    return auth.sequelize.query(
      insertDataForlogTableQuery,
      {
        replacements: logData,
        type: auth.sequelize.QueryTypes.INSERT,
      },
    ).catch((error) => {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} |LOG API SERVICE | LOG TABLE DATA INSERT UPDATE  | catch | error | ${JSON.stringify(error)} | ${error}`);
    });
  } catch (err) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} |LOG API SERVICE | LOG TABLE DATA INSERT UPDATE  | catch | error | ${JSON.stringify(err)} | ${err}`);
  }
};

module.exports = {
  insertUpdateTable,
};
