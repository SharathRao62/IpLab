/* eslint-disable camelcase */
const Logger = require('../../utils/logger');

const logger = new Logger();
const { internal_api_status: internalApiStatusFlag } = require('../../../../models');
const {
  ENTERING_TO,
  SERVICE_METHOD,
} = require('../../../insta_constants_submodule/constants/constantLogger.js');
const {
  STATUS_CODE,
} = require('../../../insta_constants_submodule/constants/constant.js');
const { maskdata } = require('../../utils/logMasking');
const CONSTANTS = require('../../../../constants/constant');


const insertOrUpdateInternalApiStatusFlag = (data) => {
  const maskData = maskdata(JSON.stringify(data));
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} insertOrUpdateInternalApiStatusFlag | lead id | ${data.lead_id} | data | ${maskData}`);
  try {
    const columns = ['id', 'lead_id'];
    return internalApiStatusFlag.findOne({
      attributes: columns,
      where: {
        lead_id: data.lead_id,
        api_name: data.api_name,
      },
      order: [['id', 'DESC']],
      raw: true,
    }).then((logData) => {
      logger.debug(`insertOrUpdateInternalApiStatusFlag | lead id | ${data.lead_id} | logData | ${JSON.stringify(logData)} `);
      if (logData && logData.id) {
        logger.debug(`insertOrUpdateInternalApiStatusFlag | lead id | ${data.lead_id} |  Update `);
        return internalApiStatusFlag.update(
          { flag: data.flag },
          {
            where: {
              lead_id: logData.lead_id,
              id: logData.id,
            },
            order: [['id', 'DESC']],
            limit: 1,
            raw: true,
          },
        );
      }
      logger.debug(`insertOrUpdateInternalApiStatusFlag | lead id | ${data.lead_id} |  Create `);
      return internalApiStatusFlag.create(data).catch((error) => error);
    }).then((value) => {
      logger.debug(`insertOrUpdateInternalApiStatusFlag | lead id | ${data.lead_id} |  value | ${JSON.stringify(value)} `);
      if (!value[0] && (!value || !value.id)) {
        logger.debug(`insertOrUpdateInternalApiStatusFlag | lead id | ${data.lead_id} | not updated`);
        return { status: STATUS_CODE.INTERNAL_ERROR };
      }
      return { status: STATUS_CODE.SUCCESS };
    });
  } catch (err) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | INTERNAL API STATUS FLAG SERVICE |insertOrUpdateInternalApiStatusFlag | lead id | ${data.lead_id} |  catch | error | ${JSON.stringify(err)} | ${err}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR, error: `error  ${err}` };
    return error;
  }
};

const fetchInternalApistatusflag = (lead_id, api_name, product_name) => {
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} | fetchInternalApistatusflag | lead_id | ${lead_id} | api_name | ${api_name} | product_name | ${product_name}`);
  const condition = { lead_id, api_name };
  logger.debug(`fetchInternalApistatusflag | lead_id | ${lead_id} | condition | ${JSON.stringify(condition)}`);
  return internalApiStatusFlag.findAll({
    where: condition,
    raw: true,
  });
};

module.exports = {
  insertOrUpdateInternalApiStatusFlag, fetchInternalApistatusflag,
};
