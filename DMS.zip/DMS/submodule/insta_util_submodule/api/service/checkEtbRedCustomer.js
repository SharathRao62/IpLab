/* eslint-disable array-callback-return */
/* eslint-disable no-async-promise-executor */
/* eslint-disable consistent-return */
/* eslint-disable prefer-promise-reject-errors */
/* eslint-disable camelcase */
const sequelize = require('sequelize');
const { STATUS_CODE, FLAGES_VALUE } = require('../../../insta_constants_submodule/constants/constant');
const { lead_attribute: leadAttribute } = require('../../../../models');
const { ENTERING_TO, SERVICE_METHOD, ERROR_MESSAGE } = require('../../../insta_constants_submodule/constants/constantLogger');
const Logger = require('../../../insta_util_submodule/utils/logger');

const { Op } = sequelize;

const leadAttributeService = (attributes, condition, leadId) => {
  const logger = new Logger(`leadAttributeService | leadId- ${leadId}`);
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} | leadAttributeService`);
  try {
    return leadAttribute.findAll({
      attributes,
      raw: true,
      where: condition,
    });
  } catch (error) {
    return (STATUS_CODE.INTERNAL_ERROR);
  }
};


const isEtbRedCustomer = (leadId) => new Promise(async (resolve, reject) => {
  const logger = new Logger(`getLeadAttributesData |lead - ${leadId}`);
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} | getLeadAttributesData`);

  const attributesName = [
    FLAGES_VALUE.ETB_OR_NTB,
    FLAGES_VALUE.KYC_COLOR_CODE_FLAG,
  ];
  try {
    const attributes = ['attribute_name', 'attribute_value'];
    const condition = {
      lead_id: leadId,
      attribute_name: { [Op.in]: attributesName },
    };
    logger.debug(`attributes | ${JSON.stringify(attributes)}`);
    return leadAttributeService(attributes, condition, leadId)
      .then((result) => {
        const data = {};
        let etb_customer = false;
        if (result && result != null) {
          result.map((response) => {
            data[response.attribute_name] = Number(response.attribute_value);
          });
        }

        if (data[FLAGES_VALUE.KYC_COLOR_CODE_FLAG] === 1 && data[FLAGES_VALUE.ETB_OR_NTB] === 2) {
          etb_customer = true;
        }
        resolve(etb_customer);
      });
  } catch (err) {
    reject({ status: STATUS_CODE.INTERNAL_ERROR, error: ERROR_MESSAGE.VKYC_INTERNAL_SERVER_ERROR });
  }
});

const checkNtbEtbRed = (leadId) => new Promise((resolve, reject) => {
  const logger = new Logger(`checkNtbEtbRed |lead - ${leadId} ::`);
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} | checkNtbEtbRed`);

  const attributesName = [
    FLAGES_VALUE.ETB_OR_NTB,
    FLAGES_VALUE.KYC_COLOR_CODE_FLAG,
  ];
  try {
    const attributes = ['attribute_name', 'attribute_value'];

    const condition = {
      lead_id: leadId,
      attribute_name: { [Op.in]: attributesName },
    };

    logger.debug(`attributes | ${JSON.stringify(attributes)}`);

    return leadAttributeService(attributes, condition, leadId)
      .then((result) => {
        const data = {};
        let etb_red = false;
        let is_ntb = false;
        if (result && result != null) {
          result.map((response) => {
            data[response.attribute_name] = Number(response.attribute_value);
          });
        }

        if (data[FLAGES_VALUE.KYC_COLOR_CODE_FLAG] === 1 && data[FLAGES_VALUE.ETB_OR_NTB] === 2) {
          etb_red = true; //etb red customer 
        }
        if(data[FLAGES_VALUE.ETB_OR_NTB] === 1){
          is_ntb = true // ntb customer 
        }
        if(etb_red || is_ntb) {
          return resolve(true);
        }
        return resolve(false);
      });

  } catch (error) {
    logger.error(`Error Occured :: ${JSON.stringify(error)}`)
    return reject(STATUS_CODE.INTERNAL_ERROR)
  }

})
const checkEtbNtbCustomer = (leadId)=>{
  const logger = new Logger(`checkEtbNtbCustomer |lead - ${leadId}`);
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} | checkEtbNtbCustomer`);
  const attributesName = [
    FLAGES_VALUE.ETB_OR_NTB,
  ];
  try {
    const attributes = ['attribute_value'];
    const condition = {
      lead_id: leadId,
      attribute_name : attributesName,
    };
    return leadAttributeService(attributes, condition, leadId)
    .then((res)=>{
      logger.debug(`res ${JSON.stringify(res)}`);
      const status = res[0]?.attribute_value || 0;
      return Number(status);
    })
  } catch (error) {
    logger.error(`Error Occured :: ${JSON.stringify(error)}`)
    return null;
  }

}

module.exports = {
  isEtbRedCustomer,
  checkNtbEtbRed,
  checkEtbNtbCustomer,
};
