/* eslint-disable eqeqeq */
/* eslint-disable max-len */
/* eslint-disable camelcase */
const { VKYC_STATUS } = require('../../../insta_constants_submodule/constants/constant');
const CONSTANTS = require('../../../insta_constants_submodule/constants/constant');
const { ENTERING_TO, SERVICE_METHOD } = require('../../../insta_constants_submodule/constants/constantLogger');
const Logger = require('../../../insta_util_submodule/utils/logger');
const checkEtbRedCustomer = require('./checkEtbRedCustomer');
const leadAttribute = require('./eventTrackerService');
const leadCommonService = require('../../../insta_util_submodule/api/service/leadService');
const systemConfig = require('../../utils/systemConfigUtils');
const leadService = require('./leadService');
const leadAttributeService = require('../service/checkEtbRedCustomer');
const vkycService = require('../../../insta_savings_submodule/utils/vkycService');

const fetchIsAccountRegularizedValue = async (isEtbCheck, leadId) => {
  const logger = new Logger(`fetchIsAccountRegularizedValue|leadId-${leadId}`);
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD}`);
  let isAccountRegularizedValue = 0;
  let kyc_code = false
  try {
    const vkycData = await vkycService.getAgentAuditorData(leadId)
    logger.info(`vkycData received - ${JSON.stringify(vkycData)}`)
    const agent_approval = vkycData?.vkyc_redirection_status || null
    const auditor_approval = vkycData?.auditor_approval || null

    logger.info(`Data received - agent_approval:${agent_approval} | auditor_approval :${auditor_approval}`)
    const leadData = await leadCommonService.getJouneyId(leadId)
    logger.info(`journeyIdcheck |leadData| - ${JSON.stringify(leadData)}`)
    const journeyId = leadData[0]?.journey_id || '';
    const etbNtbStatus = await checkEtbRedCustomer.checkEtbNtbCustomer(leadId)
    logger.info(`etbNtbStatus |- ${etbNtbStatus}`)
    if(journeyId == CONSTANTS.ETB_JOURNEY){
      kyc_code = true
    }

    let productId;
    const productData = await leadService.getProductId(leadId);
    logger.info(`productData | ${JSON.stringify(productData)}`);
    productId = productData[0].account_type || '';

    let product_name;
    const productNameData = await leadService.getProductName(productId);
    logger.info(`productNameData | ${JSON.stringify(productNameData)}`);
    product_name = productNameData[0].product_name || '';

    // if (isEtbCheck) {
    //   const isEtbRedCustomer = await checkEtbRedCustomer.isEtbRedCustomer(leadId);
    //   logger.info(`isEtbRedCustomer check - ${isEtbRedCustomer}`)
    //   kyc_code = isEtbRedCustomer ? isEtbRedCustomer : kyc_code;
    // }

    const systemConfigurations = await systemConfig.fetchMultipleSystemConfigurations(product_name, [CONSTANTS.SYS_CONF.ENABLE_FETCH_ACCOUNT_REGULARIZED_VALUE], journeyId);
    logger.debug(`systemConfigurations | ${JSON.stringify(systemConfigurations)}`);

    if (systemConfigurations && systemConfigurations.ENABLE_FETCH_ACCOUNT_REGULARIZED_VALUE) {
      logger.info(`INSIDE ENABLE_FETCH_ACCOUNT_REGULARIZED_VALUE`);

      if (auditor_approval && auditor_approval == VKYC_STATUS.APPROVED) {
        isAccountRegularizedValue = 8;
      } else if (auditor_approval && (auditor_approval == VKYC_STATUS.REJECTED || auditor_approval == VKYC_STATUS.NOT_APPROVED || auditor_approval == VKYC_STATUS.NOT_APPROVED_2)) {
        isAccountRegularizedValue = 7;
      } else if (agent_approval && agent_approval == VKYC_STATUS.SUCCESSFUL) {
        isAccountRegularizedValue = 4;
      } else if (agent_approval && agent_approval == VKYC_STATUS.REJECTED) {
        isAccountRegularizedValue = 5;
      } else if (agent_approval && ((agent_approval == VKYC_STATUS.UNABLE) || (agent_approval == VKYC_STATUS.REOPEN))) {
        isAccountRegularizedValue = 6;
      }
    }
    else {
      if (agent_approval && agent_approval == VKYC_STATUS.REJECTED) {
        isAccountRegularizedValue = 1;
      } else if (agent_approval && agent_approval == VKYC_STATUS.SUCCESSFUL) {
        isAccountRegularizedValue = 2;
      } else if (agent_approval && ((agent_approval == VKYC_STATUS.UNABLE) || (agent_approval == VKYC_STATUS.REOPEN))) {
        isAccountRegularizedValue = 3;
      }
    }
    logger.debug(`|isAccountRegularizedValue |${isAccountRegularizedValue}|kyc_code|${kyc_code}`);
    let personId

    personId = await leadCommonService.fetchPrimaryPersonId(leadId)
    logger.info(`personId fetch successfully - ${personId}`)

    const attribute_data = {
      attribute_name: 'ACCOUNT_REGULARIZED_VALUE',
      attribute_value: isAccountRegularizedValue,
      lead_id: leadId,
      person_id: personId || ''
    }
    await leadAttribute.createEventTrackerLog(attribute_data).then();
  } catch (error) {
    logger.error(`Some error occured in fetchIsAccountRegularizedValue |error| ${JSON.stringify(error)}`)
  }
  return {
    isAccountRegularizedValue,
    kyc_code,
  }
};

module.exports = {
  fetchIsAccountRegularizedValue,
};
