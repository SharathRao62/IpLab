const { lead_consent } = require("../../../../models");
// const { ENTERING_TO, SERVICE_METHOD } = require('../../constants/constantLogger');
const { maskdata } = require('../../../../submodule/insta_util_submodule/utils/logMasking');
const { STATUS_CODE } = require('../../../insta_constants_submodule/constants/constant');


const saveData = (createData, logger) => {

    logger.info(` ENTERING TO SERVICE saveData in leadConsentService ${maskdata(JSON.stringify(createData))}`);
    return lead_consent.create(createData)

};

const insertorupdateLeadConsent = (conditon, updateData, newData, logger) => {
    logger.info('insertorupdateLeadConsent', conditon.lead_id);
    try {

        return lead_consent.findOne({
            where: conditon,
            order: [['lead_consent_id', 'DESC']],
            raw: true,
        }).then(async (logData) => {

            if (logData && logData.lead_consent_id) {
                logger.debug('Update');
                return lead_consent.update(
                    { consent_value: updateData.consent_value }, // Updating the consent_value only
                    {
                        where: {
                            lead_consent_id: logData.lead_consent_id,
                        },
                    },
                );
            }
            logger.debug('Create');
            await saveData(newData, logger);
        });
    } catch (error) {

        logger.error(`LEAD_CONSENT SERVICE | catch | error | ${JSON.stringify(error)} | ${error}`);
        const err = { status: STATUS_CODE.INTERNAL_ERROR, error, retry: true };
        return Promise.reject(err);
    }
};

module.exports = {
    saveData,
    insertorupdateLeadConsent
};