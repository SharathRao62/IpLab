/* eslint-disable no-else-return */
const Logger = require("../../utils/logger");

const logger = new Logger();
const { master_ucj_access_token } = require("../../../../models");
const {
  ENTERING_TO,
  SERVICE_METHOD,
} = require("../../../insta_constants_submodule/constants/constantLogger");

const getAccessData = (apiKey, apiSecret, value) => {
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getAccessData`);
  return master_ucj_access_token.findOne({
    attributes: value,
    where: {
      apiKey,
      apiSecret,
    },
    raw: true,
  });
};

module.exports = {
  getAccessData,
};
