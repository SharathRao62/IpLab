const Logger = require('../../utils/logger');

const logger = new Logger();
const { external_api_status: apiStatusFlag, role, } = require('../../../../models');
const {
  ENTERING_TO,
  SERVICE_METHOD,
} = require('../../../insta_constants_submodule/constants/constantLogger.js');
const {
  STATUS_CODE,
} = require('../../../insta_constants_submodule/constants/constant.js');
const { maskdata } = require('../../utils/logMasking');
const CONSTANTS = require('../../../../constants/constant');

const insertOrUpdateApiStatusFlag = (data) => {
  const maskData = maskdata(JSON.stringify(data));
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} | data | ${maskData}`);
  try {
    const columns = ['id', 'lead_id'];
    return apiStatusFlag.findOne({
      attributes: columns,
      where: {
        lead_id: data.lead_id,
        api_name: data.api_name,
      },
      order: [['id', 'DESC']],
      raw: true,
    }).then(async (logData) => {
      logger.debug(`insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} | logData | ${JSON.stringify(logData)} `);
      if (logData && logData.id) {
        logger.debug(`insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} |  Update `);
        const updateData = {
          flag: data.flag,
          retry_count:data.retry_count?data.retry_count:0,
        }
        return apiStatusFlag.update(
          updateData,
          {
            where: {
              lead_id: logData.lead_id,
              id: logData.id,
            },
            order: [['id', 'DESC']],
            limit: 1,
            raw: true,
          },
        );
      }
      logger.debug(`insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} |  Create `);

      if(data && (!data.person_id || data.person_id === '')) {
        const result = await role.findOne({
          attributes: ['person_id'],
          where: {
            lead_id: data.lead_id,
          },
          raw: true,
        });
        logger.debug(`insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} | ${maskdata(JSON.stringify(result))}`);
        if(result && result.person_id) {
          data.person_id = result.person_id;
        }
      }
      return apiStatusFlag.create(data).catch((error) => error);
    }).then((value) => {
      logger.debug(`insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} |  value | ${JSON.stringify(value)} `);
      if (!value[0] && (!value || !value.id)) {
        logger.debug(`insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} | not updated`);
        return { status: STATUS_CODE.INTERNAL_ERROR };
      }
      return { status: STATUS_CODE.SUCCESS };
    });
  } catch (err) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | API STATUS FLAG | insertOrUpdateApiStatusFlag | lead id | ${data.lead_id} |  catch | error | ${JSON.stringify(err)} | ${err}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR, error: `error  ${err}` };
    return error;
  }
};

const fetchApistatusflag = (leadId, apiName, productName) => {
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} | fetchApistatusflag | lead_id | ${leadId} | api_name | ${apiName} | product_name | ${productName}`);
  const condition = {
    lead_id: leadId,
    api_name: apiName,
  };

  logger.debug(`fetchApistatusflag | lead_id | ${leadId} | condition | ${JSON.stringify(condition)}`);
  return apiStatusFlag.findAll({
    where: condition,
    raw: true,
  });
};

module.exports = {
  insertOrUpdateApiStatusFlag, fetchApistatusflag,
};
