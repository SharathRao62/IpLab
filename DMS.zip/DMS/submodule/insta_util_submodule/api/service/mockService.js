const Logger = require('../../utils/logger');
const logger = new Logger();
const {ENTERING_TO, SERVICE_METHOD} = require('../../../insta_constants_submodule/constants/constantLogger.js');
const { mock_data_config } = require('../../../../models');
const Sequelize = require('sequelize');

const getALLDetails = (sqlQuery, leadData) => {
    logger.debug(`getALLDetails |  leadData | ${(JSON.stringify(leadData))}`);
    return mock_data_config.sequelize.query(
      sqlQuery,
      {
        replacements: leadData,
        type: mock_data_config.sequelize.QueryTypes.SELECT,
      },
    ).catch((error) => {
        logger.error(`etALLDetails | error | ${JSON.stringify(error)} ${error}`);
        return error;
    });
  };

const getMockConfig = (data) => {
    logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} getMockConfig`);
    return mock_data_config
        .findOne({
            where: {
                api_name:data.api_name,
                product:data.product,
                mobile_no:data.mobile_no,
                is_enabled:1,
                env: {
                    [Sequelize.Op.like]: `%${data.env}%`
                }
            },
            raw: true,
        })
        .catch((error) => {
            logger.error(`MOCK CONFIG SERVICE ERROR | error | ${JSON.stringify(error)} ${error}`);
            return error;
        });
  };

  module.exports = {getALLDetails,getMockConfig};