/* eslint-disable camelcase */
const Logger = require('../../utils/logger');

const logger = new Logger();
const {
  master_error_code: fetchErrorCode, log_error_code: logErrorCodes, role,
} = require('../../../../models');
const {
  ENTERING_TO,
  SERVICE_METHOD,
} = require('../../../insta_constants_submodule/constants/constantLogger');
const { maskdata } = require('../../utils/logMasking');

const fetchDataFromErrorCodeTable = (error) => {
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} FETCH ALL ERROR | error | ${error}`);
  return fetchErrorCode.findAll({
    where: error,
    raw: true,
  });
};


const createLogError = async (logData) => {
  logger.debug(`${ENTERING_TO} ${SERVICE_METHOD} createLogError | lead id | ${logData.lead_id} | logData | ${JSON.stringify(logData)}`);

  if(logData && (!logData.person_id || logData.person_id === '')) {
    const result = await role.findOne({
      attributes: ['person_id'],
      where: {
        lead_id: logData.lead_id,
      },
      raw: true,
    });
    logger.debug(`createLogError | lead id | ${logData.lead_id} | ${maskdata(JSON.stringify(result))}`);
    if(result && result.person_id) {
      logData.person_id = result.person_id;
    }
  }
  return logErrorCodes.create(logData).catch((error) => error);
};

module.exports = {
  fetchDataFromErrorCodeTable, createLogError,
};
