/* eslint-disable camelcase */
/* eslint-disable no-param-reassign */
/* eslint-disable prefer-promise-reject-errors */
/* eslint-disable consistent-return */
/* eslint-disable max-len */
const { compress } = require('compress-json');
const Logger = require('../../utils/logger');

const { maskdata } = require('../../utils/logMasking');
const { mask } = require('../../utils/logMasking');
const CONSTANTS = require('../../../insta_constants_submodule/constants/constant');
const { publishMessage } = require('../../utils/gcpPubSubTopic');
const { errorFormat } = require('../../utils/errorFormat');
const CONSTATNTS = require('../../../insta_constants_submodule/constants/constant');
const zlib = require('zlib');
const systemConfig = require('../../utils/systemConfigUtils');

module.exports.eventLogs = async (leadDetail, tableData, request, status = null, response = null, logRequest = true) => {
  const type = response ? 'RESPONSE' : 'REQUEST';

  const logger = new Logger(`eventLogs ${type}`, tableData.lead_id, tableData.tableName);
  const logData = {};

  try {
    if (logRequest) {
      logger.debug(`tableData ${(JSON.stringify(tableData))} leadDetail ${JSON.stringify(leadDetail)} REQUEST ${(JSON.stringify(request))} RESPONSE ${JSON.stringify(response)} `);
    } else {
      logger.debug(`tableData ${(JSON.stringify(tableData))} leadDetail ${JSON.stringify(leadDetail)} REQUEST `);
    }

    const configurationName = [CONSTATNTS.SYS_CONF.ENABLE_GZIP_LOGS];
    const configStatus = await systemConfig.fetchMultipleSystemConfigurations(tableData.productName, configurationName);
    logger.debug(`configuration status | ${JSON.stringify(configStatus)}`);

    let reqPayload = {};
    let encryptRequest;
    const dateVal = new Date();

    if (response && response !== '') {
      try {
        if (configStatus && configStatus.ENABLE_GZIP_LOGS) {
          if (typeof response === 'object')
            response = JSON.stringify(response);

          logData.response = zlib.gzipSync(Buffer.from(response), 'utf-8');
        } else {
          logData.response = compress(response);
        }
      } catch (error) {
        if (JSON.parse(response).error) {
          if (configStatus && configStatus.ENABLE_GZIP_LOGS) {
            logData.response = zlib.gzipSync(Buffer.from(response), 'utf-8');
          } else {
            logData.response = compress(response.error);
          }
        }
      }
      logData.response_timestamp = dateVal;
    } else {
      if (tableData && tableData.isSensitive) {
        reqPayload.data = request;
        if (reqPayload && reqPayload.data.OTP) {
          reqPayload.data.OTP = mask(reqPayload.data.OTP);
        }
        if (configStatus && configStatus.ENABLE_GZIP_LOGS) {
          if (typeof reqPayload === 'object')
            reqPayload = JSON.stringify(reqPayload);

          encryptRequest = zlib.gzipSync(Buffer.from(reqPayload), 'utf-8');
        } else {
          encryptRequest = compress(reqPayload);
        }
      } else {

        if (logRequest) {
          logger.debug(`REQUEST ${(JSON.stringify(request))} leadDetail`);
        } else {
          logger.debug(`REQUEST leadDetail`);
        }

        try {
          if (configStatus && configStatus.ENABLE_GZIP_LOGS) {
            if (typeof request === 'object')
              request = JSON.stringify(request);
            encryptRequest = zlib.gzipSync(Buffer.from(request), 'utf-8');
          } else {
            encryptRequest = compress(request);
          }
        } catch (error) {
          encryptRequest = request;
        }
      };
      logData.request = encryptRequest;
      logData.person_id = tableData.person_id;
      logData.source = tableData.source;
      logData.page = tableData.page;
      logData.request_timestamp = dateVal;
    }
    if(tableData.mode) {
      logData.table_name = tableData.tableName + tableData.mode;
    } else {
      logData.table_name = tableData.tableName;
    }

    logData.mobile_no = tableData.mobile_no;
    logData.account_type = tableData.productName;

    if (leadDetail && leadDetail[0]) {
      logData.application_no = leadDetail[0].application_no;
      logData.person_id = tableData.person_id ? tableData.person_id : leadDetail[0].person_id;
      logData.mobile_no = tableData.mobile_no ? tableData.mobile_no: leadDetail[0].mobile_personal;
    }

    if (tableData.lead_id) {
      if (tableData.isEotpTable) {
        logData.txn_id = tableData.lead_id;
      } else {
        logData.lead_id = tableData.lead_id;
      }
    }

    if (tableData.functional_response) {
      logData.functional_response = tableData.functional_response;
    }
    if (tableData.track_id) {
      logData.track_id = tableData.track_id;
    }
/*     if (tableData.status) {
      logData.status = tableData.status;
    } */
    if (status==CONSTATNTS.FAILED) {
      logData.status = status;
    }
    for (const key in logData) {
      if (!logData[key]) {
        logger.debug(`null check key ${key}`);
        delete logData[key];
      } 
    }

    if (logRequest) {
      logger.debug(` LOG DATA ${(JSON.stringify(logData))} | QUERY | insertDataForlogTableQuery`);
    } else {
      logger.debug(` LOG DATA  | QUERY | insertDataForlogTableQuery`);
    }
    
    return publishMessage(JSON.stringify(logData), logger, logRequest).then((res) => {
      logger.debug(`Publisher result ${(JSON.stringify(res))} `);
      return Promise.resolve(true);
    }).catch((error) => {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | LOG API SERVICE | Pub sub catch | error | ${errorFormat(error)}`);
      return Promise.reject(true);
    });

    // only if not using pub/sub
    // restAPICall({
    //   method: API_TYPE.POST,
    //   url: environConfig.EVENT_LOGS,
    //   headers: {},
    //   body: logData,
    //   json: true,
    //   resolveWithFullResponse: true,
    // })
  } catch (error) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} |LOG API SERVICE | LOG DATA INSERT UPDATE ${logRequest ? JSON.stringify(logData) : ""}  | catch | error | ${errorFormat(error)}`);
    return Promise.reject(true);
  }
};
