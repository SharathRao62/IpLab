/* eslint-disable no-async-promise-executor */
const Logger = require('../../utils/logger');

const logger = new Logger();
const apiStatusFlagService = require('../service/apiStatusFlagService');
const eventTrackerService = require('../service/eventTrackerService');


const {
  STATUS_CODE, ERR_MESSAGE,
} = require('../../../insta_constants_submodule/constants/constant');

/**
 *
 * @param {object: {
  * api_name: string,
  * lead_id: string,
  * mobile_no: string,
  * flag: integer,
  * }} flagData
  */

const addApiStatusFlagBusiness = (flagData) => new Promise(async (resolve) => {
  logger.debug(`ENTERING TO BUSSINESS LOGIC | addApiStatusFlagBusiness | lead id | ${flagData.lead_id} | flagData | ${JSON.stringify(flagData)}`);

  if (!flagData.lead_id || !flagData.api_name) {
    logger.debug(`addApiStatusFlagBusiness | Request Parameters missing | lead id | ${flagData.lead_id} | flagData | ${JSON.stringify(flagData)}`);
    const error = {
      status: STATUS_CODE.BAD_REQUEST,
      error: ERR_MESSAGE.ADD_INTERNAL_API_STATUS_FLAG_REQUEST_PARAMETERS_NOT_PRESENT,
    };
    return Promise.reject(error);
  }
  const eventData = {
    event_code: flagData.api_name,
  };
  logger.debug(`addInternalApiStatusFlagBusiness | lead id | ${flagData.lead_id} | api_name | ${flagData.eventCode}`);
  const isApiExist = await eventTrackerService.validateEventCode(eventData);
  logger.debug(`addApiStatusFlagBusiness | lead id | ${flagData.lead_id} | isApiExist | ${isApiExist}`);
  if (isApiExist && isApiExist[0]) {
    const addInternalApiStatusFlagResult = await apiStatusFlagService.insertOrUpdateApiStatusFlag(
      flagData,
    );
    logger.debug(`addApiStatusFlagBusiness | lead id | ${flagData.lead_id} | addInternalApiStatusFlagResult | ${JSON.stringify(addInternalApiStatusFlagResult)}`);
    return resolve(addInternalApiStatusFlagResult);
  }
  logger.debug(`addApiStatusFlagBusiness | Request Parameters missing | lead id | ${flagData.lead_id} | api_name | ${flagData.api_name}`);
  const error = {
    status: STATUS_CODE.INTERNAL_ERROR, error: ERR_MESSAGE.API_NAME_NOT_PRESENT,
  };
  return Promise.reject(error);
});

module.exports = { addApiStatusFlagBusiness };
