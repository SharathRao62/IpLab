/* eslint-disable max-len */
const Logger = require('../../utils/logger');

const systemConfig = require('../../utils/systemConfigUtils');
const invalidOtpValidationService = require('../service/invalidOtpValidationService');
const decryptData = require('../../utils/decryptTableData');
const { maskdata } = require('../../utils/logMasking');

const {
  STATUS_CODE, ERROR_CODE,
} = require('../../../insta_constants_submodule/constants/constant');
const CONSTANTS = require('../../../insta_constants_submodule/constants/constant');

/**
 *
 * @param {string} mobileNo // mandatory if leadId is not present
 * @param {string} transId // mandatory
 * @param {string} leadId // not mandatory
 * @param {string} secondaryContact // not mandatory
 * @param {string} product // mandatory if leadId is not present
 * @param {string} source // not mandatory but preferred
 * @returns true for user hardstop | false for user to proceed | status: 500 if any other errors
 */
const invalidOtpValidationCheck = async (mobileNo, transId, leadId, secondaryContact, product, source) => {
  const logger = new Logger('INVALID OTP VALIDATION CHECK', leadId, `mobile | ${maskdata(mobileNo)}`);

  try {
    let data = [];
    if (!transId) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | Mandatory details not found | transId | ${transId}`);
      return { status: STATUS_CODE.INTERNAL_ERROR };
    }

    if (leadId) {
      const sqlQuery = `SELECT pr.product_name, c.email_personal, c.mobile_personal FROM \`lead\` l 
      join products pr on l.account_type=pr.product_id
      join contact c on l.lead_id=c.lead_id
      where l.lead_id= :leadId`;

      data = await invalidOtpValidationService.getData(sqlQuery, { leadId });
      logger.debug(`get data | ${JSON.stringify(data)}`);

      if (!data || !data[0] || (data && data.status === STATUS_CODE.INTERNAL_ERROR)) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | USER DATA NOT FETCHED | ${data} | ${data[0]}`);
        return { status: STATUS_CODE.INTERNAL_ERROR };
      }

      const decryptedData = await decryptData.decryptTableData(data[0]);
      data[0] = decryptedData;
    }

    const mobileNumber = mobileNo || data[0].mobile_personal;
    const secondaryContactDetail = secondaryContact || (data && data[0] && data[0].email_personal) || null;
    const accountType = product || (data && data[0] && data[0].product_name) || null;

    const systemConfigurations = await systemConfig.fetchMultipleSystemConfigurations(accountType, [CONSTANTS.SYS_CONF.ENABLE_INVALID_OTP_VALIDATOR_CHECK]);
    logger.debug(`systemConfigurations | ${JSON.stringify(systemConfigurations)}`);

    if (!systemConfigurations.ENABLE_INVALID_OTP_VALIDATOR_CHECK) {
      logger.debug('Invalid Otp validator check disables | return false');
      return false;
    }

    const condition = {
      mobile_no: mobileNumber,
      trans_id: transId,
      account_type: accountType,
    };

    const timer = new Date().getTime();
    const createData = {
      mobile_no: mobileNumber,
      secondary_contact_detail: secondaryContactDetail,
      trans_id: transId,
      account_type: accountType,
      invalid_otp_count: 1,
      source,
      timer,
    };

    logger.debug(`condition | ${JSON.stringify(maskdata(condition))}`);
    const otpStatus = await invalidOtpValidationService.fecthOtpStatus(condition);
    logger.debug(`otpStatus | ${JSON.stringify(otpStatus)}`);

    if (!otpStatus) {
      logger.debug(`otpStatus is null | createData | ${JSON.stringify(maskdata(createData))}`);
      await invalidOtpValidationService.createOtpStatus(createData);
      logger.debug('createtpStatus success | return false');
      return false;
    }

    const updateData = {
      invalid_otp_count: otpStatus.invalid_otp_count + 1,
      timer,
    };
    logger.debug(`updateData | ${JSON.stringify(updateData)}`);

    logger.debug(`updateOtpCount | id | ${otpStatus.id}`);
    const updateInvalidOtpStatus = await invalidOtpValidationService.updateOtpCount(updateData, { id: otpStatus.id });

    if (otpStatus && otpStatus.invalid_otp_count && otpStatus.invalid_otp_count >= 2) {
      logger.debug('Block user for invalid otps');
      logger.debug(`updateOtpCount | ${updateInvalidOtpStatus} | return true`);
      return true;
    }

    logger.debug(`updateOtpCount | ${updateInvalidOtpStatus} | return false`);
    return false;
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | catch error | ${error} | ${JSON.stringify(error)}`);
    return { status: STATUS_CODE.INTERNAL_ERROR };
  }
};


/**
 *
 * @param {string} mobileNo // mandatory
 * @param {string} product // mandatory
 * @returns true for user hardstop | false for user to proceed | status: 500 if any other errors
 */
const invalidOtpValidationCheckForGenerate = async (mobileNo, product) => {
  const logger = new Logger('INVALID OTP VALIDATION CHECK FOR GENERATE OTP', maskdata(mobileNo), `product | ${(product)}`);

  try {
    if (!mobileNo || !product) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | Mandatory details not found`);
      return { status: STATUS_CODE.INTERNAL_ERROR };
    }

    const systemConfigurations = await systemConfig.fetchMultipleSystemConfigurations(product, [CONSTANTS.SYS_CONF.ENABLE_INVALID_OTP_VALIDATOR_CHECK]);
    logger.debug(`systemConfigurations | ${JSON.stringify(systemConfigurations)}`);

    if (!systemConfigurations.ENABLE_INVALID_OTP_VALIDATOR_CHECK) {
      logger.debug('Invalid Otp validator check disables | return false');
      return false;
    }

    const condition = {
      mobile_no: mobileNo,
      account_type: product,
    };

    logger.debug(`condition | ${JSON.stringify(maskdata(condition))}`);
    const otpStatus = await invalidOtpValidationService.fecthOtpStatus(condition);
    logger.debug(`otpStatus | ${JSON.stringify(otpStatus)}`);

    if (otpStatus && otpStatus.timer && otpStatus.invalid_otp_count && otpStatus.invalid_otp_count >= 3) {
      logger.debug('Invalid Otp Count >= 3');

      const invalidOtpTimeLimit = await systemConfig.fetchSystemConfig({ configName: CONSTANTS.SYS_CONF.INVALID_OTP_VALIDATOR_LIMIT });
      logger.debug(`invalidOtpTimeLimit | ${JSON.stringify(invalidOtpTimeLimit)}`);

      const sysTimer = Number(invalidOtpTimeLimit.data.value);
      logger.debug(`sysTimer | ${JSON.stringify(sysTimer)}`);
      const currentTimer = new Date().getTime();
      logger.debug(`currentTimer | ${JSON.stringify(currentTimer)}`);

      const maxTimeLimit = Number(otpStatus.timer) + sysTimer;
      logger.debug(` Max Time Limit | ${maxTimeLimit}`);
      const minTimeLimit = Number(otpStatus.timer) - sysTimer;
      logger.debug(` Min Time Limit | ${minTimeLimit}`);

      if (currentTimer > minTimeLimit && currentTimer < maxTimeLimit) {
        logger.debug('Generate OTP within time limit | Block the user');
        return true;
      }
      logger.debug('Generate OTP after time limit | Allow the user');
      return false;
    }
    logger.debug('Generate OTP | Invalid OTP < 3 | Allow the user');
    return false;
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | catch error | ${error} | ${JSON.stringify(error)}`);
    return { status: STATUS_CODE.INTERNAL_ERROR };
  }
};

module.exports = {
  invalidOtpValidationCheck,
  invalidOtpValidationCheckForGenerate,
};
