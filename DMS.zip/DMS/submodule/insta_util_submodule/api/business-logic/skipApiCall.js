/* eslint-disable eqeqeq */
/* eslint-disable max-len */
/* eslint-disable no-async-promise-executor */
const dateFormat = require('dateformat');
const Logger = require('../../utils/logger');

const systemConfig = require('../../utils/systemConfigUtils');
const masterSkipApiConfigService = require('../service/skipApiCallService.js');
const decryptData = require('../../utils/decryptTableData');
const internalApiStatusFlagBusiness = require('./internalApiStatusFlagBusiness');
const datdecryptAES256 = require('../../utils/encryptDecryptAES256');
const { maskdata } = require('../../utils/logMasking');

const {
  STATUS_CODE, ERR_MESSAGE, ERROR_CODE, SYS_CONF, EVENT_CODE,
} = require('../../../insta_constants_submodule/constants/constant');


/**
 *
 * @param {string} leadId
 * @param {string} apiName
 * @param {string} product
 * @param {object {mobileNo, emailId, pan, userIp}} data
 * @returns
 */
const skipApiCall = (leadId, apiName, product, data, journeyId = null) => new Promise(async (resolve) => {
  const logger = new Logger('SKIP API CALL FOR CLIENT TESTING', leadId, `api name | ${apiName} | mobile | ${maskdata(data ? data.mobileNo : null)}`);
  let sqlQuery1;
  logger.debug(`data | ${maskdata(JSON.stringify(data))}`);
  logger.info(`journeyId | ${journeyId}`);

  const configurationName = [SYS_CONF.ENABLE_SKIP_OF_APIS];
  const configStatus = await systemConfig.fetchMultipleSystemConfigurations(product, configurationName, journeyId);
  logger.debug(`configuration status | ${JSON.stringify(configStatus)}`);
  logger.info(`journeyId | ${journeyId}`);

  if (configStatus && configStatus.ENABLE_SKIP_OF_APIS) {
    logger.debug(`configuration status enabled | ${configStatus.ENABLE_SKIP_OF_APIS}`);
    if (leadId) {
      sqlQuery1 = `SELECT c.mobile_personal, c.email_personal, p.pan_no, l.account_type, l.user_ip FROM \`lead\` l 
      left join pan p on p.lead_id=l.lead_id
      join contact c on c.lead_id=l.lead_id
      where l.lead_id= :leadId`; // added left join for pan for multiple account case as the generate lead is a dummy lead and pan will have no data during the initial call
    } else {
      sqlQuery1 = `SELECT product_id FROM products 
      where product_name= :productName`;
    }
    logger.debug(`sqlQuery1 | ${sqlQuery1}`);

    const userData = await masterSkipApiConfigService.getUserData(sqlQuery1, { leadId, productName: product });
    logger.debug(`get user Data | ${JSON.stringify(userData)}`);

    if (!userData || !userData[0] || (userData && userData.status === STATUS_CODE.INTERNAL_ERROR)) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | USER DATA NOT FETCHED | ${userData} ${userData[0]}`);
      const res = {
        isSkip: 'error',
        status: STATUS_CODE.SKIP_API_CALL_INTERNAL_ERROR,
        msg: ERR_MESSAGE.SKIP_API_CALL_INTERNAL_ERROR,
        error: ERR_MESSAGE.SKIP_API_CALL_INTERNAL_ERROR,
      };
      return resolve(res);
    }

    userData[0] = await decryptData.decryptTableData(userData[0]);
    logger.debug(`get user data decrypted | ${maskdata(JSON.stringify(userData[0]))}`);

    const userDetails = {
      mobile_no: leadId ? userData[0].mobile_personal : data.mobileNo,
      email_id: leadId ? userData[0].email_personal : data.emailId,
      pan: leadId ? userData[0].pan_no : data.pan,
      product_id: leadId ? userData[0].account_type : userData[0].product_id,
      apiName,
    };
    const getMasterDetails = await masterSkipApiConfigService.fetchMasterSkipApiConfig(userDetails);
    logger.debug(`getMasterDetails | ${getMasterDetails} ${maskdata(JSON.stringify(getMasterDetails))}`);

    if (!getMasterDetails) {
      logger.debug(`API SKIP DETAILS NOT FOUND | ${getMasterDetails} | Api call skip status FALSE`);
      return resolve({ isSkip: false });
    }

    if (getMasterDetails && (getMasterDetails.status === STATUS_CODE.INTERNAL_ERROR || !getMasterDetails.user_ip || !getMasterDetails.start_date || !getMasterDetails.end_date)) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | Mandatory details not fetched or internal error | ${getMasterDetails.status} | ${getMasterDetails.user_ip} | ${getMasterDetails.start_date} | ${getMasterDetails.end_date}`);
      const res = {
        isSkip: 'error',
        status: STATUS_CODE.SKIP_API_CALL_INTERNAL_ERROR,
        msg: ERR_MESSAGE.SKIP_API_CALL_INTERNAL_ERROR,
        error: ERR_MESSAGE.SKIP_API_CALL_INTERNAL_ERROR,
      };
      return resolve(res);
    }

    const userIpArr = getMasterDetails.user_ip.split(',').map((a) => a.trim());
    const userIp = leadId ? userData[0].user_ip : data.userIp;
    const ipCheck = userIpArr.includes(userIp);
    logger.debug(`ipCheck status | ${ipCheck}`);
    if (!ipCheck) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | USER IP DID NOT MATCH WITH MASTER IP CONFIG`);
      const res = {
        isSkip: 'error',
        status: STATUS_CODE.SKIP_API_CALL_USERIP_MISMATCH,
        msg: ERR_MESSAGE.SKIP_API_CALL_USERIP_MISMATCH,
        error: ERR_MESSAGE.SKIP_API_CALL_USERIP_MISMATCH,
      };
      return resolve(res);
    }

    const date = new Date();
    const today = dateFormat(date, 'yyyy-mm-dd');
    logger.debug(`Today's Date | ${today}`);
    logger.debug(`Master details start date : ${getMasterDetails.start_date} | Master details end date : ${getMasterDetails.end_date}`);
    if (today < getMasterDetails.start_date || today > getMasterDetails.end_date) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | START AND END DATE DID NOT MATCH WITH MASTER DATES CONFIG`);
      const res = {
        isSkip: 'error',
        status: STATUS_CODE.SKIP_API_CALL_DATE_MISMATCH,
        msg: ERR_MESSAGE.SKIP_API_CALL_DATE_MISMATCH,
        error: ERR_MESSAGE.SKIP_API_CALL_DATE_MISMATCH,
      };
      return resolve(res);
    }

    if (leadId) {
      const apiStatusFlagData = {
        api_name: EVENT_CODE.API_CALL_SKIP,
        lead_id: leadId,
        mobile_no: (await datdecryptAES256.encrypt256(userData[0].mobile_personal)).encryptedData,
        flag: 1,
      };
      const updateInternalStatus = await internalApiStatusFlagBusiness.addInternalApiStatusFlagBusiness(apiStatusFlagData);
      logger.debug(`updateInternalStatus | ${updateInternalStatus}`);
      apiStatusFlagData.api_name = EVENT_CODE.IS_ACCOUNT_CREATION;
      apiStatusFlagData.flag = getMasterDetails.is_account_creation;
      const updateInternalAccountCreationStatus = await internalApiStatusFlagBusiness.addInternalApiStatusFlagBusiness(apiStatusFlagData);
      logger.debug(`updateInternalAccountCreationStatus | ${updateInternalAccountCreationStatus}`);
    }

    logger.debug(`Api call skip status | ${configStatus.ENABLE_SKIP_OF_APIS}`);
    return resolve({ isSkip: true });
  }

  logger.debug(`Api call skip status | ${configStatus.ENABLE_SKIP_OF_APIS}`);
  return resolve({ isSkip: false });
});

module.exports = { skipApiCall };
