/* eslint-disable consistent-return */
/* eslint-disable max-len */
/* eslint-disable no-async-promise-executor */
const Logger = require('../../utils/logger');

// const logger = new Logger();
const eventTrackerService = require('../service/eventTrackerService');
// const internalApiStatusFalg = require('./internalApiStatusFlagBusiness');
// const apiStatusFalg = require('./apiStatusFlagBusiness');
const datdecryptAES256 = require('../../utils/encryptDecryptAES256');
const leadService = require('../service/leadService');
const CONSTANTS = require('../../../../constants/constant');
const {
  STATUS_CODE,
} = require('../../../insta_constants_submodule/constants/constant');

const insertIntoEventTracker = async (inputData) => {
  const logger = new Logger('insertIntoEventTracker', 'inputdata', `${inputData}`);
  const {
    eventCode, value, mob, lead,
  } = inputData;
  const eventData = {
    event_code: eventCode,
  };
  logger.debug(`EVENT CODE | ${JSON.stringify(eventData)}`);

  const validateData = await eventTrackerService.validateEventCode(eventData);
  logger.debug(`validateData | ${JSON.stringify(validateData)}`);

  if (validateData && validateData[0]) {
    const personColumn = ['person_id'];
    const condition = {
      lead_id: lead,
    };
    const getPersonData = await leadService.getPersonData(personColumn, condition, 1);
    logger.debug(`getPersonData | ${JSON.stringify(getPersonData)}`);
    const insertData = {
      attribute_name: eventCode,
      attribute_value: value,
      person_id: getPersonData && getPersonData[0] && getPersonData[0].person_id ? (getPersonData[0].person_id) : null,
    };
    logger.debug(`insertData | ${JSON.stringify(insertData)}`);
    if (lead) {
      insertData.lead_id = lead;
    } else if (mob) {
      insertData.mobile_no = (await datdecryptAES256.encrypt256(mob)).encryptedData;
    }
    const insertedResponse = await eventTrackerService.createEventTrackerLog(insertData);

    if (!insertedResponse) {
      return { status: STATUS_CODE.INTERNAL_ERROR };
    }
    return { status: STATUS_CODE.SUCCESS };
  }
  return { status: STATUS_CODE.INTERNAL_ERROR };
};


// eslint-disable-next-line no-unused-vars

/**
 *
 * @param {string} eventCode
 * @param {string} value
 * @param {string} addToOtherTable
 * @param {string} mob
 * @param {string} lead
 * returns 200 in case of sucess else returns 500
 */
const addEvent = (eventCode, value, addToOtherTable, mob, lead) => new Promise(async (resolve, reject) => {
  const logger = new Logger('ADD EVENT', 'lead', 'BUSINESS METHOD');

  try {
    logger.debug(`mobOrLead | ${mob} | ${lead}`);
    const inputData = {
      eventCode,
      value,
      mob,
      lead,
    };
    logger.debug(`INPUT DATA | ${JSON.stringify(inputData)}`);
    const responseData = await insertIntoEventTracker(inputData);
    logger.debug(`RESPONSE DATA | ${JSON.stringify(responseData)}`);
    if (!responseData || (responseData && responseData.status === STATUS_CODE.INTERNAL_ERROR)) {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} EVENT TRACKER | RESPONSE DATA NOT FOUND OR ERROR RESPONSE | ${JSON.stringify(responseData)}`);
      const err = { status: STATUS_CODE.INTERNAL_ERROR };
      reject(err);
    }
    if (!addToOtherTable) {
      logger.debug(`UPDATE DATA TO EVENT TRACKER | ${JSON.stringify(addToOtherTable)}`);
      if (responseData && responseData.status === STATUS_CODE.SUCCESS) {
        logger.debug(`UPDATE DATA TO EVENT TRACKER SUCCESS | ${JSON.stringify(responseData)}`);
        return resolve({ status: STATUS_CODE.SUCCESS });
      }
      const err = { status: STATUS_CODE.INTERNAL_ERROR };
      reject(err);
    }
    return resolve({ status: STATUS_CODE.SUCCESS });
  } catch (e) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} EVENT TRACKER | CATCH ERROR | ${JSON.stringify(e)}`);
    reject(e);
  }
});

module.exports = { addEvent };
