/* eslint-disable camelcase */
/* eslint-disable no-async-promise-executor */
/* eslint-disable max-len */
const Logger = require('../../utils/logger');
const masterService = require('../service/masterService');

const {
  STATUS_CODE, ERR_MESSAGE,
} = require('../../../insta_constants_submodule/constants/constant');

const fetchIdForReligion = (religion, productId) => new Promise(async (resolve, regect) => {
  const logger = new Logger('fetchIdForReligion');
  logger.debug(`religion | ${JSON.stringify(religion)} | prductId | ${productId}`);
  if (!religion || !productId) {
    logger.debug('Request Parameters missing');
    const error = { status: STATUS_CODE.BAD_REQUEST, error: ERR_MESSAGE.BAD_REQUEST };
    regect(error);
  }
  const condition = {
    religions: religion,
    product_id: productId,
  };
  const fetchRegionId = masterService.getReligionId(condition);
  logger.debug(`fetchRegionId result | ${JSON.stringify(fetchRegionId)}`);
  resolve(fetchRegionId);
});

const fetchIdForCaste = (caste, productId) => new Promise(async (resolve, regect) => {
  const logger = new Logger('fetchIdForCaste');
  logger.debug(`religion | ${JSON.stringify(caste)} | prductId | ${productId}`);
  if (!caste || !productId) {
    logger.debug('Request Parameters missing');
    const error = { status: STATUS_CODE.BAD_REQUEST, error: ERR_MESSAGE.BAD_REQUEST };
    regect(error);
  }
  const condition = {
    caste,
    product_id: productId,
  };
  const fetchCasteId = masterService.getCasteId(condition);
  logger.debug(`fetchRegionId result | ${JSON.stringify(fetchCasteId)}`);
  resolve(fetchCasteId);
});

module.exports = {
  fetchIdForReligion,
  fetchIdForCaste,
};
