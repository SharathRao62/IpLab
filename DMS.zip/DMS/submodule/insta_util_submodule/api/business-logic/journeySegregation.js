const leadService = require('../service/leadService');

const journeySegregation = async (leadId) => {
  const utmCondition = await leadService.leadFindOne(['utm_source', 'utm_product'], { lead_id: leadId });
  const utmData = await leadService.utmFindOne(['configuration_bypass'], {
    utm_source_id: utmCondition.utm_source,
    utm_product_id: utmCondition.utm_product,
  });
  const configuration = JSON.parse(utmData.configuration_bypass);
  return configuration.journeySegregation;
};

module.exports = {
  journeySegregation,
};
