/* eslint-disable no-async-promise-executor */
const Logger = require("../../utils/logger");

const logger = new Logger();

const {
  STATUS_CODE,
  ERR_MESSAGE,
} = require("../../../insta_constants_submodule/constants/constant");
const acsTknSrvc = require("../service/accessTokenService");

/**
 *
 * @param {object: {
 * apiKey: string,
 * apiSecret: string,
 * }} tokenData
 */

const accessTokenBusiness = (flagData) =>
  new Promise(async (resolve) => {
    logger.info(
      `ENTERING TO BUSSINESS LOGIC | accessTokenBusiness | flagData | ${JSON.stringify(
        flagData
      )}`
    );

    if (!flagData.apiKey || !flagData.apiSecret) {
      const error = {
        status: STATUS_CODE.BAD_REQUEST,
        error: ERR_MESSAGE.UCJ_ACCESS_TOKEN_PARAMETERS_NOT_PRESENT,
      };
      return Promise.reject(error);
    }

    const accssToken = await acsTknSrvc.getAccessData(
      flagData.apiKey,
      flagData.apiSecret,
      ["access_token"]
    );
    logger.info(
      `accessTokenBusiness  | accssToken | ${JSON.stringify(accssToken)}`
    );
    if (accssToken) {
      return resolve(accssToken);
    }
    return Promise.reject({
      status: STATUS_CODE.INTERNAL_ERROR,
      error: ERR_MESSAGE.ACCESS_TOKEN_NOT_PRESENT,
    });
  });

module.exports = { accessTokenBusiness };
