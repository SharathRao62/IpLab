const leadConsentService = require('../../api/service/leadConsentService');
const { STATUS_CODE } = require('../../../insta_constants_submodule/constants/constant');
const { errorFormat } = require("../../utils/errorFormat");
const fetchFields = require('../../../insta_cap_utils_submodule/utils/fetchFields');

class saveConsentBusiness {
  updatedPayload = {};
  constructor(redirection) {
    this.redirection = redirection;
  }


  async saveConsentData(payloadData, logger) {

    logger.info(`saveConsentData Bussiness | `, ` lead_id | `, payloadData.lead_id);

    const consentData = payloadData.data;
    logger.info(`consentData | `, consentData);

    if (!consentData || !Array.isArray(consentData)) {
      logger.info(`no consent name found | `);
      return Promise.resolve({ status: STATUS_CODE.BAD_REQUEST, error: 'No consent found Or consent is not an Array' });
    }

    let updatedPayload = {};
    updatedPayload = await fetchFields.fetchFields(payloadData);
    logger.info(`updatedPayload | ${JSON.stringify(updatedPayload)}`);

    try {
      let createOrUpdateConsentArr = []

      const mappedObjects = consentData.map((obj) => {

        if (!obj || !obj.field_name) {
          logger.info(`consent field_name not found | ${obj.field_name}`);
          return Promise.resolve(`field_name not found`);
        }

        const conditon = { lead_id: payloadData.lead_id, consent_name: obj.field_name.toUpperCase() };
        logger.info(`condition | ${JSON.stringify(conditon)}`);

        const updateData = { consent_value: obj.value == 'true' ? 1 : 0, consent_timestamp: new Date() };

        logger.info(`updateData | ${JSON.stringify(updateData)}`);
        const newData = {
          ...conditon,
          ...updateData,
        };
        logger.info(`newData | ${JSON.stringify(newData)}`);

        createOrUpdateConsentArr.push(leadConsentService.insertorupdateLeadConsent(conditon, updateData, newData, logger));
        logger.info(`inserted or updated for field name | ${obj.field_name}`);

      })

      //it will wait for all the requests to get complete.
      await Promise.all(mappedObjects);

      return Promise.resolve({ status: STATUS_CODE.SUCCESS });

    } catch (err) {
      logger.error(`error in saveConsentBusiness | ${errorFormat(err)}`);
      return {
        status: STATUS_CODE.INTERNAL_ERROR,
        error: 'CONSENT_INSERT_UPDATE_INTERNAL_ERROR'
      }
    }
  }
}

module.exports = saveConsentBusiness;