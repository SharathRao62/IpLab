/* eslint-disable eqeqeq */
/* eslint-disable max-len */
/* eslint-disable no-async-promise-executor */
const Logger = require('../../utils/logger');

const { errorFormat } = require('../../utils/errorFormat');
const apiStatusFlagService = require('../service/apiStatusFlagService');

const skipAffluentUser = async (leadId, apiName) => {
    const logger = new Logger(`skipAffluentUser | leadId | ${leadId} , ''`);
    try {
        logger.debug(`Checking apiStatusFlag for leadId | ${leadId} | apiName: ${apiName}`);
        const fetchAffluentUser = await apiStatusFlagService.fetchApistatusflag(leadId, apiName);
        logger.debug(`fetchAffluentUser | ${JSON.stringify(fetchAffluentUser)}`);
        if (fetchAffluentUser && fetchAffluentUser[0] && fetchAffluentUser[0].flag && fetchAffluentUser[0].flag === 1) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        logger.error(`Error | ${errorFormat(error)}`)
    }
};

module.exports = {
    skipAffluentUser,
}