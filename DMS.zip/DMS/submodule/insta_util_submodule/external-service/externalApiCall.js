/* eslint-disable no-lonely-if */
/**
 * Copyright - Copyright © Niveus Solution Private Limited - All Rights Reserved
 *
 * Proprietary and confidential
 *
 * long description for the file
 *
 * @summary short description for the file
 * @author Rashni Poojary
 *
 * Created at     : 2022-10-09 20:03:05
 * Last modified  : 2023-11-20 11:32:59
 */

/* eslint-disable no-param-reassign */
/* eslint-disable no-async-promise-executor */
/* eslint-disable no-else-return */
/* eslint-disable consistent-return */
// const properties = require("../../../package.json");
// const restCall = properties.dependencies["request-promise"] ? require('../utils/restCalls') : require('../utils/axiosRestCalls');
const Logger = require('../utils/logger');
const logger = new Logger();
const dataEncryptDecrypt = require('../utils/encryptDecrypt');
const { generateEncrpytedPayload } = require('../utils/encryptDecryptAES256');
const restCall = require('../utils/restCalls');
const config = require('../../../config/environConfig');
const configEnc = require('../../insta_config_submodule/config/environConfig');
const { STATUS_CODE, SYS_CONF,ERR_MESSAGE } = require('../../insta_constants_submodule/constants/constant');
const CONSTANTS = require('../../insta_constants_submodule/constants/constant');
const logApiService = require('../api/service/logApiService');
const CONSTATNTS = require('../../insta_constants_submodule/constants/constant');
const { maskdata } = require('../utils/logMasking');
const { eventLogs } = require('../api/service/eventLogsService');
const systemConfigUtils = require('../utils/systemConfigUtils');
const { fetchEventLogsDetails } = require('../api/service/leadService');
const { errorFormat } = require('../utils/errorFormat');

const environment = process.env.NODE_ENV;


const resetTheData = (tableData) => {
  if (tableData && !(tableData.source)) {
    tableData.source = null;
  } else {
    tableData.source = `${tableData.source}`;
  }
  if (tableData && !(tableData.service_type)) {
    tableData.service_type = null;
  } else {
    tableData.service_type = `${tableData.service_type}`;
  }
  if (tableData && !(tableData.person_id)) {
    tableData.person_id = null;
  }
  return tableData;
};

/**
 *
 * @param {object: {
 * url: string
 * headers: object
 * isEncrypt: boolean
 * }} dataInput
 * @param {object: {
 * payload: object
 * }} externalDataVal
 * @param {object: {
 * tableData: object
 * }} tableData
 */
const extCall = async (dataInput, externalDataVal, tableData, isjson = true, mockData) => {
  const logExtData = dataInput && dataInput.logExtData === false ? false : true;
  const eventLogsEnabled = dataInput && dataInput.eventLogs === false ? false : true;
  
  const leadId = tableData && tableData.lead_id ? tableData.lead_id:null;
  const logger = new Logger(`EXTERNAL API CALL  | lead_id | ${leadId}`);
  logger.debug(`${JSON.stringify(dataInput)} | externalDataVal | ${logExtData ? JSON.stringify(externalDataVal) : ""} tableData | ${JSON.stringify(tableData)} |`);
  let headerVal;
  let env;
  let timeOut;
  let externalCallPayload = {};
  let plainData;
  let otpData;
  let aadharOtpData;
  let encryptedDataResp;
  if (externalDataVal && externalDataVal.OTP) {
    otpData = externalDataVal.OTP;
    logger.debug(`OTP DATA | ${maskdata(otpData)}`);
  }
  if (externalDataVal && externalDataVal.aadharOtp) {
    aadharOtpData = externalDataVal.aadharOtp;
    logger.debug(`AADHAAR OTP DATA | ${maskdata(aadharOtpData)}`);
  }
  if (!dataInput || !externalDataVal || !dataInput.url) {
    logger.debug('REQUIRED PARAMETER NOT PRESENT |');
    return new Promise((reject) => reject({ status: STATUS_CODE.INTERNAL_ERROR }));
  }
  if (dataInput && dataInput.headers) {
    headerVal = dataInput.headers;
  } else {
    headerVal = {
      'content-type': 'application/json',
      apikey: configEnc.API_KEY,
    };
  }

  //changes for DIFM
  if(externalDataVal.adminToken) {
    headerVal['x-auth'] = externalDataVal.adminToken;
    delete externalDataVal.adminToken;
  }
  
  logger.debug(`${JSON.stringify(dataInput)} | headerVal | ${JSON.stringify(headerVal)} |`);

  if (dataInput && dataInput.env) {
    env = dataInput.env;
  } else {
    env = environment;
  }
  logger.debug(`${JSON.stringify(dataInput)} | env | ${JSON.stringify(env)} |`);

  if (dataInput && dataInput.timeOut) {
    timeOut = dataInput.timeOut;
  } else if (dataInput && (!dataInput.timeOut || dataInput.timeOut === null || dataInput.timeOut === 'null' || dataInput.timeOut === '')) {
    timeOut = '';
  } else {
    timeOut = config.TIME_OUT;
  }
  logger.debug(`${JSON.stringify(dataInput)} | timeOut | ${JSON.stringify(timeOut)} |`);
  externalCallPayload = {
    method: dataInput.method || CONSTANTS.API_TYPE.POST,
    url: dataInput.url,
    headers: headerVal,
    body: externalDataVal,
    timeout: timeOut,
    resolveWithFullResponse: true,
  };
  if (isjson) {
    externalCallPayload.json = true;
  }

  const systemConfigurations = (await systemConfigUtils.getMultipleSysConfigData(
    'NULL', [SYS_CONF.ENABLE_DB_LOGS, SYS_CONF.ENABLE_GCP_LOGS],
  )).reduce((obj, item) => (obj[item.configuration_name] = Number(item.value), obj), {});

  logger.debug(`allSysFunc | userdata ${maskdata(JSON.stringify(systemConfigurations))}`);

  if (headerVal.ProductID) {
    tableData.productName = headerVal.ProductID;
  }
  if (dataInput && !dataInput.isEncrypt && dataInput.isPgpEncrypt) {
    const leadDetail = await fetchEventLogsDetails(tableData, headerVal);
    const PGPEncDec = require('../utils/pgp-enc-dec/pgpEncDec.js');
    const pgpEncDec = new PGPEncDec('password');

    if (tableData && dataInput.enableLogs) {
      tableData.enableLogStore = dataInput.enableLogs;
    }
    tableData = await resetTheData(tableData);
    try {
      const status = CONSTATNTS.INPROGRESS;
      if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS]) {
        logger.debug(`eventLogs ENABLE_GCP_LOGS REQUEST ${JSON.stringify(tableData)}`);
        eventLogs(leadDetail, tableData, externalDataVal, status, null, logExtData).catch(error => {
          logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);
        });
      }
      if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
        logger.info(`externalApiCall insertUpdateTable 1`);
        await logApiService.insertUpdateTable(tableData, externalDataVal, status, null, undefined, logExtData);
      }
    } catch (error) {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${JSON.stringify(error)} | ${error}`);
    }
    try {
      const payload = await pgpEncDec.encrypt(JSON.stringify(externalDataVal));
      if (logExtData) {
        logger.debug('GENERATE OTP TEST encrypted request 1', payload);
      } else {
        logger.debug('GENERATE OTP TEST encrypted request 1');
      }
      externalCallPayload.body = payload;
      if (logExtData) {
        logger.debug('GENERATE OTP TEST encrypted request 2', externalCallPayload);
      } else {
        logger.debug('GENERATE OTP TEST encrypted request 2');
      }

      if (externalCallPayload && (externalCallPayload.timeout === null || externalCallPayload.timeout === 'null' || externalCallPayload.timeout === '' || !externalCallPayload.timeout)) {
        delete externalCallPayload.timeout;
      }

      if (logExtData) {
        logger.debug(`${JSON.stringify(dataInput)} | externalCallPayload | ${SON.stringify(externalCallPayload)} |`);
      } else {
        logger.debug(`| externalCallPayload | |`);
      }

      const encryptedResponse = await restCall.restAPICall(externalCallPayload, mockData);
      
      if (logExtData) {
        logger.debug(`encryptedResponse | ${JSON.stringify(encryptedResponse)}`);
      } else {
        logger.debug(`encryptedResponse | `);
      }

      const { statusCode, body } = encryptedResponse;
      const decryptedResponse = JSON.parse(await pgpEncDec.decrypt(body));
      if (decryptedResponse) {
        decryptedResponse.responseCode = statusCode;

        if (dataInput && !dataInput.isVerify) {
          if (logExtData) {
            logger.debug(` ${JSON.stringify(dataInput)} | DECRYPTEDDD RESPONSEEE | ${logExtData ? JSON.stringify(decryptedResponse) : ""}`);
          } else {
            logger.debug(` | DECRYPTEDDD RESPONSEEE |`);
          }

        } else if (dataInput && dataInput.isVerify && dataInput.enableLogs) {
          if (logExtData) {
            logger.debug(`${JSON.stringify(dataInput)} | DECRYPTEDDD RESPONSEEE | ${JSON.stringify(decryptedResponse)}`);
          } else {
            logger.debug(`| DECRYPTEDDD RESPONSEEE |`);
          }
        }

        let returnResponse;
        try {
          // Parse it as JSON.
          returnResponse = decryptedResponse;
        } catch (error) {
          // Return raw data if it is not JSON.
          returnResponse = decryptedResponse;
        }

        if (dataInput && dataInput.enableLogs) {
          tableData.enableLogStore = dataInput.enableLogs;
        }
        try {
          if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS]) {
            logger.debug(`eventLogs ENABLE_GCP_LOGS RESPONSE ${JSON.stringify(tableData)}`);
            eventLogs(leadDetail, tableData, externalDataVal, ERR_MESSAGE.SUCCESS, decryptedResponse, logExtData).catch(error => {
              logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);
            });;
          }
          if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
            logger.info(`externalApiCall insertUpdateTable 2`);
            const result = await logApiService.insertUpdateTable(tableData, externalDataVal, ERR_MESSAGE.SUCCESS, decryptedResponse, decryptedResponse.responseCode, logExtData);
            if (tableData && tableData.isSensitive) {
              if (result[1]) {
                if (externalDataVal && externalDataVal.OTP) {
                  externalDataVal.OTP = otpData;
                }
                if (externalDataVal && externalDataVal.aadharOtp) {
                  externalDataVal.aadharOtp = aadharOtpData;
                }
              }
            }
          }
        } catch (error) {
          logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error)} | ${error}`);
        }

        if (logExtData) {
          logger.debug(`${JSON.stringify(dataInput)} | returnResponse | ${JSON.stringify(returnResponse)}`);
        } else {
          logger.debug(` returnResponse | `);
        }
        return new Promise((resolve) => resolve(returnResponse));
      }
    } catch (error) {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error)} | ${error}`);
      if (dataInput && dataInput.enableLogs) {
        tableData.enableLogStore = dataInput.enableLogs;
      }
      try {
        const statuserror = CONSTATNTS.FAILED;
        const { statusCode } = error;
        if (error && error.error && error.statusCode != 401) {
          error = JSON.parse(await pgpEncDec.decrypt(error.error));
        }
        if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS]) {
          eventLogs(leadDetail, tableData, externalDataVal, statuserror, error, logExtData).catch(error => {
            logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);;
          });
        }

        if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
          logger.info(`externalApiCall insertUpdateTable 3`);
          const result = await logApiService.insertUpdateTable(tableData, externalDataVal,
            statuserror, JSON.stringify(error), statusCode, logExtData);
          if (tableData && tableData.isSensitive) {
            if (result[1]) {
              if (externalDataVal && externalDataVal.OTP) {
                externalDataVal.OTP = otpData;
              }
              if (externalDataVal && externalDataVal.aadharOtp) {
                externalDataVal.aadharOtp = aadharOtpData;
              }
            }
          }
        }
        error.responseCode = statusCode;
      } catch (error1) {
        logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error1)} | ${error1}`);
      }
      return Promise.resolve(error);
    }
  } else if (dataInput && !dataInput.isEncrypt) {
    try {
      if (logExtData) {
        logger.debug(`${JSON.stringify(dataInput)} | externalCallPayload | ${JSON.stringify(externalCallPayload)} |`);
      } else {
        logger.debug(` | externalCallPayload | |`);
      }
      plainData = await restCall.restAPICall(externalCallPayload, mockData);
      logger.debug(`${JSON.stringify(dataInput)} | plainData | ${JSON.stringify(plainData)} |`);
      if (plainData && plainData.mock_status && plainData.data) {
        plainData = plainData.data.data;
      }
      if (plainData) {
        logger.debug(' | response | resolve');
        return new Promise((resolve) => resolve(plainData));
      } else {
        logger.debug(' response | reject');
        const error = { status: 500 };
        throw error;
      }
    } catch (eeee) {
      logger.debug(`${JSON.stringify(dataInput)} | CATCH ERROR | ${JSON.stringify(eeee)} |`);
      throw eeee;
    }
  } else {
    const leadDetail = await fetchEventLogsDetails(tableData, headerVal);

    if (tableData && dataInput.enableLogs) {
      tableData.enableLogStore = dataInput.enableLogs;
    }
    tableData = await resetTheData(tableData);
    try {
      const status = CONSTATNTS.INPROGRESS;
      if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS] && tableData.lead_id && eventLogsEnabled) {
        logger.debug(`eventLogs ENABLE_GCP_LOGS REQUEST ${JSON.stringify(tableData)}`);
        eventLogs(leadDetail, tableData, externalDataVal, status, null, logExtData).catch(error => {
          logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);
        });
      }
      if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
        logger.info(`externalApiCall insertUpdateTable 4`);
        const result = await logApiService.insertUpdateTable(tableData, externalDataVal, status, null, undefined, logExtData);
        if (tableData && tableData.isSensitive) {
          if (result[1]) {
            if (externalDataVal && externalDataVal.OTP) {
              externalDataVal.OTP = otpData;
            }
            if (externalDataVal && externalDataVal.aadharOtp) {
              externalDataVal.aadharOtp = aadharOtpData;
            }
          }
        }
      }
    } catch (error) {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${JSON.stringify(error)} | ${error}`);
    }
    try {
      if (tableData && tableData.isXml) {
        // used to encrypt xml data
        encryptedDataResp = await dataEncryptDecrypt.encryptDataXML(externalDataVal, env);
      } else {
        // used to encrypt json data
        encryptedDataResp = await dataEncryptDecrypt.encryptData(externalDataVal, env, dataInput.key, logExtData);
      }
      if (logExtData) {
        logger.debug('GENERATE OTP TEST encrypted request 1', encryptedDataResp);
      } else {
        logger.debug('GENERATE OTP TEST encrypted request 1');
      }

      const { key, data } = encryptedDataResp;
      let service = dataInput.service ? dataInput.service : '';
      const payload = await generateEncrpytedPayload(key, data, service);

      if (logExtData) {
        logger.debug('GENERATE OTP TEST encrypted request 2', payload);
      } else {
        logger.debug('GENERATE OTP TEST encrypted request 2');
      }

      externalCallPayload.body = payload;

      if (logExtData) {
        logger.debug('GENERATE OTP TEST encrypted request 3', externalCallPayload);
      } else {
        logger.debug('GENERATE OTP TEST encrypted request 3');
      }
      if (externalCallPayload && (externalCallPayload.timeout === null || externalCallPayload.timeout === 'null' || externalCallPayload.timeout === '' || !externalCallPayload.timeout)) {
        delete externalCallPayload.timeout;
      }
      if (logExtData) {
        logger.debug(`${JSON.stringify(dataInput)} | externalCallPayload | ${JSON.stringify(externalCallPayload)} |`);
      } else {
        logger.debug(` | externalCallPayload | |`);
      }
      try {
        const encryptedResponse = await restCall.restAPICall(externalCallPayload, mockData);
        if (encryptedResponse) {
          if (logExtData) {
            logger.debug(`EXTERNAL API CALL | encryptedResponse2 | ${JSON.stringify(encryptedResponse)}`);
          } else {
            logger.debug(`EXTERNAL API CALL | encryptedResponse2 |`);
          }
          let statusCode; let body; let decryptedResponse;
          if (encryptedResponse && encryptedResponse.mock_status && encryptedResponse.data) {
            statusCode = encryptedResponse.data.statusCode;
            decryptedResponse = {};
            decryptedResponse.data = encryptedResponse.data.data;
            return new Promise((resolve) => resolve(decryptedResponse.data));
          } else {
            if (encryptedResponse && encryptedResponse.statusCode && encryptedResponse.body) {
              ({ statusCode, body } = encryptedResponse);
              const { encryptedKey, encryptedData } = body;
              decryptedResponse = await dataEncryptDecrypt.decryptData(encryptedData,
                encryptedKey, env, dataInput.key);
              
              
              if (logExtData) {
                logger.debug(`EXTERNAL API CALL | decryptedResponse2 | ${JSON.stringify(decryptedResponse)}`);
              } else {
                logger.debug(`EXTERNAL API CALL | decryptedResponse2 |`);
              }

              if (decryptedResponse) {
                decryptedResponse.responseCode = statusCode;
                if (dataInput && !dataInput.isVerify) {
                  if (logExtData) {
                    logger.debug(` ${JSON.stringify(dataInput)} | DECRYPTEDDD RESPONSEEE | ${JSON.stringify(decryptedResponse)}`);
                  } else {
                    logger.debug(` | DECRYPTEDDD RESPONSEEE | `);
                  }
                } else if (dataInput && dataInput.isVerify && dataInput.enableLogs) {
                  if (logExtData) {
                    logger.debug(`${JSON.stringify(dataInput)} | DECRYPTEDDD RESPONSEEE | ${JSON.stringify(decryptedResponse)}`);
                  } else {
                    logger.debug(`| DECRYPTEDDD RESPONSEEE | `);
                  }
                }
                let returnResponse;
                if (tableData && tableData.wholeData) {
                  try {
                    // Parse it as JSON.
                    returnResponse = JSON.parse(decryptedResponse);
                  } catch (error) {
                    // Return raw data if it is not JSON.
                    returnResponse = decryptedResponse;
                  }
                } else {
                  try {
                    // Parse it as JSON.
                    returnResponse = JSON.parse(decryptedResponse.data);
                  } catch (error) {
                    // Return raw data if it is not JSON.
                    returnResponse = decryptedResponse.data;
                  }
                }

                if (dataInput && dataInput.enableLogs) {
                  tableData.enableLogStore = dataInput.enableLogs;
                }
                try {
                  if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS] && tableData.lead_id && eventLogsEnabled) {
                    logger.debug(`eventLogs ENABLE_GCP_LOGS RESPONSE ${JSON.stringify(tableData)}`);
                    eventLogs(leadDetail, tableData, externalDataVal, ERR_MESSAGE.SUCCESS, decryptedResponse.data, logExtData).catch(error => {
                      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);;
                    });
                  }
                  if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
                    logger.info(`externalApiCall insertUpdateTable 5`);
                    const result = await logApiService.insertUpdateTable(tableData, externalDataVal, '', decryptedResponse.data, decryptedResponse.responseCode, logExtData);
                    if (tableData && tableData.isSensitive) {
                      if (result[1]) {
                        if (externalDataVal && externalDataVal.OTP) {
                          externalDataVal.OTP = otpData;
                        }
                        if (externalDataVal && externalDataVal.aadharOtp) {
                          externalDataVal.aadharOtp = aadharOtpData;
                        }
                      }
                    }
                  }
                } catch (error) {
                  logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error)} | ${error}`);
                }
                
                if (logExtData) {
                  logger.debug(`${JSON.stringify(dataInput)} | returnResponse | ${JSON.stringify(returnResponse)}`);
                } else {
                  logger.debug(` | returnResponse | `);
                }
                return new Promise((resolve) => resolve(returnResponse));
              } else {
                let dataToStore;
                if (decryptedResponse) {
                  dataToStore = decryptedResponse;
                } else {
                  dataToStore = 'THIRD PARTY DECRYPTED RESPONSE NOT RECIEVED'; // add this to constants
                }
                try {
                  if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS] && tableData.lead_id) {
                    logger.debug(`eventLogs ENABLE_GCP_LOGS RESPONSE ${JSON.stringify(tableData)}`);
                    eventLogs(leadDetail, tableData, externalDataVal, CONSTATNTS.FAILED, dataToStore, logExtData).catch(error => {
                      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);
                    });
                  }
                  if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
                    logger.info(`externalApiCall insertUpdateTable 6`);
                    const result = await logApiService.insertUpdateTable(tableData, externalDataVal, '', dataToStore, STATUS_CODE.INTERNAL_ERROR, logExtData);
                    if (tableData && tableData.isSensitive) {
                      if (result[1]) {
                        if (externalDataVal && externalDataVal.OTP) {
                          externalDataVal.OTP = otpData;
                        }
                        if (externalDataVal && externalDataVal.aadharOtp) {
                          externalDataVal.aadharOtp = aadharOtpData;
                        }
                      }
                    }
                  }
                } catch (error) {
                  logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error)} | ${error}`);
                }
              }
            } else {
              let dataToStore;
              if (encryptedResponse) {
                dataToStore = encryptedResponse;
              } else {
                dataToStore = 'THIRD PARTY ENCRYPTED RESPONSE NOT RECIEVED'; // add this to constants
              }
              try {
                if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS] && tableData.lead_id) {
                  logger.debug(`eventLogs ENABLE_GCP_LOGS RESPONSE ${JSON.stringify(tableData)}`);
                  eventLogs(leadDetail, tableData, externalDataVal, CONSTATNTS.FAILED, dataToStore, logExtData).catch(error => {
                    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);;
                  }); 
                }
                if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
                  logger.info(`externalApiCall insertUpdateTable 7`);
                  const result = await logApiService.insertUpdateTable(tableData, externalDataVal, '', dataToStore, STATUS_CODE.INTERNAL_ERROR, logExtData);
                  if (tableData && tableData.isSensitive) {
                    if (result[1]) {
                      if (externalDataVal && externalDataVal.OTP) {
                        externalDataVal.OTP = otpData;
                      }
                      if (externalDataVal && externalDataVal.aadharOtp) {
                        externalDataVal.aadharOtp = aadharOtpData;
                      }
                    }
                  }
                }
              } catch (error) {
                logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error)} | ${error}`);
              }
            }
          }
        } else {
          let dataToStore;
          if (encryptedResponse) {
            dataToStore = encryptedResponse;
          } else {
            dataToStore = 'THIRD PARTY ENCRYPTED RESPONSE NOT RECIEVED'; // add this to constants
          }
          try {
            if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS] && tableData.lead_id) {
              logger.debug(`eventLogs ENABLE_GCP_LOGS RESPONSE ${JSON.stringify(tableData)}`);
              eventLogs(leadDetail, tableData, externalDataVal, CONSTATNTS.FAILED, dataToStore, logExtData).catch(error => {
                logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);;
              });
            }
            if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
              logger.info(`externalApiCall insertUpdateTable 8`);
              const result = await logApiService.insertUpdateTable(tableData, externalDataVal, '', dataToStore, STATUS_CODE.INTERNAL_ERROR, logExtData);
              if (tableData && tableData.isSensitive) {
                if (result[1]) {
                  if (externalDataVal && externalDataVal.OTP) {
                    externalDataVal.OTP = otpData;
                  }
                  if (externalDataVal && externalDataVal.aadharOtp) {
                    externalDataVal.aadharOtp = aadharOtpData;
                  }
                }
              }
            }
          } catch (error) {
            logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error)} | ${error}`);
          }
        }
      } catch (e) {
        logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(e)} | ${e}`);
        if (dataInput && dataInput.enableLogs) {
          tableData.enableLogStore = dataInput.enableLogs;
        }
        try {
          const statuserror = CONSTATNTS.FAILED;
          if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS] && tableData.lead_id) {
            eventLogs(leadDetail, tableData, externalDataVal, statuserror, e, logExtData).catch(error => {
              logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);;
            });
          }
          if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
            logger.info(`externalApiCall insertUpdateTable 9`);
            const result = await logApiService.insertUpdateTable(tableData, externalDataVal,
              statuserror, e, e.statusCode, logExtData);
            if (tableData && tableData.isSensitive) {
              if (result[1]) {
                if (externalDataVal && externalDataVal.OTP) {
                  externalDataVal.OTP = otpData;
                }
                if (externalDataVal && externalDataVal.aadharOtp) {
                  externalDataVal.aadharOtp = aadharOtpData;
                }
              }
            }
          }
        } catch (error1) {
          logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error1)} | ${error1}`);
        }
        throw e;
      }
    } catch (error) {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error)} | ${error}`);
      if (dataInput && dataInput.enableLogs) {
        tableData.enableLogStore = dataInput.enableLogs;
      }
      try {
        const statuserror = CONSTATNTS.FAILED;
        if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS] && tableData.lead_id) {
          eventLogs(leadDetail, tableData, externalDataVal, statuserror, error, logExtData).catch(error => {
            logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | catch | failed | ${errorFormat(error)}`);;
          });
        }

        if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS]) {
          logger.info(`externalApiCall insertUpdateTable 10`);
          const result = await logApiService.insertUpdateTable(tableData, externalDataVal,
            statuserror, JSON.stringify(error), error.statusCode, logExtData);
          if (tableData && tableData.isSensitive) {
            if (result[1]) {
              if (externalDataVal && externalDataVal.OTP) {
                externalDataVal.OTP = otpData;
              }
              if (externalDataVal && externalDataVal.aadharOtp) {
                externalDataVal.aadharOtp = aadharOtpData;
              }
            }
          }
        }
      } catch (error1) {
        logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | EXTERNAL API CALL | LOG TABLE DATA UPDATE | catch | failed | ${JSON.stringify(error1)} | ${error1}`);
      }
      // return new Promise((resolve) => resolve(error));

      return Promise.reject(error);

      // throw error;
    }
  }
};


module.exports = {
  extCall,
  resetTheData,
};
