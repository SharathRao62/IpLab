const Logger = require("../utils/logger");

const dataEncryptDecrypt = require("../utils/encryptDecrypt");
const { generateEncrpytedPayload } = require("../utils/encryptDecryptAES256");
const restCall = require("../utils/axiosRestCalls");
const config = require("../../../config/environConfig");
const configEnc = require("../../insta_config_submodule/config/environConfig");
const { STATUS_CODE, SYS_CONF, ERROR_CODE, API_TYPE } = require("../../insta_constants_submodule/constants/constant");
const CONSTANTS = require("../../insta_constants_submodule/constants/constant");
const logApiService = require("../api/service/logApiService");
const { maskdata } = require("../utils/logMasking");
const { eventLogs } = require("../api/service/eventLogsService");
const systemConfigUtils = require("../utils/systemConfigUtils");
const { fetchEventLogsDetails } = require("../api/service/leadService");
const { errorFormat } = require('../utils/errorFormat');

// Clear Undefined Fields in Table
const resetTheData = (tableData) => {
  if (tableData) {
    let { source, service_type, person_id } = tableData;
    return {
      ...tableData,
      source: source ? source : null,
      service_type: service_type ? service_type : null,
      person_id: person_id ? person_id : null,
    };
  }
  return tableData;
};

// Encrypt The Payload
const encryptPayload = async (restApiBody, encryptConfig, apikey = null) => {
  const logger = new Logger(`UTILS: EXTERNAL AXIOS API CALL | METHOD: ENCRYPT PAYLOAD`);
  try {
    let { isXml, environment } = encryptConfig;
    let restResponse = "";
    if (isXml) {
      restResponse = await dataEncryptDecrypt.encryptDataXML(restApiBody, environment);
    } else {
      restResponse = await dataEncryptDecrypt.encryptData(restApiBody, environment, apikey);
    }

    logger.debug(`Encrypted Payload | ${restResponse}`);
    const { key, data } = restResponse;
    const encryptedRequest = generateEncrpytedPayload(key, data);
    logger.debug(`Formatted Payload | ${encryptedRequest}`);
    return Promise.resolve(encryptedRequest);
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTEGRATION} | error | ${errorFormat(err)}`);
    return Promise.reject({ data: err, status: STATUS_CODE.INTERNAL_ERROR });
  }
};

// Decrypt The Response
const decryptResponse = async (encryptedResponse, status, decryptConfig = {}, key = null) => {
  const logger = new Logger(`UTILS: EXTERNAL AXIOS API CALL | METHOD: DECRYPT RESPONSE`);

  const { encryptedKey, encryptedData } = encryptedResponse;

  const { environment } = decryptConfig;

  if (encryptPayload && encryptedData) {
    let response;
    try {
      let decryptedResponse = await dataEncryptDecrypt.decryptData(encryptedData, encryptedKey, environment, key);
      logger.debug(`RESPONSE | ${JSON.stringify(decryptedResponse)}`);
      let { data } = decryptedResponse;
      if (data) {
        if (typeof data == "string") {
          let santizedData = data.replace(/[\n\r]/g, "");
          try {
            let parsedJSON = JSON.parse(santizedData);
            response = { data: parsedJSON, status };
          } catch (error) {
            logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} | catch | Unable To Parse Data | ${errorFormat(error)}`);
            response = { data: santizedData, status };
          }
        } else {
          response = { data, status };
        }
      } else {
        response = { data: decryptedResponse, status };
      }

      return response;
    } catch (err) {
      logger.error(`${ERROR_CODE.API_INTEGRATION} | catch | Error While Decrypting | ${errorFormat(err)}`);
      response = { data: err, status, message: "Error While Decrypting" };
    }
    return Promise.reject(response);
  } else {
    let response = { data: encryptedResponse, status };
    logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} | catch | Receieved Invalid Payload For Decryption | ${maskdata(encryptedResponse)}`);
    return Promise.reject(response);
  }
};

// Create/Update The Logs
const saveOrUpdateLogs = async ({ systemConfigurations, leadDetail, tableData, request, eventStatus, dbStatus, response, responseCode, logExtData }) => {
  const logger = new Logger(`UTILS: EXTERNAL AXIOS API CALL | METHOD: SAVE OR UPDATE LOGS`);

  try {
    if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS]) {
      logger.debug(` eventLogs ENABLE_GCP_LOGS REQUEST ${JSON.stringify(tableData)}`);
      eventLogs(leadDetail, tableData, request, eventStatus, response, logExtData);
    }
    if (systemConfigurations[SYS_CONF.ENABLE_DB_LOGS] && tableData && tableData.lead_id) {
      await logApiService.insertUpdateTable(tableData, request, dbStatus, response, responseCode, logExtData);
    }
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | catch | failed | ${errorFormat(error)}`);
  }
};

// Prepare The ExternalCallPayload
const prepareRestApiConfig = async (restApiConfig) => {
  const logger = new Logger(`UTILS: EXTERNAL AXIOS API CALL | METHOD: PREPARE REST API CONFIG`);

  let externalCallPayload = {};

  let { headers, timeout, url, isEncrypt, env, logExtData } = restApiConfig;

  if (!headers) {
    headers = {
      "content-type": "application/json",
      apikey: configEnc.API_KEY,
    };
  }

  if (!timeout) {
    timeout = config.TIME_OUT;
  } else if (timeout && timeout === "null") {
    timeout = "";
  }

  externalCallPayload = {
    method: API_TYPE.POST,
    url,
    headers,
    timeout,
  };

  logger.debug(`ExternalCallPayload | ${externalCallPayload}`);

  return { externalCallPayload, isEncrypt, headers, environment: env ? (env) : process.env.NODE_ENV, logExtData: [undefined, true, null].includes(logExtData)  ? true : false};
};

// Main Function
const extCall = async (restApiConfig, restApiPayload, tableData, mockData) => {
  const leadId = tableData && tableData.lead_id ? tableData.lead_id:'';
  const logger = new Logger(`UTILS: EXTERNAL AXIOS API CALL | ${leadId}`);
  const logExtData = restApiConfig && restApiConfig.logExtData === false ? false : true;
  
  if (logExtData){
    logger.debug(
      ` restApiConfig | ${JSON.stringify(maskdata(restApiConfig))} | restApiPayload | ${JSON.stringify(maskdata(restApiPayload))} | tableData | ${JSON.stringify(
        tableData
      )}`
    );
  }else{
    logger.debug(
      ` restApiConfig | ${JSON.stringify(maskdata(restApiConfig))} | restApiPayload |  | tableData |`
    );
  }
 

  if (!restApiConfig || !restApiConfig.url) {
    logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} | catch | REQUIRED PARAMETER NOT PRESENT`);
    return Promise.reject({ status: STATUS_CODE.INTERNAL_ERROR, message: "Required Parameter Not Present", data: "" });
  }

  tableData = tableData ? tableData : {};

  //Fetch System Configs
  const sysConfigs = await systemConfigUtils.getMultipleSysConfigData("NULL", [SYS_CONF.ENABLE_DB_LOGS, SYS_CONF.ENABLE_GCP_LOGS]);
  const systemConfigurations = sysConfigs.reduce((obj, item) => ((obj[item.configuration_name] = Number(item.value)), obj), {});

  //Prepare External CallPayload
  const { isEncrypt, externalCallPayload, headers, environment } = await prepareRestApiConfig(restApiConfig);

  let leadDetail;

  try {
    tableData = resetTheData(tableData);

    if (tableData && headers.ProductID) {
      tableData.productName = headers.ProductID;
    }
    leadDetail = await fetchEventLogsDetails(tableData, headers);

    //Set InProgress Status In Logs
    let status = CONSTANTS.INPROGRESS;
    let logData = {
      systemConfigurations,
      tableData,
      leadDetail,
      eventStatus: status,
      dbStatus: status,
      request: restApiPayload,
      logExtData,
    };
    await saveOrUpdateLogs(logData);

    // Payload Encryption
    if (isEncrypt) {
      let { isXml } = tableData;
      let encryptConfig = {
        isXml,
        environment,
      };
      const payload = await encryptPayload(restApiPayload, encryptConfig, tableData?.apiSpecificKey);
      externalCallPayload.body = payload;
    } else {
      externalCallPayload.body = restApiPayload;
    }

    if (logExtData) {
      logger.debug(`External Call Payload | ${maskdata(externalCallPayload)}`);
    } else {
      logger.debug(`External Call Payload | `);
    }

    //Call Third Party Api - Axios
    const response = await restCall.restAPICall(externalCallPayload, mockData);

    //Decrypt The Payload And Return Response
    let result;
    let statusCode;
    if (response) {
      let { mock_status, data, status } = response;
      if (mock_status && data) {
        if (logExtData) {
          logger.debug(`Mock Status | ${maskdata(response)}`);
        } else {
          logger.debug(`Mock Status |`);
        }
        statusCode = mock_status;
        result = { data: data.data, status: mock_status };
      } else if (status && data) {
        if (isEncrypt) {
          if (logExtData) {
            logger.debug(`Encrypted Response | ${maskdata(response)}`);
          } else {
            logger.debug(`Encrypted Response | `);
          }
          statusCode = status;

          const decryptConfig = {
            environment,
          };
          result = await decryptResponse(data, status, decryptConfig, tableData?.apiSpecificKey);
        } else {
          if (logExtData) {
            logger.debug(`Plain Response | ${maskdata(response)}`);
          } else {
            logger.debug(`Plain Response | `);
          }
          let { status } = response;
          statusCode = status;
          result = response;
        }
      }

      //Set Success Status In Logs
      status = CONSTANTS.SUCCESS;
      logData = {
        systemConfigurations,
        tableData,
        leadDetail,
        eventStatus: status,
        dbStatus: status,
        request: restApiPayload,
        response: result,
        responseCode: statusCode,
        logExtData,
      };
      await saveOrUpdateLogs(logData);
      if (logExtData) {
        logger.debug(` SUCCESS | ${JSON.stringify(result)}`);
      } else {
        logger.debug(` SUCCESS | }`);
      }

      return result;
    } else {
      logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} | catch | ERROR | RESPONSE NOT RECEIEVED`);
      const error = { status: 500, data: "", message: "Response Not Receieved From Third Party" };
      throw error;
    }
  } catch (err) {
    //Set Failed Status In Logs For Error Handling
    const status = CONSTANTS.FAILED;

    let error = {};
    logger.error(`${ERROR_CODE.API_INTERNAL} | catch | FAILED | ${errorFormat(err)}`);
    if (typeof err == "object") {
      const { status, data, message } = err;
      error = { status: status ? status : 500, message, data: data ? data : "" };
    } else {
      error = { status: STATUS_CODE.INTERNAL_ERROR, data: err };
    }

    const logData = {
      systemConfigurations,
      tableData,
      leadDetail,
      eventStatus: status,
      dbStatus: status,
      request: restApiPayload,
      response: err,
      responseCode: error.status,
      logExtData,
    };
    await saveOrUpdateLogs(logData);

    return Promise.reject(error);
  }
};

module.exports = {
  extCall,
};
