/* eslint-disable consistent-return */
/* eslint-disable no-sequences */
/* eslint-disable no-return-assign */
// eslint-disable-next-line no-return-assign, no-sequences
/* eslint-disable no-param-reassign */
const { v4: uuidv4 } = require('uuid');
const extAxiosCall = require('./externalAxiosApiCall');
const Logger = require('../utils/logger');
const environConfig = require('../../insta_config_submodule/config/environConfig');
const logApiService = require('../api/service/logApiService');
const generateApiTokenService = require('../api/service/generateApiTokenService');
const CONSTANTS = require('../../insta_constants_submodule/constants/constant');
const eventLogs = require('./eventLogs');
const encryptDecryptAES256 = require('../utils/encryptDecryptAES256');

const generateApiToken = async (data, journeyId = null) => {
  const {
    lead_id: leadId,
    person_id: personId,
    mobile_no,
    page,
    stage,
  } = data;
  let statusCode;
  let respCode;
  let errorDesc;
  let statusData;
  let response;
  const dataToCreate = { lead_id: leadId, source: data.source || 'MAIN' };
  const condition = { lead_id: leadId };
  let VRM_IVIEW_API_KEY =  environConfig.VRM_IVIEW_API_KEY; //'ksyxdWkfOOOkcDabq0Dq33BwdAtEyDRi';
  let GENERATE_API_TOKEN_SECRETKEY = environConfig.GENERATE_API_TOKEN_SECRETKEY; // 'kxtW1aHgeN4OL9As';
  let URL = environConfig.GENERATE_ACCESS_TOKEN_URL; //'https://apibankingone.icicibank.com/clientcredentials/GenerateAccessToken'; 

  if (!leadId) {
    return Promise.reject({ status: CONSTANTS.STATUS_CODE.INTERNAL_ERROR, message: 'LeadId is required' });
  }

  const logger = new Logger(`generateAccessToken | lead_id | ${leadId}`);

  try {
    const trackId = uuidv4();
    const AUTH = `Basic ${new Buffer(`${VRM_IVIEW_API_KEY}:${GENERATE_API_TOKEN_SECRETKEY}`).toString('base64')}`;

    const tableData = {
      tableName: 'log_generate_api_token',
      lead_id: leadId,
      person_id: personId || '',
      source: data.source || 'MAIN',
      service_type: '',
      track_id: trackId,
    };

    logger.debug(`TABLE DATA | ${JSON.stringify(tableData)}`);

    logger.info(`journeyId | ${journeyId}`);

    const accessTokenData = {
      url: URL,
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
        Authorization: AUTH,
        ProductID: data.product_name || '',
        ChannelID: data.CHANNEL_ID, // "UCJ-PROD",
      },
      isEncrypt: false,
      env: data.env
    };

    const payload = {
      grant_type: 'client_credentials'
    };

    const functionPayload = {
      txn_id: null,
      lead_id: leadId,
      mobile_no: mobile_no || '',
      table_name: 'log_generate_api_token',
      functional_response: CONSTANTS.SUCCESS,
      person_id: personId || '',
      status: CONSTANTS.SUCCESS,
      stage: stage || '',
      page: page || '',
      track_id: trackId,
    };

    logger.debug(`headers | ${JSON.stringify(accessTokenData)} | payload | ${JSON.stringify(payload)}`);

    response = await extAxiosCall.extCall(accessTokenData, payload, tableData, journeyId).catch(async (err) => {
      logger.error(`EXT CALL FAILED | error | ${JSON.stringify(err)}`);
      if (err && err.ERROR_DESCRIPTION && err.ERROR_CODE) {
        statusCode = CONSTANTS.FAILED;
        respCode = err.ERROR_CODE;
        errorDesc = err.ERROR_DESCRIPTION;

        functionPayload.functional_response = err.ERROR_DESCRIPTION;
        functionPayload.status = CONSTANTS.FAILED;
      } else {
        statusCode = CONSTANTS.FAILED;
        respCode = CONSTANTS.STATUS_CODE.INTERNAL_SERVER_ERROR;
        errorDesc = CONSTANTS.ERR_MESSAGE.THIRD_PARTY_ERROR;

        functionPayload.functional_response = CONSTANTS.FAILED;
        functionPayload.status = CONSTANTS.FAILED;
      }

      statusData = {
        status: statusCode,
        api_response_code: respCode,
        api_response_desc: errorDesc,
      };

      dataToCreate.request = JSON.stringify(payload);
      dataToCreate.response = JSON.stringify(response);
      dataToCreate.api_response_desc = errorDesc;
      dataToCreate.status = statusCode;
      dataToCreate.api_response_code = respCode;
      await generateApiTokenService.logGenerateApiToken(condition, statusData, dataToCreate).catch((err) => {
        logger.error(`Error while updating logGenerateApiToken | ${JSON.stringify(err)}`);
      });

      eventLogs.saveFunctionalResponse(functionPayload).catch((err) => {
        logger.error(`saveFunctionalResponse | error | ${JSON.stringify(err)}`);
      });
      return Promise.reject(err);
    });

    logger.debug(`THIRD PARTY RESPONSE | ${JSON.stringify(response)}`);
    statusCode = CONSTANTS.FAILED;
    respCode = CONSTANTS.STATUS_CODE.INTERNAL_ERROR;
    errorDesc = CONSTANTS.ERR_MESSAGE.THIRD_PARTY_ERROR;

    functionPayload.functional_response = CONSTANTS.ERR_MESSAGE.THIRD_PARTY_ERROR;
    functionPayload.status = CONSTANTS.FAILED;

    if (response && response.data && response.data.ERROR_CODE) {
      statusCode = CONSTANTS.FAILED;
      respCode = response.data.ERROR_CODE;
      errorDesc = response.data.ERROR_DESCRIPTION;

      functionPayload.functional_response = response.data.ERROR_DESCRIPTION;
      functionPayload.status = CONSTANTS.FAILED;
    } else if(response && response.data){
      statusCode = CONSTANTS.SUCCESS;
      respCode = CONSTANTS.STATUS_CODE.SUCCESS;
      errorDesc = CONSTANTS.SUCCESS;

      functionPayload.functional_response = CONSTANTS.SUCCESS;
      functionPayload.status = CONSTANTS.SUCCESS;
    }

    statusData = {
      status: statusCode,
      api_response_code: respCode,
      api_response_desc: errorDesc,
    };

    dataToCreate.request = JSON.stringify(payload);
    dataToCreate.response = JSON.stringify(response);
    dataToCreate.api_response_desc = errorDesc;
    dataToCreate.status = statusCode;
    dataToCreate.api_response_code = respCode;
    await generateApiTokenService.logGenerateApiToken(condition, statusData, dataToCreate).catch((err) => {
      logger.error(`Error while updating logGenerateApiToken | ${JSON.stringify(err)}`);
    });

    eventLogs.saveFunctionalResponse(functionPayload).catch((err) => {
      logger.error(`saveFunctionalResponse | error | ${JSON.stringify(err)}`);
    });
    return Promise.resolve(response);
  } catch (error) {
    logger.error(`CATCH ERROR | ${JSON.stringify(error)}`);
    return Promise.reject(error);
  }
};


module.exports = {
  generateApiToken,
};
