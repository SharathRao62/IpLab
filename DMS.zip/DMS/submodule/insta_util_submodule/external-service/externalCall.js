/* eslint-disable no-param-reassign */
const Logger = require('../utils/logger');
const { encryptDataXML, encryptData, decryptData } = require('../utils/encryptDecrypt');
const { generateEncrpytedPayload } = require('../utils/encryptDecryptAES256');
const restCall = require('../utils/axiosCall');
const config = require('../../../config/environConfig');
const {
  STATUS_CODE, SYS_CONF, ERR_MESSAGE, API_TYPE, ERROR_CODE, INPROGRESS, FAILED,
} = require('../../insta_constants_submodule/constants/constant');
const logApiService = require('../api/service/logApiService');
const { eventLogs } = require('../api/service/eventLogsService');
const systemConfigUtils = require('../utils/systemConfigUtils');
const { fetchEventLogsDetails } = require('../api/service/leadService');
const { errorFormat } = require('../utils/errorFormat');
const { maskdata } = require('../utils/logMasking');

const environment = process.env.NODE_ENV;

const isObjectEmpty = (object) => Object.keys(object).length === 0;

const parseData = (data) => {
  try {
    // Parse it as JSON.
    return JSON.parse(data);
  } catch (error) {
    // Return raw data if it is not JSON.
    return data;
  }
};

const resetData = (tableData) => {
  const columns = ['source', 'service_type', 'person_id'];
  columns.forEach((column) => {
    if (!Number.isInteger(tableData[column]) && !tableData[column]) {
      tableData[column] = null;
    }
  });
};

const logging = (logger, data, logData = true) => {
  if (logData) logger.debug(data);
};

const storeLogs = async (
  leadDetail,
  dataInput,
  tableData,
  externalDataVal,
  status,
  response,
  responseCode,
  sysConf,
  configs,
) => {
  const {
    eventLogsEnabled,
    logExtData,
  } = configs;

  const {
    lead_id: leadId,
  } = tableData;
  const logger = new Logger('extCall', leadId);

  try {
    if (sysConf[SYS_CONF.ENABLE_GCP_LOGS] && eventLogsEnabled) {
      logger.info('storing event logs');
      eventLogs(leadDetail, tableData, externalDataVal, status, response, logExtData)
        .catch((error) => {
          logger.error(`${ERROR_CODE.API_INTERNAL} | eventLogs | ${errorFormat(error)}`);
        });
    }

    if (sysConf[SYS_CONF.ENABLE_DB_LOGS]) {
      await logApiService
        .insertUpdateTable(
          tableData,
          externalDataVal,
          status,
          response,
          responseCode,
          logExtData,
        );
    }

  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | storeLogs | failed | ${errorFormat(error)}`);
  }
};

// eslint-disable-next-line default-param-last, no-unused-vars
const extCall = async (dataInput, externalDataVal, tableData, isjson = true, mockData) => {
  const logExtData = !(dataInput && dataInput.logExtData === false);
  const eventLogsEnabled = !(dataInput && dataInput.eventLogs === false);

  const configs = {
    logExtData,
    eventLogsEnabled,
  };

  // setting logger unique lead
  let leadId = externalDataVal.lead_id;
  leadId = tableData && tableData.lead_id ? tableData.lead_id : leadId;
  const logger = new Logger('extCall', leadId);

  logging(logger, `dataInput ${JSON.stringify(dataInput)}`, logExtData);
  logging(logger, `externalDataVal ${JSON.stringify(externalDataVal)}`, logExtData);
  logging(logger, `tableData ${JSON.stringify(tableData)}`, logExtData);

  if (
    isObjectEmpty(dataInput)
    || !externalDataVal
    || !dataInput.url
  ) {
    logger.info('Required Parameters missing');
    return Promise.reject(new Error('Required Parameters missing'));
  }

  // set headers
  const { headers } = dataInput;

  // set tokens - not required pass in headers after checking the code
  if (externalDataVal.adminToken) {
    headers['x-auth'] = externalDataVal.adminToken;
    delete externalDataVal.adminToken;
  }

  // set environment
  const env = dataInput.env || environment;

  // set timeout
  const timeOut = dataInput.timeOut || config.TIME_OUT;

  // set method
  const method = dataInput.method || API_TYPE.POST;

  // prepare request
  const externalCallPayload = {
    method,
    url: dataInput.url,
    headers,
    body: externalDataVal,
    timeout: timeOut,
    resolveWithFullResponse: true,
  };

  // temp fix
  let otpData;
  let aadharOtpData;
  if (externalDataVal && externalDataVal.OTP) {
    otpData = externalDataVal.OTP;
    logger.debug(`OTP DATA | ${maskdata(otpData)}`);
  }
  if (externalDataVal && externalDataVal.aadharOtp) {
    aadharOtpData = externalDataVal.aadharOtp;
    logger.debug(`AADHAAR OTP DATA | ${maskdata(aadharOtpData)}`);
  }
  // temp fix

  if (externalDataVal && externalDataVal.OTP) externalCallPayload.body.OTP = otpData;
  if (externalDataVal && externalDataVal.aadharOtp) externalCallPayload.body.aadharOtp = aadharOtpData;

  const sysConf = (await systemConfigUtils.getMultipleSysConfigData('NULL', [SYS_CONF.ENABLE_DB_LOGS, SYS_CONF.ENABLE_GCP_LOGS])).reduce((obj, item) => ({ ...obj, [item.configuration_name]: Number(item.value) }), {});

  if (headers.ProductID) {
    tableData.productName = headers.ProductID;
  }
  if (tableData) {
    tableData.enableLogStore = dataInput.enableLogs || false;
  }

  logging(logger, `externalCallPayload ${JSON.stringify(externalCallPayload)}`, logExtData);

  let leadDetail;
  if (tableData) {
    leadDetail = await fetchEventLogsDetails(tableData, headers);
    resetData(tableData);
  }

  let encryptedRequest;
  if (dataInput.isPgpEncrypt) {
    // eslint-disable-next-line global-require
    const PGPEncDec = require('../utils/pgp-enc-dec/pgpEncDec');
    const pgpEncDec = new PGPEncDec('password');
    await storeLogs(
      leadDetail,
      dataInput,
      tableData,
      externalDataVal,
      INPROGRESS,
      null,
      undefined,
      sysConf,
      configs,
    );

    try {
      const payload = await pgpEncDec.encrypt(JSON.stringify(externalDataVal));
      externalCallPayload.body = payload;

      logging(logger, `externalCallPayload ${JSON.stringify(externalCallPayload)}`, logExtData);
      logger.info('encrypted payload');

      const encryptedResponse = await restCall.restAPICall(externalCallPayload, mockData);

      logging(logger, `encryptedResponse ${JSON.stringify(encryptedResponse)}`, logExtData);
      logger.info('encryptedResponse');

      const { body, statusCode } = encryptedResponse;
      const decryptedResponse = JSON.parse(await pgpEncDec.decrypt(body));

      // if decryptedResponse is null || {} then return
      if (!decryptedResponse && isObjectEmpty(decryptedResponse)) {
        logger.info('Third Party Response is Empty');
        const dataToStore = 'Third Party Response is Empty';
        await storeLogs(
          leadDetail,
          dataInput,
          tableData,
          externalDataVal,
          FAILED,
          dataToStore,
          STATUS_CODE.INTERNAL_ERROR,
          sysConf,
          configs,
        );
        return Promise.reject();
      }

      decryptedResponse.responseCode = statusCode;

      logging(logger, `decryptedResponse ${JSON.stringify(decryptedResponse)}`, logExtData);
      logger.info('decryptedResponse');

      await storeLogs(
        leadDetail,
        dataInput,
        tableData,
        externalDataVal,
        ERR_MESSAGE.SUCCESS,
        decryptedResponse,
        decryptedResponse.responseCode,
        sysConf,
        configs,
      );

      logging(logger, `returnResponse ${JSON.stringify(decryptedResponse)}`, logExtData);
      logger.info('returnResponse');
      return Promise.resolve(decryptedResponse);
    } catch (error) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | failed | ${errorFormat(error)}`);
      let errorResponse = {};

      if (error.statusCode !== 401) {
        errorResponse = JSON.parse(await pgpEncDec.decrypt(error.error));
      }
      errorResponse.responseCode = error.statusCode;
      await storeLogs(
        leadDetail,
        dataInput,
        tableData,
        externalDataVal,
        FAILED,
        error,
        error.statusCode || 500,
        sysConf,
        configs,
      );
      return Promise.resolve(errorResponse);
    }
  } else if (!dataInput.isEncrypt) {
    try {
      let plainData = await restCall.restAPICall(externalCallPayload, mockData);
      logger.debug(`plainData | ${JSON.stringify(plainData)}`);
      if (plainData && plainData.mock_status && plainData.data) {
        plainData = plainData.data.data;
      }
      logger.debug('resolve plainData');
      return Promise.resolve(plainData);
    } catch (error) {
      logger.debug(`failed | ${errorFormat(error)} |`);
      return Promise.reject(error);
    }
  } else {
    await storeLogs(
      leadDetail,
      dataInput,
      tableData,
      externalDataVal,
      INPROGRESS,
      null,
      undefined,
      sysConf,
      configs,
    );

    // temp fix
    if (externalDataVal && externalDataVal.OTP) {
      externalCallPayload.body.OTP = otpData;
    }
    if (externalDataVal && externalDataVal.aadharOtp) {
      externalCallPayload.body.aadharOtp = aadharOtpData;
    }
    logging(logger, `externalCallPayload ${JSON.stringify(externalCallPayload)}`, logExtData);
    // Third Party Call starts
    // Third Party Call starts
    try {
      if (tableData.isXml) {
        // used to encrypt xml data
        encryptedRequest = await encryptDataXML(externalDataVal, env);
      } else {
        // used to encrypt json data
        encryptedRequest = await encryptData(externalDataVal, env, dataInput.key, logExtData);
      }

      logging(logger, `encryptedRequest ${JSON.stringify(encryptedRequest)}`, logExtData);
      logger.info('encrypted request');

      const { key, data } = encryptedRequest;
      const payload = generateEncrpytedPayload(key, data, dataInput.service || '');

      externalCallPayload.body = payload;

      logging(logger, `externalCallPayload ${JSON.stringify(externalCallPayload)}`, logExtData);
      logger.info('externalCallPayload after encryption');

      const encryptedResponse = await restCall.restAPICall(externalCallPayload, mockData);

      logging(logger, `encryptedResponse ${JSON.stringify(encryptedResponse)}`, logExtData);
      logger.info('encryptedResponse recieved');

      // resolve mock data immediately
      if (encryptedResponse.mock_status && encryptedResponse.data) {
        return Promise.resolve(encryptedResponse.data.data);
      }

      // decrypt response
      const { body, statusCode } = encryptedResponse;
      const { encryptedKey, encryptedData } = body;
      const decryptedResponse = await decryptData(
        encryptedData,
        encryptedKey,
        env,
        dataInput.key,
      );

      logging(logger, `decryptedResponse ${JSON.stringify(decryptedResponse)}`, logExtData);
      logger.info('response decrypted');

      // if decryptedResponse is null || {} then return
      if (!decryptedResponse || isObjectEmpty(decryptedResponse)) {
        logger.info('Third Party Response is Empty');
        const dataToStore = 'Third Party Response is Empty';
        await storeLogs(
          leadDetail,
          dataInput,
          tableData,
          externalDataVal,
          FAILED,
          dataToStore,
          STATUS_CODE.INTERNAL_ERROR,
          sysConf,
          configs,
        );

        return Promise.reject(new Error(dataToStore));
      }

      decryptedResponse.responseCode = statusCode;
      logging(logger, `decryptedResponse ${JSON.stringify(decryptedResponse)}`, logExtData);

      const returnResponse = tableData.wholeData
        ? parseData(decryptedResponse) : parseData(decryptedResponse.data);

      await storeLogs(
        leadDetail,
        dataInput,
        tableData,
        externalDataVal,
        ERR_MESSAGE.SUCCESS,
        decryptedResponse.data,
        decryptedResponse.responseCode,
        sysConf,
        configs,
      );

      logging(logger, `returnResponse ${JSON.stringify(returnResponse)}`, logExtData);
      logger.info('resolving returnResponse');

      return Promise.resolve(returnResponse);
    } catch (error) {
      logger.error(`${ERROR_CODE.API_INTERNAL} | failed | ${errorFormat(error)}`);

      // incase encrypted response
      if (typeof error === 'object'
        && error.error.encryptedKey
        && error.error.encryptedData) {
        const { encryptedKey, encryptedData } = error.error;
        const decryptedResponse = await decryptData(
          encryptedData,
          encryptedKey,
          env,
          dataInput.key,
        );
        logging(logger, `error decryptedResponse ${JSON.stringify(decryptedResponse)}`, logExtData);
        logger.info('error response decrypted');
        error.error = parseData(decryptedResponse.data);
      }

      await storeLogs(
        leadDetail,
        dataInput,
        tableData,
        externalDataVal,
        FAILED,
        error,
        error.status || 500,
        sysConf,
        configs,
      );
      return Promise.reject(error);
    }
  }
};

module.exports = {
  extCall,
};
