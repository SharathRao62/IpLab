/* eslint-disable consistent-return */
/* eslint-disable no-sequences */
/* eslint-disable no-return-assign */
// eslint-disable-next-line no-return-assign, no-sequences
/* eslint-disable no-param-reassign */
// const { extCall } = require('./externalApiCall');
const Logger = require('../utils/logger');
const environConfig = require('../../insta_config_submodule/config/environConfig');
const { maskdata } = require('../utils/logMasking');
const { errorFormat } = require('../utils/errorFormat');
const systemConfigUtils = require('../utils/systemConfigUtils');
const { SYS_CONF, ERROR_CODE } = require('../../insta_constants_submodule/constants/constant');
const { publishMessage } = require('../utils/gcpPubSubTopic');
const { getPage } = require('../utils/stageImplementation');

module.exports.saveFunctionalResponse = async (data, journeyId = null) => {
  const uniqueId = !('txn_id' in data && data.txn_id) ? data.lead_id : data.txn_id;
  const logger = new Logger('saveFunctionalResponse', uniqueId, data.table_name);

  const systemConfigurations = (await systemConfigUtils.getMultipleSysConfigData(
    'NULL', [SYS_CONF.ENABLE_GCP_LOGS], journeyId
  )).reduce((obj, item) => (obj[item.configuration_name] = Number(item.value), obj), {});
  logger.debug(`systemConfigurations ${(JSON.stringify(systemConfigurations))}`);

  data.page = data.page ? data.page : await getPage(data.lead_id);
  logger.debug("data.page  value", data.page)
  
  if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS]) {
    try {
      return publishMessage(JSON.stringify(data), logger).then((res) => {
        logger.debug(`Publisher result ${(JSON.stringify(res))} `);
        return Promise.resolve(true);
      }).catch((error) => {
        logger.error(`${ERROR_CODE.API_INTERNAL} | LOG API SERVICE | Pub sub catch | error | ${errorFormat(error)}`);
        return Promise.resolve(true);
      });
    } catch (error) {
      logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} error ${errorFormat(error)}`);
      return '';
    }
  }
};

module.exports.updateEventLogs = async (data, journeyId = null) => {
  const uniqueId = data.lead_id;
  const logger = new Logger('updateEventLogs', uniqueId, data.table_name);
  logger.info(`journeyId | ${journeyId}`);

  const systemConfigurations = (await systemConfigUtils.getMultipleSysConfigData(
    'NULL', [SYS_CONF.ENABLE_GCP_LOGS],
  ),journeyId).reduce((obj, item) => (obj[item.configuration_name] = Number(item.value), obj), {});
  logger.debug(`systemConfigurations ${(JSON.stringify(systemConfigurations))}`);

  if (systemConfigurations[SYS_CONF.ENABLE_GCP_LOGS]) {
    try {
      return publishMessage(JSON.stringify(data), logger).then((res) => {
        logger.debug(`Publisher result ${(JSON.stringify(res))} `);
        return Promise.resolve(true);
      }).catch((error) => {
        logger.error(`${ERROR_CODE.API_INTERNAL} | LOG API SERVICE | Pub sub catch | error | ${errorFormat(error)}`);
        return Promise.resolve(true);
      });
    } catch (error) {
      logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} error ${errorFormat(error)}`);
      return '';
    }
  }
};
