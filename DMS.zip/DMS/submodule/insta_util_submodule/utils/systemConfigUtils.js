/* eslint-disable camelcase */
/* eslint-disable no-else-return */
const Sequelize = require('sequelize');
const { system_configuration: systemConfiguration } = require('../../../models');
const Logger = require('./logger');

const logger = new Logger();
const environment = process.env.NODE_ENV || 'development';
const { STATUS_CODE, SYS_CONF, DIFM_JOURNEY} = require('../../insta_constants_submodule/constants/constant');
const CONSTANTS = require('../../../constants/constant');

const { Op } = Sequelize;
const getSysConfigData = (product_name, configuration_name, journey) => {
  try {
    let condition = {};
    if (environment) {
      condition = {
        configuration_name: `${configuration_name}`,
        product_list: { [Op.like]: `%${product_name}%` },
        enviornment_list: { [Op.like]: `%${environment}%` },
      };
    } else {
      condition = {
        configuration_name: `${configuration_name}`,
        product_list: { [Op.like]: `%${product_name}%` },
      };
    }

    if (journey) {
      condition.journey_list = { [Op.like]: `%${journey}%` };
      delete condition.product_list;
    }

    logger.debug(`SYSTEM CONFIG DATA | product_name | ${product_name} | configuration_name ${configuration_name} | environment ${environment}`);
    return systemConfiguration.findOne({
      attributes: ['value'],
      where: condition,
      raw: true,
    });
  } catch (err) {
    logger.debug(`SYSTEM CONFIG DATA | product_name | ${product_name} | ${JSON.stringify(err)}`);
  }
};

const checkIfValuePresent = (product_name, configuration_name, value, journey) => {
  try {
    let condition = {};
    if (environment) {
      condition = {
        configuration_name: `${configuration_name}`,
        product_list: { [Op.like]: `%${product_name}%` },
        enviornment_list: { [Op.like]: `%${environment}%` },
        value: { [Op.like]: `%${value}%` },
      };
    } else {
      condition = {
        configuration_name: `${configuration_name}`,
        product_list: { [Op.like]: `%${product_name}%` },
        value: { [Op.like]: `%${value}%` },
      };
    }

    if (journey) {
      condition.journey_list = { [Op.like]: `%${journey}%` };
      delete condition.product_list;
    }

    logger.debug(`SYSTEM CONFIG DETAILS | product_name | ${product_name} | configuration_name ${configuration_name} | environment ${environment} | value | ${value}`);
    return systemConfiguration.findOne({
      attributes: ['id'],
      where: condition,
      // where: {
      //   configuration_name: `${configuration_name}`,
      //   product_list: {
      //     [Op.like]: `%${product_name}%`,
      //   },
      //   enviornment_list: {
      //     [Op.like]: `%${environment}%`,
      //   },
      // },
      raw: true,
    });
  } catch (err) {
    logger.error(`SYSTEM CONFIG DETAILS | product_name | ${product_name} | ${JSON.stringify(err)}`);
  }
};

/**
 * @param {product, configName, journey} sysData 
 * @returns { data: value }
 */
const fetchSystemConfigDetails = async (sysData) => {
  // const logger = new Logger ('fetchSystemConfigDetails', `environment | ${environment}`, `request data | ${JSON.stringify(sysData)}`);
  try {
    logger.debug(`SYSTEM CONFIG DETAILS | environment | ${environment} | request data | ${JSON.stringify(sysData)}`);
    const systConfigData = await getSysConfigData(sysData.product, sysData.configName, sysData.journey);
    if (systConfigData && systConfigData.value) {
      return Promise.resolve({ data: systConfigData.value });
    } else {
      return Promise.resolve({ data: null });
    }
  } catch (error) {
    logger.error(`SYSTEM CONFIG DETAILS | error occured | ${JSON.stringify(error)}`);
    const err = { status: STATUS_CODE.INTERNAL_ERROR, error: 'DB ERROR IN SYSTEM_CONFIGURATION' };
    throw err;
  }
};

const getSysConfigProductData = (configuration_name, journeyId) => {
  try {
    let condition = {};
    if (environment) {
      condition = {
        configuration_name: `${configuration_name}`,
        enviornment_list: { [Op.like]: `%${environment}%` },
      };
    } else {
      condition = {
        configuration_name: `${configuration_name}`,
      };
    }
    if(journeyId){
      condition.journey_list = { [Op.like]: `%${journeyId}%` }
    }
    logger.debug(`SYSTEM CONFIG DETAILS | configuration_name ${configuration_name} | environment ${environment}`);
    return systemConfiguration.findOne({
      attributes: ['value','product_list'],
      where: condition,
      raw: true,
    });
  } catch (err) {
    logger.error(`SYSTEM CONFIG DETAILS | product_name | ${product_name} | ${JSON.stringify(err)}`);
  }
};

const fetchSystemConfigCheck = (sysData, journeyId) => {
  try {
    logger.debug(`SYSTEM CONFIG DETAILS | enviornment | ${environment} | request data | ${JSON.stringify(sysData)}`);
    return getSysConfigProductData(sysData.configName, journeyId).then((systConfigData) => new Promise((resolve) => {
      resolve({ data: systConfigData });
      logger.debug(`SYSTEM CONFIG DETAILS | response data | ${JSON.stringify(systConfigData)}`);
    }));
  } catch (error) {
    logger.error(`SYSTEM CONFIG DETAILS | error occured | ${JSON.stringify(error)}`);

    if (sysData.configName === SYS_CONF.ENABLE_SAVE_EMAIL || sysData.configName === CONSTANTS.SYS_CONF.FUNDING_BASIS_PROFILE_ENABLE
      || sysData.configName === CONSTANTS.SYS_CONF.ENABLE_CASA_DUPLICATE_CHECK) {
      throw error;
    }

    return new Promise((resolve) => resolve({ data: { value: 0 } }));
  }
};

const getSysConfig = (configuration_name) => {
  try {
    let condition = {};
    if (environment) {
      condition = {
        configuration_name: `${configuration_name}`,
        enviornment_list: { [Op.like]: `%${environment}%` },
      };
    } else {
      condition = {
        configuration_name: `${configuration_name}`,
      };
    }
    logger.debug(
      `SYSTEM CONFIG DETAILS | configuration_name ${configuration_name} | environment ${environment}`,
    );
    return systemConfiguration.findOne({
      attributes: ['value', 'product_list'],
      where: condition,
      raw: true,
    });
  } catch (err) {
    logger.error(
      `SYSTEM CONFIG DETAILS | ${JSON.stringify(
        err,
      )}`,
    );
  }
};

const fetchSystemConfig = (sysData) => {
  try {
    logger.debug(
      `SYSTEM CONFIG DETAILS | enviornment | ${environment} | request data | ${JSON.stringify(
        sysData,
      )}`,
    );
    return getSysConfig(sysData.configName).then(
      (systConfigData) => new Promise((resolve) => {
        resolve({ data: systConfigData });
        // logger.debug(
        //   `SYSTEM CONFIG DETAILS | response data | ${JSON.stringify(
        //     systConfigData,
        //   )}`,
        // );
      }),
    );
  } catch (error) {
    logger.error(
      `SYSTEM CONFIG DETAILS | error occured | ${JSON.stringify(error)}`,
    );
    return new Promise((resolve) => resolve({ data: { value: 0 } }));
  }
};

/**
 * @param {product, configName, journey} sysData 
 * @returns { data: value }
 */
const fetchValueIfpersentDetails = (sysData) => {
  try {
    logger.debug(`SYSTEM CONFIG DETAILS | enviornment | ${environment} | request data | ${JSON.stringify(sysData)}`);
    // sysData { product, configName, value, journey }
    return checkIfValuePresent(sysData.product, sysData.configName, sysData.value, sysData.journey).then((systConfigData) => new Promise((resolve) => {
      resolve({ data: systConfigData });
      // logger.debug(`SYSTEM CONFIG DETAILS | response data | ${JSON.stringify(systConfigData)}`);
    }));
  } catch (error) {
    logger.error(`SYSTEM CONFIG DETAILS | error occured | ${JSON.stringify(error)}`);
    return new Promise((resolve) => resolve({ data: { value: 0 } }));
  }
};

/**
 * @param {product, configName, journey} sysData 
 * @returns { data: value }
 */
const fetchSystemConfigDetailsErrorThrown = (sysData) => {
  /* fetchSystemConfigDetailsErrorThrown --> throws error on db error
  while fetchSystemConfigDetails does not throw error gives value 0 on any error */
  try {
    logger.debug(`SYSTEM CONFIG DETAILS | enviornment | ${environment} | request data | ${JSON.stringify(sysData)}`);
    // sysData { product, configName, value, journey }
    return getSysConfigData(sysData.product, sysData.configName, sysData.journey).then((systConfigData) => new Promise((resolve) => {
      resolve({ data: systConfigData });
      // logger.debug(`SYSTEM CONFIG DETAILS | response data | ${JSON.stringify(systConfigData)}`);
    }));
  } catch (error) {
    logger.error(`SYSTEM CONFIG DETAILS | error occured | ${JSON.stringify(error)}`);
    throw error;
  }
};

const getEnableSystemConfig = async (product, configName, journey) => {
  /* getEnableSystemConfig gives true if configuration is enabled else false
      if error, throws 500 */
  logger.debug(`getSystemConfigForleadGeneration | request data product | ${JSON.stringify(product)} |configName | ${JSON.stringify(configName)}`);
  if (!product) {
    return { status: STATUS_CODE.INTERNAL_ERROR };
  }
  const sysData = { product, configName };

  if (journey) {
    sysData.journey = journey;
  }

  logger.debug(`getSystemConfigForleadGeneration | request data SYS DATA | ${JSON.stringify(sysData)}`);
  try {
    const systdata = await fetchSystemConfigDetailsErrorThrown(sysData);
    logger.debug(`getSystemConfigForleadGeneration | request data systdata | ${JSON.stringify(systdata)}`);

    if (systdata && systdata.data && systdata.data.value
      && (systdata.data.value === 1 || systdata.data.value === '1')) {
      logger.debug(`getSystemConfigForleadGeneration | request data systdata | ${JSON.stringify(systdata)} | value is true`);
      return true;
    }
    logger.debug(`getSystemConfigForleadGeneration | request data systdata | ${JSON.stringify(systdata)} | value is false`);
    return false;
  } catch (error) {
    logger.error(`getSystemConfigForleadGeneration | catch errorr | ${JSON.stringify(error)} `);
    return { status: STATUS_CODE.INTERNAL_ERROR };
  }
};

const fetchMultipleSystemConfigDetails = (sysData) => {
  try {
    // logger.debug(`SYSTEM CONFIG DETAILS | enviornment | ${environment} | request data | ${JSON.stringify(sysData)}`);
    return getMultipleSysConfigData(sysData.product, sysData.configName).then((systConfigData) => new Promise((resolve) => {
      resolve({ data: systConfigData });
      // logger.debug(`SYSTEM CONFIG DETAILS | response data | ${JSON.stringify(systConfigData)}`);
    }));
  } catch (error) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | SYSTEM CONFIG DETAILS | error occured | ${JSON.stringify(error)}`);
    throw error;
  }
};

const getMultipleSysConfigData = (product_name, configuration_name) => {
  try {
    let condition = {};
    condition = {
      configuration_name: { [Op.in]: configuration_name },
    };
   logger.debug(`SYSTEM CONFIG DETAILS | product_name | ${product_name} | configuration_name ${JSON.stringify(configuration_name)}`);
    return systemConfiguration.findAll({
      attributes: ['value', 'configuration_name', 'enviornment_list', 'product_list','journey_list'],
      where: condition,
      raw: true,
    });
  } catch (err) {
    logger.error(`SYSTEM CONFIG DETAILS | product_name | ${product_name} | ${JSON.stringify(err)} | ${err}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    throw error;
  }
};

const isConfigEnabled = (configName, sysConfigData, product) => {
  try {
    if (!configName || !sysConfigData || !product) {
      // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | SYSTEM CONFIG DATA | ${JSON.stringify(sysConfigData)} | PRODUCT | ${JSON.stringify(product)} Some datas are missing`);
      return { status: STATUS_CODE.INTERNAL_ERROR };
    }
    // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | ENTERING IS CONFIG ENABLED`);
    const data = sysConfigData;
    // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | SYSTEM CONFIG DATA | ${JSON.stringify(sysConfigData)}`);
    const envExpr = new RegExp(environment);
    const confExpr = new RegExp(configName);
    const productExpr = new RegExp(product);
    let value;
    data.forEach((obj) => {
      // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | OBJECT| ${JSON.stringify(obj)}`);
      const env = obj.enviornment_list.match(envExpr);
      const conf = obj.configuration_name.match(confExpr);
      const productMatch = obj.product_list.match(productExpr);
      if (env && env.length >= 1 && conf && conf.length >= 1 && productMatch && productMatch.length >= 1 && obj && obj.value && (obj.value == 1)) {
        // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | ENVIRONMENT | ${JSON.stringify(env)}`);
        // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | CONFIGURATION| ${JSON.stringify(conf)}`);
        // logger.debug(`SYSTEM CONFIG DETAILS | FOUND THE ENVIRONMENT AND CONFIGURATION | OBJECT VALUE | ${obj.value}`);
        value = true;
        return true;
      }
    });
    if (value === true) {
      // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | ENABLED`);
      return true;
    }

    // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | DISABLED`);
    return false;
  } catch (error) {
    // eslint-disable-next-line no-throw-literal
    throw { status: STATUS_CODE.INTERNAL_ERROR };
  }
};

const isConfigEnabledAllSysConf = (configName, sysConfigData, product) => {
  let env;
  let productMatch;
  try {
    if (!configName || !sysConfigData || !product) {
      // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | SYSTEM CONFIG DATA | ${JSON.stringify(sysConfigData)} | PRODUCT | ${JSON.stringify(product)} Some datas are missing`);
      return false;
    }
    // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | ENTERING IS CONFIG ENABLED`);
    const data = sysConfigData;
    // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | SYSTEM CONFIG DATA | ${JSON.stringify(sysConfigData)}`);
    const envExpr = new RegExp(environment);
    const confExpr = new RegExp(configName);
    const productExpr = new RegExp(product);
    let value = false;
    data.forEach((obj) => {
      // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | OBJECT| ${JSON.stringify(obj)}`);
      if (obj && obj.enviornment_list) {
        env = obj.enviornment_list.match(envExpr);
      } else {
        env = null;
      }
      if (obj && obj.product_list) {
        productMatch = obj.product_list.match(productExpr);
      } else {
        productMatch = null;
      }
      const conf = obj.configuration_name.match(confExpr);
      if (env && env.length >= 1 && conf && conf.length >= 1 && productMatch && productMatch.length >= 1 && obj && obj.value && (obj.value == 1)) {
        // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | ENVIRONMENT | ${JSON.stringify(env)}`);
        // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | CONFIGURATION| ${JSON.stringify(conf)}`);
        // logger.debug(`SYSTEM CONFIG DETAILS | FOUND THE ENVIRONMENT AND CONFIGURATION | OBJECT VALUE | ${obj.value}`);
        value = true;
        return { data: configName, value };
      }
    });
    if (value === true) {
      // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | ENABLED`);
      return { data: configName, value };
    }

    // logger.debug(`SYSTEM CONFIG DETAILS | CONFIG NAME | ${configName} | DISABLED`);
    return { data: configName, value };
  } catch (error) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | SYSTEM CONFIG DETAILS | INNER CATCH ERROR | ${JSON.stringify(error)} | ${error} `);
    // eslint-disable-next-line no-throw-literal
    return false;
  }
};


const allSysFunc = async (configName, product) => {
  try {
    // logger.debug(`SYSTEM CONFIG DETAILS | allSysFunc | CONFIG NAME | ${configName} | PRODUCT | ${product}`);
    let dummy = [];
    let confStatus = [];
    let configEnabled = false;
    dummy = Object.keys(CONSTANTS.SYS_CONF);
    const sysData = {
      product,
      configName: dummy,
    };
    const reqData = await fetchMultipleSystemConfigDetails(sysData);
    if (reqData && reqData.data) {
      const reqlength = reqData.data.length;
      for (let i = 0; i < reqlength; i += 1) {
        confStatus = await isConfigEnabledAllSysConf(reqData.data[i].configuration_name, reqData.data, product);
        if (confStatus && confStatus.data && confStatus.data.includes(configName) && confStatus.value) {
          configEnabled = true;
        }
      }
      // logger.debug(`SYSTEM CONFIG DETAILS | allSysFunc | CONFIG NAME | ${configName} | PRODUCT | ${product} | CONFIG ENABLED | ${JSON.stringify(configEnabled)} | ${configEnabled}`);
      return { configName, configEnabled };
    } else {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | SYSTEM CONFIG DETAILS | allSysFunc | CONFIG NAME | ${configName} | PRODUCT | ${product} | DATA NOT RECIEVED`);
      return false;
    }
  } catch (error) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | SYSTEM CONFIG DETAILS | allSysFunc | CONFIG NAME | ${configName} | PRODUCT | ${product} | CATCH ERROROR | ${JSON.stringify(error)}`);
    return false;
  }
};

const fetchMultipleSystemConfigurations = async (product_name, configuration_names = [], journey) => {
  try {
    let condition = {
      configuration_name: { [Op.in]: configuration_names },
      product_list: { [Op.like]: `%${product_name}%` },
      enviornment_list: { [Op.like]: `%${environment}%` },
    };

    if(journey) {
      condition.journey_list = { [Op.like]: `%${journey}%` };
      delete condition.product_list;
    }
    logger.debug(`SYSTEM CONFIG DETAILS | request | ${product_name} | condition: ${JSON.stringify(condition)}`);

    const configRes = await systemConfiguration.findAll({
      attributes: ['value', 'configuration_name'],
      where: condition,
      raw: true,
    });
    const resp = {};
    configRes.map(res => {
      resp[res.configuration_name] = res && res.value == 1;
    });
    logger.debug(`SYSTEM CONFIG DETAILS | product_name | ${product_name} | Result: ${JSON.stringify(resp)}`);
    return resp;
  } catch (err) {
    logger.error(`SYSTEM CONFIG DETAILS | product_name  ERROR | ${product_name} | ${JSON.stringify(err)} | ${err}`);
    const error = { status: STATUS_CODE.INTERNAL_ERROR };
    throw error;
  }
};

module.exports = {
  getSysConfigData,
  fetchSystemConfigDetails,
  fetchValueIfpersentDetails,
  getEnableSystemConfig,
  fetchSystemConfigDetailsErrorThrown,
  fetchSystemConfig,
  fetchMultipleSystemConfigDetails,
  getMultipleSysConfigData,
  isConfigEnabled,
  allSysFunc,
  isConfigEnabledAllSysConf,
  fetchSystemConfigCheck,
  fetchMultipleSystemConfigurations
};
