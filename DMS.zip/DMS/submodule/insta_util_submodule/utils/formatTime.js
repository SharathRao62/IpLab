
const formatTimeGMT = (time) => {

    const dateObj = new Date(time);

    const year = dateObj.getUTCFullYear();
    const month = dateObj.getUTCMonth() + 1; 
    const day = dateObj.getUTCDate();
    const hours = dateObj.getUTCHours();
    const minutes = dateObj.getUTCMinutes();
    const seconds = dateObj.getUTCSeconds();

    let timeToSave = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`

    return timeToSave
}

module.exports={
    formatTimeGMT
}