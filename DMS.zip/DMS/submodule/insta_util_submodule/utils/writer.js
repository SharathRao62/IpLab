const crypt = require('./feBeEncryptionDecryption');
const environConfig = require('../../../config/environConfig');

const writeJson = (response, arg1, arg2) => {
  let code;
  let payload;
  const { url } = response;

  if (arg2 && Number.isInteger(arg2)) {
    code = arg2;
  } else if (arg1 && Number.isInteger(arg1)) {
    code = arg1;
  }
  if (code && arg1) {
    payload = arg1;
  } else if (arg1) {
    payload = arg1;
  }

  if(arg1 && arg1.errorCode && arg1.errorCode.actCode){
    response.setHeader('actCode', arg1.errorCode.actCode)
  }
  
  if(arg1 && arg1.errorCode && arg1.errorCode.errorCode){
    payload.errorCode = arg1.errorCode.errorCode
  }

  if (!code) {
    // if no response code given, we default to 200
    code = 200;
  }
  if (typeof payload === 'object') {
    payload = JSON.stringify(payload, null, 2);
  } else {
    payload = payload ? payload.toString() : '';
  }
  if (environConfig.ENCRYPTION_BYPASS
  || url.includes('/eazypayTransactionStatus') || url.includes('/casaUpdateStatusCode')
  || url.includes('/casaSaveUpdateLog') || url.includes('/createPushDataLog')
  || url.includes('/ribSaveUpdateLog') || url.includes('/crmSaveUpdateLog')
  || url.includes('/imobileSaveUpdateLog') || url.includes('/omnidoxSaveUpdateLog') || url.includes('videoKYC')
  || url.includes('/encrypt') || url.includes('/decrypt')
  || url.includes('/fetchPublicKey')
  || url.includes('/coinToss')
  || url.includes('/iview')
  || url.includes('/dedupeCallForSavingsCASA')
  || url.includes('/dedupeCallForSavingsCASAfundingcron')
  || url.includes('/isSavings')
  || url.includes('/idump')
  || url.includes('/internalStoreAccountDetails')
  || url.includes('/internalCustomerCall')
  || url.includes('/dedupeCron')
  || url.includes('/CheckDedupe')
  || url.includes('/checkPaymentStatus')
  || url.includes('/fundTransferPool')
  || url.includes('/imageConversion')
  || url.includes('/checkEsignCount')
  || url.includes('/experian') || url.includes('/BIU')
  || url.includes('/savings-bre2')
  || url.includes('/updateCRMLeadInstaSaveAccount')
  || url.includes('/createCRMLeadInstaSaveAccount')
  || url.includes('/createCRMLeadInstaSave3In1AccountForDropOutCase')
  || url.includes('/createCRMLeadInstaSavePremiumAccountForDropOutCase')
  || url.includes('/createCRMLeadInstaSaveBridgeFundAccountForDropOutCase')
  || url.includes('/updateCRMLeadInstaSave3In1Account')
  || url.includes('/updateCRMLeadInstaSaveBridgeFundFacility')
  || url.includes('/updateCRMLeadInstaSavePremiumAccount')
  || url.includes('/getRegionSolIdMapdata')
  || url.includes('/crmSaveUpdateLog')
  || url.includes('/cronCreateCRMLeadInstaSaveAccount')
  || url.includes('/cronCreateCRMLeadInstaSave3In1AccountForDropOutCase')
  || url.includes('/cronCreateCRMLeadInstaSavePremiumAccountForDropOutCase')
  || url.includes('/cronCreateCRMLeadInstaSaveBridgeFundAccountForDropOutCase')
  || url.includes('/cronUpdateCRMLeadInstaSaveAccount')
  || url.includes('/cronUpdateCRMLeadInstaSave3In1Account')
  || url.includes('/cronUpdateCRMLeadInstaSaveBridgeFundFacility')
  || url.includes('/cronUpdateCRMLeadInstaSavePremiumAccount')
  || url.includes('/pushData')
  || url.includes('/fetchDataFromMasterUtm')
  || url.includes('/omnidoxMethod')
  || url.includes('/omnidoxMethodCron')
  || url.includes('/logsPdfOmnidox')
  || url.includes('/storeAccountDetailsCASA')
  || url.includes('/internalStoreAccountDetails')
  || url.includes('/internalCustomerCall')
  || url.includes('/pushWhatsappConsent')
  || url.includes('/mobileHardStop')
  || url.includes('/trigger-email')
  || url.includes('/sendCronEmail')
  || url.includes('/sendEmail')
  || url.includes('/createEsignPdf')
  || url.includes('/v1/pdf/ppf')
  || url.includes('/createEsignPdfCron')
  || url.includes('/createEsignBrokerPdfCron')
  || url.includes('/productCombinationCheckForEsign')
  || url.includes('/generateVerifyMobileOtp')
  || url.includes('/aadharPdfGenrate')
  || url.includes('/checkPincodeFromMasters')
  || url.includes('/checkFircosoftStatus') // 175895 CheckFircosoft Status | Encryption Bypass
  || url.includes('/fircosoft') // 175895 fircosoft | Encryption Bypass
  || url.includes('/callbackApi') // 175895 callbackApi | Encryption Bypass
  || url.includes('/createCRMLeadCALOA')
  || url.includes('/crmSaveUpdateLogCurrentAccount')
  || url.includes('/cronCreateCRMLeadCALOA')
  || url.includes('/cronUpdateCRMLeadCALOA')
  || url.includes('/updateCRMLeadCALOA')
  || url.includes('/sendCronemailCaloa')
  || url.includes('/sendmailCALOA')
  || url.includes('/inwardTrackerCALOA')
  || url.includes('/idumpCa')
  || url.includes('/iScan')
  || url.includes('/iScanCron')
  || url.includes('/getCurrentAccountCount')
  || url.includes('/otpStatusCall')
  || url.includes('/CronStoreAccountDetails')
  || url.includes('/inwardTrackerCALOACron')
  || url.includes('/vkycValidationCaloaNoEncrypt')
  || url.includes('/vkycValidationCaloaNoEncryptCron')
  || url.includes('/tiff_image_manual_trigger')
  || url.includes('/pushImageToIcoreCron')
  || url.includes('/createCRMLeadIndividual')
  || url.includes('/cronCreateCRMLeadIndividual')
  || url.includes('/nameApproveRejectStatus') // 182633 Encryption Bypass
  || url.includes('/updateCRMLeadIndividual')
  || url.includes('/cronUpdateCRMLeadIndividual')
  || url.includes('/sendmailSaloa')
  || url.includes('/sendCronEmailSaloa')
  || url.includes('/sendmailIndividual')
  || url.includes('/sendCronEmailIndividual')
  || url.includes('/sendmailAmazonSavings')
  || url.includes('/sendmailCronAmazonSavings')
  || url.includes('/creditChecksPdfCron')
  || url.includes('/generateCreditCardReportCron')
  || url.includes('/savemisgemsdetailsCron')
  || url.includes('/vkycReverseStatus')
  || url.includes('/panvalidationPL')
  || url.includes('/reversefeedDecryptRefValue')
  || url.includes('/customerDedupeCheck')
  || url.includes('/utmValidationInternal')
  || url.includes('/createCRMLeadSolePropertier')
  || url.includes('/cronCreateCRMLeadSolePropertier')
  || url.includes('/updateCRMLeadSolePropertier')
  || url.includes('/cronUpdateCRMLeadSolePropertier')
  || url.includes('/sendmailSolePropertier')
  || url.includes('/sendCronEmailSolePropertier')
  || url.includes('/omniFlowIndividual')
  || url.includes('/omniFlowSolePropriter')
  || url.includes('/omniFlowCompanySES')
  || url.includes('/omniFlowCompanySESCron')
  || url.includes('/omniFlowIndividualCron')
  || url.includes('/generatePlReportCron')
  || url.includes('/omniFlowSolePropriterCron')
  || url.includes('/ccCRMServiceCron')
  || url.includes('/CrmLeadCreationPayLaterCron')
  || url.includes('/createpaylaterodaccountCron')
  || url.includes('/fundtransferPaylater')
  || url.includes('/generatePaylaterReportCron')
  || url.includes('/createCreditCardCron')
  || url.includes('/gemsCron')
  || url.includes('/saveHlodreportdetails')
  || url.includes('/esignSessionCron')
  || url.includes('/saveStageTimerInternal')
  || url.includes('/sendmailCronEmailConfirmation')
  || url.includes('/updateCRMLeadCompanySES')
  || url.includes('/createCRMLeadCompanySES')
  || url.includes('/cronUpdateCRMLeadCompanySES')
  || url.includes('/cronCreateCRMLeadCompanySES')
  || url.includes('/sendmailCompanySes')
  || url.includes('/sendCronEmailCompanySes')
  || url.includes('/lopDestProdApiCall')
  || url.includes('/panvalidationNoEncrypt')
  || url.includes('/customerHandshakeCompanySES')
  || url.includes('/sendmailFixedDeposit')
  || url.includes('/sendmailCronPaHlHfc')
  || url.includes('/generatePAHLHFCReportCron')
  || url.includes('/ntbfdcreationCron')
  || url.includes('/cronsavercaspayload')
  || url.includes('/cronrcascasecreation')
  || url.includes('/sendmailPaHlHfc')
  || url ==  '/eotp/generateFormpartner' 
  || url == '/ucj_prebre/revolverpartner'
  || url == '/bank_customer/customerpartner'
  || url == '/bank_customer/ckycpartner'
  || url == '/bank_customer/oneKycpartner'
  || url == '/bank_customer/mccmpartner'
  || url == '/pan/panvalidationpartner'
  || url == '/pre_approved_offer/lopallofferspartner'
  || url == '/pre_approved_offer/getlopproductofferspartner'
  || url == '/bank_customer/lopDigiBrepartner'
  || url.includes('/initiate')
  || url.includes('/TriggerRMEmail')
  || url.includes('/TriggerCustomerPaymentPending')
  || url == '/loans-service/saveProfessionpartner'  
  || url == '/loans-service/updateTrackpartner'
  || url == '/loans-service/getactiveloandetailspartner'
  || url == '/ucj-bre/unifiedplBrepartner'
  || url == '/ucj-bre/imputedBrepartner'
  || url == '/forms_capture/generateApplicationpartner'
  || url == '/credit-score/bu-one_personal_loanpartner'
  || url == '/crm/plCRMServicepartner'
  || url == '/fraud-check/posidexpartner'
  || url == '/fraud-check/checkAllpartner'
  || url == '/fraud-check/fircosoftpartner'
  || url == '/aggregator-backend/transaction-statuspartner'
  || url == '/aggregator-backend/reportpartner'
  || url == '/aggregator-backend/download-reportpartner'
  || url == '/loans-service/generateScoreCardTokenpartner'
  || url.includes('/getBankDetailsFromIFSC')
  || url == '/loans-service/saveOfficeDetailspartner'
  || url == '/loans-service/saveConsentQuestionspartner'
  || url == '/loans-service/saveIFSCCodepartner' 
  || url == '/personalLoan/saveAdditionalDetailsPLpartner'
  ||url == '/personalLoan/get-detailspartner'
  ||url == '/bank-customer/cKYCforPLpartner'
  ||url == '/loans-service/showcommunicationaddresspartner'
  ||url == '/crm/plUpdateCRMServicepartner'
  ||url == '/loans-service/enachCheckpartner'
  ||url == '/loans-service/getOneKycStatuspartner'
  ||url.includes('/generateSharecode')
  ||url == '/ucj-enach/personalLoanEnachDatapartner'
  ||url == '/ucj-enach/personalLoanIFSCCodepartner'
  || url == '/loans-service/financialavailabledetailspartner'
  || url == '/loans-service/savePLLoanDetailspartner'
  || url == '/loans-service/saveOrganisationpartner'
  || url == '/loans-service/saveOfficeEmailpartner'
  || url == '/customerInfo/eve-postpartner'
  || url == '/instaEotp/verifyOfficeEmailOTPpartner'
  || url == '/instaEotp/generateOfficeEmailOTPpartner'
  || url == '/instaMaster/getOrganisationNamepartner'
  || url == '/ucj-bre/unifiedplBrepartner'
  || url == '/aggregator-backend/set-url-datapartner'
  || url == '/aggregator-backend/get-url-datapartner'
  || url == '/aggregator-backend/initiationpartner'
  ||url.includes('/runcheck')
  || url == '/partnerjourney/transaction'
  || url == '/partnerjourney/saveData'
  ||url.includes('/enachFlow')
  ||url.includes('/ocrCallBackData')
  ||url.includes('/verifyOcrToken')
  ||url.includes('/getDocumentInternal')
  ||url.includes('/signDetection')
  ||url.includes('/getPDF')
  ||url == '/loans-service/getThankYouPageDetailspartner'
  ||url == '/ucjinstarcas/rcascasecreationpartner'
  ||url == '/instaMaster/getMasterCastepartner'
  ||url == '/instaMaster/getMaritalStatuspartner'
  ||url == '/instaMaster/getReligionspartner'
  ||url == '/instaMaster/getNewResidentTypespartner'
  ||url == '/instaMaster/getDesignationspartner'
  ||url == '/instaMaster/getFacilitiespartner'
  ||url == '/instaMaster/getQualificationspartner'
  ||url == '/instaMaster/getallcitiespartner'
  ||url == '/instaMaster/getEmploymentTypepartner'
  ||url == '/instaMaster/getGradepartner'
  ||url == '/instaMaster/getStateByPincodepartner'
  ||url == '/instaMaster/getCityListByStateIdpartner'
  ||url == '/instaMaster/getUniversityNamepartner'
  ||url.includes('/sendFdCronConfirmationEmail')
  ||url.includes('/sendFdConfirmationEmail')
  ||url.includes('/lamf/OmnidocsMethod')
  || url.includes('/esignPdfManualTrigger')
  || url == '/instanewesign/esignSessionCron'
  || url == '/crm/plCRMServiceCron'
  || url == '/crm/cronPlCreateCrmForDropJourney'
  || url.includes('/saveCrossSellData')
  || url.includes('/crossSellHardStopApi')
  || url.includes('/crossSellHardStopApiCron')
  || url.includes('/pincodeHardStop')
  || url.includes('/solIdHardStop')
  || url.includes('/sqlIdPincodeMap')
  || url.includes('/imputedBreInternal')
  || url.includes('/v2/incomeBre')
  || url == 'aggregator-backend/AggregatorTransactionStatusCron'
  || url == 'aggregator-backend/initiationCron'
  || url == 'aggregator-backend/download-reportCron'
  || url == 'perfios_netbanking_backend/perfiosV2-generateLinkCron'
  || url == 'perfios_netbanking_backend/perfiosV2-retrieveReportCron'
  || url == 'perfios_netbanking_backend/perfiosV2-transactionStatusCron'
  || url == 'communication/sendEmailCommunication'
  || url == 'loans-service/generateScoreCardTokenCron'
  || url == 'fraud-check/checkPLFircosoftStatusCron'
  || url == 'ucj-bre/unifiedCCBreCron'
  || url == 'ucj-bre/unifiedplBreCron'
  || url.includes('/bureau-one-savings')
  || url.includes('/savings-bre-internal_crosssell')
  || url.includes('/lopSavingsOffercrosssell')
  || url.includes('/forexOmnidoxMethodCron')
  || url.includes('/updateAccountStatus')
  || url.includes('/plenachcallback')
  || url.includes('/ntbFdReportCreationCron')
  || url.includes('/sendHomeLoanConfirmationEmail')
  || url.includes('/sendHomeLoanCronConfirmationEmail')
  || url == '/ucj-bre/unifiedCCBrepartner'
  || url == '/credit-score/bu-one_ccpartner'
  || url == '/crm/ccCRMServicepartner'
  || url == '/personalLoan/getBreDetailspartner'
  || url == '/loans-service/captureEventpartner'
  || url.includes('/manualForexTrigger')
  || url == '/amazon/amazonSaMisReportCron'
  || url == '/email/emailConfirmationpartner'
  || url == '/ucj_cc_disbursemenmt/gemspartner'
  || url == '/ucj_cc_disbursemenmt/createCreditCardpartner'
  || url == '/ucj_cc_disbursemenmt/fetchCreditCardpartner'
  || url == '/ucj_cc_disbursemenmt/primeAddonCCCron'
  || url == '/addoncc/generateAddOnCCReportCron'
  || url == '/ucjcc/generateCreditCardReportpartner'
  || url == '/paylater/createpaylaterodaccountCron'
  || url == '/paylater/fundtransferPaylater'
  || url.includes('/cronrcasalcasecreation')
  || url.includes('/getLoanApplicationStatus')
  || url.includes('/initiateOemMarutiAldd')
  || url.includes('/sendSmsConfirmation')
  || url.includes('/sendCronSmsConfirmation')
  || url.includes('/v1/revolver')
  || url.includes('/loans-service/v1/fetchRelationShipInternal')
  || url.includes('/loans-service/v1/fetchEmiInternal')
  || url.includes('/crossSellOmnidocsCron')
  || url.includes('/blockOfferPlCron')
  || url == '/loans-service/saveDeliveryAddresspartner'
  || url == '/homeloan/generateHomeloanMisReportCron'
  || url === '/ppf/v1/ppfAccountCron'
  || url === '/instanewesign/v1/pdf/ppfcron'
  || url === '/nps/v1/npsAccountCreation'
  || url === '/nps/v2/pranverification'
  || url.includes('/generateAlMisReportCron')
  || url.includes('/cronsaveALrcaspayload')
  || url === '/ucj_cc_disbursemenmt/gemsStatus'
  || url.includes('/v1/selfEmployed')
  || url == '/vkyc/recruitEkycCron'
  || url.includes('/smsAlertNotification')    
  || url.includes('/smsAlertCronNotification') 
  || url.includes('/sendCommunication') 
  || url.includes('/crmUpdateServiceCron')
  || url.includes('/twlCRMServiceCron')
  || url == '/bank-customer/maskedOneKycCustomerInternal'
  || url.includes('/v2/eligibilityCheck')
  || url.includes('/saveALIrrDataInternal')
  || url == '/track_journey/verifyResumeJourney'
  || url == '/track_journey/dbCombinationCheck'
  || url.includes('/aldd/Omnidocs')
  || url.includes('/whatsappNotificationCron')
  || url.includes('/whatsappNotification')
  || url == '/homeloan/pahlsanctionletterGenerationCron'
  || url.includes('/getEsignSignedPDF')
  || url.includes('/emailDropOffNotification')
  || url.includes('/loansDDAutoSms')
  || url=='/pan/V2/panvalidationInternal'
  || url.includes('/generateNonPaLapMisReportCron')
  || url.includes('/generateAdaniCCReportCron')
  || url.includes('/generateAmazonCCReportCron')
  || url.includes('/sendCronCommunication')
  || url=='/bank-customer/iCoreCustomerInternal'
  || url == '/homeloan/generatePaHlMisReportCron'
  || url.includes('/vkycSignPhotoDownload')
  || url.includes('/vkycFileDownload')
  || url == '/ucj-bre/unifiedPartnerCCBreCron'
  || url == '/mispartner/partnerReverseStatusCron'
  || url == '/loanDisbursementAlTopUpCron'
  || url.includes('/autoloan/demogSaveBasicInfo')
  || url.includes('/nri/omnidocsMethod')
  || url.includes('/nri/multipleFileUpload')
  || url == '/ucj_support/adminGetLeadId'
  || url == '/ucj_support/adminApplication-logs'
  || url == '/ucj_support/admingetapplicationnodata'
  || url == '/ucj_support/adminGetMasterData'
  || url == '/mispartner/generateMmtCCReportCron'
  || url == '/bank-customer/v2/maskedOneKycCustomerInternal'
  || url.includes('/wealthOrFamily360Banner')
  || url.includes('/lamf/generateLamfReportCron')
  || url == '/palap/savepalapsareportdetailsCron'
  || url == '/hl24hrtopup/generate24topupMisReportCron'
  || url.includes('/alRcasCrmCron')
  || url == '/mispartner/generatesupportotp'
  || url == '/mispartner/verifysupportotp'
  || url == '/mispartner/downloadPartnerMisReport'
  || url == '/mispartner/getPartnerMisReport'
  || url == '/pan/v1/BSBDAPanCheck'
  || url == '/instaEotp/mobileUserExists'
  || url == '/instanewesign/agreement-pdf'
  || url == '/ucj_instanewirr_calc/kfs-repayment-schedule'
  || url.includes('/sendNpsEmail')
  || url.includes('/CrossSellApi')
  || url.includes('/createCRMLeadForm')
  || url.includes('/autoloanbackend/CronAuditTrialALDDStp')
  || url.includes('/croncrmEntry')
  || url.includes('/CronautoMail')
  || url.includes('/cronDeliveryOrderGenerator')
  || url == '/instanewesign/digiCamGeneratorCron'
  
) {
    response.writeHead(code, { 'Content-Type': 'application/json' });
    response.end(payload);
  } else {
    try {
      const key = response.encKey;
      response.encKey = '';
      const value = crypt.encrypt(payload, key);
      const data = JSON.stringify({
        part1: value,
        part2: response.txnId,
      });
      response.writeHead(code, { 'Content-Type': 'application/json' });
      response.end(data);
    } catch(err){
      console.error(`Error in fe-be encryption ${JSON.stringify(err)}`);
    }
  }
};

module.exports = {
  writeJson,
};