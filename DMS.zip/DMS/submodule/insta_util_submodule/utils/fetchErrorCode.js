/* eslint-disable max-len */
const Logger = require('./logger');

const logger = new Logger();
const fetchErrorData = require('../api/service/fetchErrorCodeService');
const CONSTANTS = require('../../insta_constants_submodule/constants/constant');

const fetchErrorCode = async (error, leadId, personId) => {
  logger.debug(`FETCH ERROR CODE | leadId | ${leadId} | ERROR CODE DATA | ${error} | ${JSON.stringify(error)} `);
  try {
    const condition = { error_short_desc: error };
    const errCode = await fetchErrorData.fetchDataFromErrorCodeTable(condition);
    logger.debug(`FETCH ERROR CODE | leadId | ${leadId} | ERROR CODE RESPONSE | ${errCode} | ${JSON.stringify(errCode)}`);
    if (leadId !== 'noLead') {
      const logErrorData = {
        lead_id: leadId,
        person_id: personId,
        error_id: (errCode && errCode[0] && errCode[0].id) ? errCode[0].id : null,
      };
      logger.debug(`FETCH ERROR CODE | leadId | ${leadId} | logErrorData | ${logErrorData} | ${JSON.stringify(logErrorData)}`);
      const result = await fetchErrorData.createLogError(logErrorData);
      logger.debug(`FETCH ERROR CODE | leadId | ${leadId} | createLogError | result | ${result} | ${JSON.stringify(result)}`);
    }
    if (errCode && errCode[0] && errCode[0].error_code) {
      if(errCode[0].act_code){
        return{
          error_code: errCode[0].error_code,
          act_code: errCode[0].act_code
        }
      };
      return{
        error_code: errCode[0].error_code
      }
    }
    return CONSTANTS.EMPTY;
  } catch (err) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | FETCH ERROR CODE | leadId | ${leadId} | ERROR RESPONSE RECIEVED CATCH BLOCK | ${err} | ${JSON.stringify(err)}`);
    return CONSTANTS.EMPTY;
  }
};

const sendErrorCode = async (response, leadId, personId) => {
  logger.debug(`SEND ERROR CODE | leadId | ${leadId} | RESPONSE |  ${JSON.stringify(response)}`);
  if (response && !response.error) {
    const errCodeData = await fetchErrorCode(CONSTANTS.ERR_MESSAGE.UNIDENTIFIED_ERROR, leadId, personId);
    logger.debug(`SEND ERROR CODE | leadId | ${leadId} | ERROR CODE DATA |  ${JSON.stringify(errCodeData)}`);
    return new Promise((resolve) => resolve({ status: response.status, errorCode: errCodeData.error_code, actCode: errCodeData.act_code }));
  // eslint-disable-next-line no-else-return
  } else {
    const errCodeData = await fetchErrorCode(response.error, leadId, personId);
    logger.debug(`SEND ERROR CODE | leadId | ${leadId} | ERROR CODE DATA |  ${JSON.stringify(errCodeData)}`);
    return new Promise((resolve) => resolve({ status: response.status, errorCode: errCodeData.error_code, actCode: errCodeData.act_code }));
  }
};


module.exports = { fetchErrorCode, sendErrorCode };
