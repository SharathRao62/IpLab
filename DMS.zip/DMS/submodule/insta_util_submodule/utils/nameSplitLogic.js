const CONSTANTS = require('../../insta_constants_submodule/constants/constant');
const Logger = require('./logger');


const nameSplit = (splitName) => new Promise((resolve, reject) => {
  const logger = new Logger('nameSplit');
  try {
    const splitname = {};
    let name1 = '';
    let name2 = '';
    let name3 = '';
    let temp = '';
    let name = splitName;

    if (name !== '' && name != null && name !== 'null') {
      name = name.replace(CONSTANTS.REPLACE_SPL_CHAR_REG_EXP_01, ' ').replace(/-/g, '');
      name = name.trim();
      if (name.indexOf(' ') >= 0) {
        name1 = name.substr(0, name.indexOf(' '));
        temp = name.substr(name.indexOf(' ') + 1);
        temp = temp.trim();

        if (temp && temp.indexOf(' ') >= 0) {
          name2 = temp.substr(0, temp.indexOf(' '));
          name3 = temp.substr(temp.indexOf(' ') + 1);
        } else {
          name2 = '';
          name3 = temp;
        }
      } else {
        name1 = name;
        name2 = '';
        name3 = '';
      }
      name1 = name1.trim();
      name2 = name2.trim();
      name3 = name3.trim();
      if (name1) {
        splitname.first = name1;
      }
      if (name2) {
        splitname.middle = name2;
      }
      if (name3) {
        splitname.last = name3;
      }
      logger.info('Name SPlit |  splitted name values', splitname);
      resolve({ splitname });
    } else {
      logger.info('Name SPlit |  name is empty', splitname);
      resolve({ splitname });
    }
  } catch (err) {
    const error = {
      err: ' error while splitting name logic ',
    };
    reject(error);
  }
});
module.exports = {
  nameSplit,
};
