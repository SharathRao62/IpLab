/* eslint-disable no-async-promise-executor */
const Logger = require('./logger');

const logger = new Logger();
const sendErrorCode = require('./fetchErrorCode');

const CONSTANTS = require('../../../constants/constant');


const handleErrorCode = (response, leadId,
  defaultErr, personId) => new Promise(async (resolve) => {
  logger.debug(`HANDLE ERROR CODE | leadId | ${leadId} | RESPONSE |  ${JSON.stringify(response)} | defaultErr | ${defaultErr}`);
  let errorVal;
  let errorCode;
  logger.debug(`HANDLE ERROR CODE | leadId | ${leadId} | RESPONSE |  ${JSON.stringify(response)}`);

  try {
    if (response && !response.error) {
      response.error = defaultErr;
      logger.debug(`HANDLE ERROR CODE | leadId | ${leadId} | RESPONSE |  ${JSON.stringify(response)}`);
      errorVal = await sendErrorCode.sendErrorCode(response, leadId || 'noLead', personId || null);
    } else if (response && response.error !== 'SUCCESS') {
      errorVal = await sendErrorCode.sendErrorCode(response, leadId || 'noLead', personId || null);
    }
    logger.debug(`HANDLE ERROR CODE | leadId | ${leadId} | errorVal |  ${JSON.stringify(errorVal)} | ${errorVal}`);
    if (errorVal && errorVal.errorCode) {
      errorCode = {
        errorCode : errorVal.errorCode,
        actCode : errorVal.actCode
      }
    } else {
      errorCode = '';
    }
    return resolve(errorCode);
  } catch (error) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | HANDLE ERROR CODE | leadId | ${leadId} | error |  ${JSON.stringify(error)}`);
    return resolve('');
  }
});

module.exports = { handleErrorCode };
