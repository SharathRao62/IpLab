// const requestWithPromise = require('request-promise');
// const Logger = require('./logger');

// const logger = new Logger();
const CONSTANTS = require('../../insta_constants_submodule/constants/constant');
const config = require('../../../config/environConfig');
const configEnc = require('../../insta_config_submodule/config/environConfig');
const Logger = require("../utils/logger");

// const {
//   ENTERING_TO, UTIL_METHOD, METHOD, FILES,
// } = require('../../insta_constants_submodule/constants/constantLogger');

// const { restAPICall } = require('./restCalls');
const { restAPICall } = require('./axiosCall');

const encryptData = (data, environment, key, logOptions = true) => {
  // logger.debug(`${ENTERING_TO} ${FILES.ENCRYPT_DECRYPT} ${UTIL_METHOD} ${METHOD.ENCRYPT_DATA}`);

  let apiSpecificKey = '';
  if (key === 'wheels_specific_enc' && (environment === 'production' || environment === 'pre_prod' || environment === 'prod_beta')) {
    apiSpecificKey = key;
  }

  const message = (typeof data === 'object') ? JSON.stringify(data) : data;
  let url = (environment === CONSTANTS.PRODUCTION || environment === 'pre_prod' || environment === 'prod_beta') ? configEnc.ENCRYPT_URL_PROD : configEnc.ENCRYPT_URL;
  if (environment === 'qa') url = 'https://buyqa.niveussolutions.com/apirequestencryption/encryption';
  const options = {
    method: CONSTANTS.API_TYPE.POST,
    url,
    body: { message },
    headers: {
      'content-type': 'application/json',
    },
    timeout: config.TIME_OUT,
    json: true,
  };
  if (key) {
    if (key === 'xbiz_fileUpload_enc') options.url = config.ENCRYPT_URL;
    options.body.apiSpecificKey = key;
  }

  if (apiSpecificKey) options.body.apiSpecificKey = apiSpecificKey;
  // return requestWithPromise(options);
  return restAPICall(options);
};

const decryptData = (message, key, environment, apikey = null) => {
  const logger = new Logger(`decryptData | apikey | ${apikey}`);

  let apiSpecificKey = '';
  if (apikey && apikey === 'wheels_specific_enc' && (environment === 'production' || environment === 'pre_prod' || environment === 'prod_beta')) {
    apiSpecificKey = apikey;
    logger.info(`apiSpecificKey | ${apiSpecificKey}`)
  }

  let url = (environment === CONSTANTS.PRODUCTION || environment === 'pre_prod' || environment === 'prod_beta') ? configEnc.DECRYPT_URL_PROD : configEnc.DECRYPT_URL;
  if (environment === 'qa') url = 'https://buyqa.niveussolutions.com/apirequestencryption/decryption';
  const options = {
    method: CONSTANTS.API_TYPE.POST,
    url,
    body: { message, key },
    headers: {
      'content-type': 'application/json',
    },
    timeout: config.timeOut,
    json: true,
  };
  if (apikey === 'xbiz_fileUpload_enc') options.url = config.DECRYPT_URL;
  // logger.debug(`DECRYPT PAYLOAD : ${JSON.stringify(options)}`);
  // return requestWithPromise(options).then((res) => {
  //   logger.debug(`DECRYPT DATA RESULT : ${JSON.stringify(res)}`);
  //   return res;
  // });

  if (apiSpecificKey) options.body.apiSpecificKey = apiSpecificKey;
  logger.info(`option | ${JSON.stringify(options)}`)
  return restAPICall(options);
};

const encryptDataXML = (data, environment) => {
  // logger.debug(`${ENTERING_TO} ${FILES.ENCRYPT_DECRYPT} ${UTIL_METHOD} ${METHOD.ENCRYPT_DATA}`);
  const options = {
    method: CONSTANTS.API_TYPE.POST,
    url: (environment === CONSTANTS.PRODUCTION || environment === 'pre_prod' || environment === 'prod_beta') ? configEnc.ENCRYPT_URL_PROD : configEnc.ENCRYPT_URL,
    body: { message: data },
    headers: {
      'content-type': 'application/json',
    },
    timeout: config.TIME_OUT,
    json: true,
  };
  // return requestWithPromise(options);
  return restAPICall(options);
};

module.exports = {
  encryptData,
  decryptData,
  encryptDataXML,
};
