const jwt = require('jsonwebtoken');
const Logger = require('./logger');

const logger = new Logger();
const {
  ENTERING_TO, FILES, UTIL_METHOD, METHOD,
} = require('../../insta_constants_submodule/constants/constantLogger');

// const secretKey = 'sdeddevew3dmkm';
const secretKey = 'd9f638abe8e9e5'


const jwtSign = (payload, expiresIn = 60 * 40) => {
  return jwt.sign(payload, secretKey, { expiresIn });
};


const jwtVerify = (payload) => {
  new Logger(`${ENTERING_TO} ${FILES.JWT} ${UTIL_METHOD} ${METHOD.JWT_VERIFY}`);
  return jwt.verify(payload, secretKey);
};

// 171901 start jan 16 2023
const jwtDecode = (payload) => {
  return jwt.decode(payload)
}
// 171901 end jan 16 2023



module.exports = { jwtSign, jwtVerify, jwtDecode };
