/* eslint-disable brace-style */
/* eslint-disable no-lonely-if */
/* eslint-disable consistent-return */
const Logger = require('./logger');
const leadService = require('../api/service/leadService');
const logger = new Logger();
const config = require('../../../config/environConfig');
const properties = require("../../../package.json");
const environment = process.env.NODE_ENV;
const jwt = require('./jwt'); // 171901 jan 16 2023

// Admin Portal
const whitelistExternal = [ 'https://instaadmin.icicibank.com'];

const adminAccess = (url) => {
  return (url.includes('/generateAdminEmailOtp')
  || url.includes('/verifyAdminEmailOtp')
  || url.includes('/fetchPublicKey')
  || url.includes('/coinToss')
  || url.includes('/partByPart')
  || url.includes('/adminGetLeadId')
  || url.includes('/admingetapplicationnodata')
  || url.includes('/adminGetMasterData')
  || url.includes('/adminApplication-logs'));
}

// 171901 start jan 16 2023
const fetchAcccountTypeMicro = async (req, res) => {
  if(req && req.body && req.body.lead_id && (!req.headers || !req.headers.authorization)){
  let sqlQuery;
  let conditions;
    logger.debug(`fetchAcccountTypeMicro | request data with out header`)
    conditions = { leadId: req.body.lead_id.toString() };
    sqlQuery = `select jwt_token from auth where lead_id =:leadId`;
  
  const verifyData = await leadService.getALLDetails(sqlQuery, conditions);
  logger.debug(`fetchAcccountTypeMicro | verifyData - ${JSON.stringify(verifyData)} `);
  if (!verifyData || !verifyData[0] || !verifyData[0].jwt_token) {
    logger.error('fetchAcccountTypeMicro| USER NOT FOUND');
    return Promise.resolve({ status: 403 });
  } else {
    const response = await jwt.jwtDecode(verifyData[0].jwt_token);
    logger.debug(`fetchAcccountTypeMicro | Adding required data to request body`);
    if(response && response.product && response.product_id){
    req.body.account_type = response.product.toString();
    const accountList = ['INSTA SAVE ACCOUNT','INSTA SALARY ACCOUNT']; // Panchami 211971
    if(accountList.includes((req.body.account_type).toUpperCase()))
    {
      sqlQuery = `select journey_id from \`lead\` where lead_id =:leadId`;
      const journeyId = await leadService.getALLDetails(sqlQuery, conditions);
      logger.info(`fetchAcccountTypeMicro | journey_id | ${journeyId}`);
      req.body.journeyId = journeyId[0] ? journeyId[0].journey_id : null;
    } // Panchami 211971
    req.body.product_id = response.product_id;
    }
    return 1;
  }
}
}
// 171901 end jan 16 2023

const securityFunction = async (payload, response) => {
  logger.debug('Access-Control-Allow-Origin | ENVIRONMENT', environment);
  const allowedMethods = ['GET', 'OPTIONS', 'POST', 'HEAD'];
  logger.debug(`Access-Control-Allow-Origin | ALLOWED METHODS | ${allowedMethods} | payload METHOD | ${payload.method} | payload.url | ${payload.url}`);
 if((JSON.stringify(payload.body) !== '{}') && !payload.url.includes('/generateMobileOtpOrShortlink') && !payload.url.includes('/saveGenerateMobileOtpShuffle') && !payload.url.includes('/saveVerifyMobileOtpShuffle') && !payload.url.includes('/getLeadsForPersonKyc') && !payload.url.includes('/v1/generateOtp') && !payload.url.includes('/v1/verifyOtp')){
  logger.debug(`Access-Control-Allow-Origin | check the data has account`);
  const result = await fetchAcccountTypeMicro(payload, response);
  logger.debug(`Access-Control-Allow-Origin | result | ${JSON.stringify(result)}`);
  if(result && result.status === 403){
    logger.debug(`Access-Control-Allow-Origin | Invalid user`);
    return response.status(403).json('Invalid user');
  }
 }

  let myStringVal;
  const domainUrl = config.DOMAIN_URL ? config.DOMAIN_URL : null;
  logger.debug('Access-Control-Allow-Origin | DOMAIN URL', domainUrl);
  const originVal = payload.headers.host;
  logger.debug('Access-Control-Allow-Origin | IN STAGING');
  logger.debug('Access-Control-Allow-Origin | CORSE WHITE LIST', config.corsWhitelist);
  logger.debug('Access-Control-Allow-Origin | ORIGIN', originVal);
  const localHostVal = originVal.substring(0, originVal.indexOf(':'));
  logger.debug('Access-Control-Allow-Origin | LOCAL HOST VALUE', localHostVal);

  if (!localHostVal) {
    myStringVal = originVal.substring(originVal.lastIndexOf('.', originVal.lastIndexOf('.') - 1) + 1);
  } else {
    myStringVal = localHostVal;
  }

  logger.debug('Access-Control-Allow-Origin | MY STRING VALUE', myStringVal);
  /* this piece of code should not be moved to production begin -- used to allow localhost (for fe to local test) */
  if (payload && payload.headers && payload.headers.origin && (environment !== 'pre_prod' && environment !== 'production')) {
    const reqOrigin = payload.headers.origin;
    logger.debug(`Access-Control-Allow-Origin | payload ORIGIN | ${reqOrigin}`);
    const subStringVal = reqOrigin.substring(
      reqOrigin.lastIndexOf('/') + 1,
      reqOrigin.lastIndexOf(':'),
    );
    logger.debug('Access-Control-Allow-Origin | SubstringVal', subStringVal);
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  } /* this piece of code should not be moved to production end */
  else {
    if (config.corsWhitelist.includes(myStringVal) && allowedMethods.includes(payload.method)) {
      logger.debug('Access-Control-Allow-Origin | IT HAS VALUE');
      if (whitelistExternal.includes(payload.headers.origin) && adminAccess(payload.url)) {
        response.setHeader('Access-Control-Allow-Origin', payload.headers.origin);
      }
      else {
        response.setHeader('Access-Control-Allow-Origin', originVal);
      }
      response.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    } else {
      logger.debug('Access-Control-Allow-Origin | DOES NOT HAVE THE VALUE');
      response.setHeader('Access-Control-Allow-Origin', domainUrl);
      response.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      logger.debug('Access-Control-Allow-Origin | next');
      return response.status(404).json('Not allowed to access');
    }
  }
};


module.exports = { securityFunction };
