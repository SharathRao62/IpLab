const Logger = require("./logger");
const axios = require("axios");
const mockResponse = require("../utils/mockResponse");
const { maskdata } = require("./logMasking");
const { ERROR_CODE } = require("../../insta_constants_submodule/constants/constant");

const restAPICall = async (options, mock) => {
  const logger = new Logger(`METHOD: AXIOS REST API CALL`);
  let mockData = null;
  if (mock) {
    mockData = await mockResponse.mockResponse(mock);
    logger.debug(`restAPICall | mockData | ${JSON.stringify(mockData)}`);
  }
  if (mockData && mockData.mock_status === true) {
    return mockData;
  } else {
    try {
      let { url, method, headers, body, timeout } = options;

       // if it is an external call then update internalCall variable
       let internalCall = true;
       if (url.includes('apibankingone.icicibank.com') || url.includes('apibankingonesandbox.icicibank.com')) {
         internalCall = false;
       }
 
      let config = {
        method,
        url,
        headers,
        data: body,
        timeout,
      };

      // If it is TIG and If it is not an internal request
      if (process.env.TIG === 'true' && !internalCall) {
        config.proxy = {
          protocol: 'http',
          host: '10.229.3.88',
          port: 80,
        };
      };

      const result = await axios(config);
      let { data, status } = result;
      let response = {
        data,
        status,
      };
      logger.debug(`External Call | success |${maskdata(response)}`);
      return response;
    } catch (err) {
      let errorResponse = {};
      if (err.response) {
        let { data, status } = err.response;
        errorResponse = {
          data,
          status,
        };
        logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} | failed |${maskdata(errorResponse)}`);
      } else {
        errorResponse = {
          data: err,
          status: 500,
        };
        logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} | failed |${maskdata(errorResponse)}`);
      }
      return errorResponse;
    }
  }
};

module.exports = { restAPICall };
