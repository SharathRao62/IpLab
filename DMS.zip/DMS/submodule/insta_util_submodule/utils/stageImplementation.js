/* eslint-disable max-len */
/* eslint-disable radix */
const { lead, products, master_stage_page: masterStagePage } = require('../../../models');
const Logger = require('./logger');

const logger = new Logger();

const getStageCode = (eventType, product) => masterStagePage.findOne({
  attributes: ['id', 'stage'],
  where: {
    stage_description: eventType,
    product_id: product,
  },
  raw: true,
});

const getStageCodeByID = (id, product) => masterStagePage.findOne({
  attributes: ['id', 'stage', 'stage_description'],
  where: {
    id,
    product_id: product,
  },
  raw: true,
});

const getCurrentStage = (leadId) => lead.findOne({
  attributes: ['stage_page_id', 'account_type'],
  where: {
    lead_id: leadId,
  },
  raw: true,
});

const getFlow = (leadId) => products.findOne({
  attributes: ['flow', 'product_name'],
  where: {
    lead_id: leadId,
  },
  raw: true,
});

const updateCurrentStage = (updateData, leadId) => {
  logger.debug(`LEAD ID | ${leadId}`);
  return lead.update(
    updateData,
    {
      where: {
        lead_id: leadId,
      },
    },
  );
};

const getPage = async (leadId) => {
  logger.debug(`63dcbfca679e9 LEAD ID | ${leadId}`);
  const sqlQuery = "SELECT msp.next_page from `lead` l, master_stage_page msp where l.lead_id = '" + leadId + "' and msp.id = l.stage_page_id";
  let [page] = await masterStagePage.sequelize.query(
    sqlQuery,
    {
      type: lead.sequelize.QueryTypes.SELECT,
    },
  );

  logger.debug(`63dcbfca679e9 page | ${JSON.stringify(page)}`);
  if (page && page.next_page) {
    return page.next_page;
  }
  else {
    return null;
  }
}

const stage = async (stageDescription, leadId) => {
  logger.updateInfo('Stage Implementation', leadId);

  logger.debug(`stage_description | ${stageDescription}`);

  if (!stageDescription || !leadId) {
    throw new Error('Stage Description or leadId is missing');
  }

  let currentStage;
  try {
    currentStage = await getCurrentStage(leadId);
    logger.debug(`getCurrentStage | ${JSON.stringify(currentStage)}`);
  } catch (error) {
    logger.error(`getCurrentStage | ${JSON.stringify(error)}`);
    throw new Error(error);
  }

  let currentStageCode;
  if (currentStage.stage_page_id) {
    try {
      currentStageCode = await getStageCodeByID(currentStage.stage_page_id, currentStage.account_type);
      logger.debug(`currentStageCode | ${JSON.stringify(currentStageCode)}`);
    } catch (error) {
      logger.error(`currentStageCode error | ${JSON.stringify(error)}`);
      throw new Error(error);
    }
  }

  let newStageCode;
  try {
    newStageCode = await getStageCode(stageDescription, currentStage.account_type);
    logger.debug(`newStageCode | ${JSON.stringify(newStageCode)}`);
  } catch (error) {
    logger.error(`newStageCode error | ${JSON.stringify(error)}`);
    throw new Error(error);
  }

  if (!newStageCode) {
    throw new Error('Stage Page is not defined in the DB');
  }

  if (currentStage.stage_page_id && (parseInt(newStageCode.stage) < parseInt(currentStageCode.stage))) {
    logger.debug(`No update in stage!, New Stage ${newStageCode.stage} - ${stageDescription} is less than the old stage ${currentStageCode.stage} - ${currentStageCode.stage_description}`);
    return 'no update';
  }

  return updateCurrentStage({ stage_page_id: newStageCode.id }, leadId);
};

module.exports = {
  stage, getFlow, getPage
};
