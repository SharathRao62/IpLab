const axios = require('axios');
const Logger = require('./logger');
const mockResponse = require('./mockResponse');
const { ERROR_CODE } = require('../../insta_constants_submodule/constants/constant');
const { errorFormat } = require('./errorFormat');
const environConfig = require('../../insta_config_submodule/config/environConfig')
const igniterConfig = environConfig.IGNITER_KEY;

/**
  * @param {object} options Request
  * @param {string} options.url Request URL.
  * @param {object} options.headers Request headers.
  * @param {object} options.body Request body.
  * @param {number} options.timeout Request timeout.
  * @param {boolean} options.internalCall Request is internal.
  * @param {boolean} options.resolveWithFullResponse Resolve with {statusCode, body}.
  * @returns {Promise}
  */
const restAPICall = async (options, mock) => {
  const logger = new Logger('restAPICall', options.url);

  if (mock) {
    const mockData = await mockResponse.mockResponse(mock);
    logger.debug(`mockData | ${JSON.stringify(mockData)}`);
    if (mockData && mockData.mock_status === true) {
      return mockData;
    }
  }

  /**
   * internalCall: boolean
   * if (true) no proxy addition
   * else add proxy
   */

  /**
   * to match the axios request with request-promise below key is used
   * resolveWithFullResponse: boolean
   * if (true) resolve(body)
   * else resolve({body, statusCode})
   */

  const {
    url,
    method,
    headers,
    body,
    timeout,
    resolveWithFullResponse = false,
  } = options;

  // if it is an external call then update internalCall variable
  let internalCall = true;
  if (url.includes('apibankingone.icicibank.com')
    || url.includes('apibankingonesandbox.icicibank.com')
  ) {
    internalCall = false;
  }

  const config = {
    method,
    url,
    headers,
    data: body,
    timeout,
  };

  // If it is TIG and If it is not an internal request
  // if (process.env.TIG === 'true' && !internalCall) {
  //   config.proxy = {
  //     protocol: igniterConfig.IGNITER_PROTOCOL,
  //     host: igniterConfig.IGNITER_IP,
  //     port: igniterConfig.IGNITER_PORT,
  //   };
  //   logger.info(`config Proxy | ${JSON.stringify(config.proxy)}`);

  // }

  if (process.env.TIG === 'true' && !internalCall) {
    if (igniterConfig) {
      config.proxy = {
        protocol: igniterConfig.IGNITER_PROTOCOL,
        host: igniterConfig.IGNITER_IP,
        port: igniterConfig.IGNITER_PORT,
      };
      logger.info(`config Proxy | ${JSON.stringify(config.proxy)}`);
    } else {
      logger.error('Igniter configuration not found');
    }
  }

  logger.debug(`config | ${JSON.stringify(config)}`);
  try {
    const result = await axios(config);
    // axios response
    const { data, status } = result;
    // convert to request-promise response.statusCode, response.body
    const response = {
      body: data,
      statusCode: status,
    };
    // success 2xx
    logger.debug('success');

    if (resolveWithFullResponse) {
      // resolve with status code { body, statusCode }
      return Promise.resolve(response);
    }
    // resolve only data
    return Promise.resolve(data);
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTEGRATION_API_GATEWAY} | failed |${errorFormat(error)}`);
    let errorResponse = {};

    if (error.response) {
      // failure > 2xx
      const { message, code, response } = error;
      const { data, status } = response;
      errorResponse = {
        error: data,
        statusCode: status,
        message,
        code,
      };
    } else {
      // The request was made but no response was received
      // Timeout Error
      // Refused to connect
      const { status = 500, message, code } = error;
      errorResponse = {
        statusCode: status,
        message,
        code,
        error,
      };
    }
    return Promise.reject(errorResponse);
  }
};

module.exports = { restAPICall };
