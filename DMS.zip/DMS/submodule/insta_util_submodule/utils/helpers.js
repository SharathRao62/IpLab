module.exports.isNil = (val) => val === undefined || val === null;

module.exports.isEmptyArray = (val) => Array.isArray(val) && val.length === 0;