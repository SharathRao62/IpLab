/**
 * Copyright © Niveus Solution Private Limited - All Rights Reserved
 *
 * Proprietary and confidential
 *
 * Used for PGP Encryption and Decryption
 *
 * @summary PGP Encrypt Decrypt
 * @author Vinayak G Kudva(vinayak.kudva@niveussolutions.com)
 *
 * Ref : https://www.npmjs.com/package/openpgp
 * Ref : https://www.loginradius.com/blog/async/using-pgp-encryption-with-nodejs/
 * Created at     : 2020-11-27 22:51:36 
 * Last modified  : 2020-12-16 20:07:57
 */

const openpgp = require('openpgp');
const environConfig = require('../../../insta_config_submodule/config/environConfig');
class PGPEncDec {
    constructor(passPhrase) {
        this.passPhrase = passPhrase;
        this.publicKey = environConfig.PGP_ENCRYPTION_KARZA_PUBLIC_KEY;
        this.privateKey = environConfig.PGP_ENCRYPTION_KARZA_PRIVATE_KEY;
    }

    async generate() {
        const { privateKeyArmored, publicKeyArmored } = await openpgp.generateKey({
            userIds: [{ name: "NiveusSolutions", email: "vinayak.kudva@niveussolutions.com" }],
            rsaBits: 4096,
            passphrase: this.passPhrase,
        });
        this.publicKey = publicKeyArmored;
        this.privateKey = privateKeyArmored;
    }

    async encrypt(plainData) {
        const encrypted = await openpgp.encrypt({
            message: openpgp.message.fromText(plainData),
            publicKeys: (await openpgp.key.readArmored(this.publicKey)).keys[0],
        });
        return (encrypted.data);
    }

    async decrypt(encryptedData) {
        const privateKey = (await openpgp.key.readArmored([this.privateKey])).keys[0];
        await privateKey.decrypt(this.passPhrase);
        const decrypted = await openpgp.decrypt({
            message: await openpgp.message.readArmored(encryptedData),
            privateKeys: [privateKey],
        });
        return (decrypted.data);
    }
}

module.exports = PGPEncDec;
