/* eslint-disable consistent-return */
const CryptoJS = require('crypto-js');
const Logger = require('./logger');

const logger = new Logger();
const configEnc = require('../../insta_config_submodule/config/environConfig');
const extService = require('../external-service/externalCall');
const {
  ERROR_CODE,
} = require('../../insta_constants_submodule/constants/constant');
const { errorFormat } = require('./errorFormat');

const encrypt = (text, secret) => {
  logger.debug(`FE BE ENCRYPTION DECRYPTION | UTILS | TEXT | ${JSON.stringify(text)}`);
  const salt = CryptoJS.lib.WordArray.random(128 / 8);
  const iv = CryptoJS.lib.WordArray.random(128 / 8);
  const encrypted = CryptoJS.AES.encrypt(
    text,
    CryptoJS.PBKDF2(secret, salt, {
      keySize: 256 / 32,
      iterations: 100,
    }) /* key */,
    { iv, padding: CryptoJS.pad.Pkcs7, mode: CryptoJS.mode.CBC },
  );
  logger.debug(`FE BE ENCRYPTION DECRYPTION | UTILS | SALT | ${JSON.stringify(salt)} | IV | ${JSON.stringify(iv)} | ENCRYPTED | ${encrypted} `);

  const transitmessage = salt.toString() + iv.toString() + encrypted.toString();

  return transitmessage;
};

const decrypt = (text, secret) => {
  const key = CryptoJS.PBKDF2(
    secret,
    CryptoJS.enc.Hex.parse(text.substr(0, 32)) /* Salt */,
    { keySize: 256 / 32, iterations: 100 },
  );
  const decrypted = CryptoJS.AES.decrypt(
    text.substring(64) /* encrypted */,
    key,
    {
      iv: CryptoJS.enc.Hex.parse(text.substr(32, 32)) /* iv */,
      padding: CryptoJS.pad.Pkcs7,
      mode: CryptoJS.mode.CBC,
    },
  );
  return decrypted.toString(CryptoJS.enc.Utf8);
};


const feBeEncDecFuntion = async (request, response) => {
  logger.debug('FE BE ENC FUNCTION | PACKET DECRYPTION | request url | decrypt the packet');
  logger.debug(`request url!! | ${JSON.stringify(configEnc.FEBE_ENCRYPTION_DECRYPTION_URL)}`);
  const extData = {
    url: configEnc.FEBE_ENCRYPTION_DECRYPTION_URL, // 'http://ao-fe-be-encryption-decryptionpreprodinternal:5000/uirequestencyption/decryptionFEBE', // configEnc.FEBE_ENCRYPTION_DECRYPTION_URL, // 'https://buystaging.niveussolutions.com/uirequestencyption/decryptionFEBE'
    headers: {
      'content-type': 'application/json',
    },
    timeOut: 12000,
  };
  logger.debug(`EXT DATA | ${JSON.stringify(extData)}`);
  const externalDataVal = {
    message: request.body.part2,
    key: request.body.part2,
  };
  logger.debug(`FE BE ENC FUNCTION | PACKET DECRYPTION | EXT DATA | ${JSON.stringify(extData)} | EXTERNAL DATA VALUE | ${JSON.stringify(externalDataVal)}`);
  try {
    const data = await extService.extCall(extData, externalDataVal);
    // var t = jsdecrypt.dec(privkey, request.body.part2)
    logger.debug(`FE BE ENC FUNCTION | PACKET DECRYPTION | DATA | ${JSON.stringify(data)}`);
    const t = data.body.data;
    const s = await decrypt(request.body.part1, t);
    request.body = JSON.parse(JSON.parse(s));
    response.txnId = request.body.txnId;
    response.encKey = t;
    logger.debug(`FE BE ENC FUNCTION | PACKET DECRYPTION | RESPONSE | ${(response)}`);
    return response;
  } catch (err) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | FE BE ENC FUNCTION | PACKET DECRYPTION | failed |`, JSON.stringify(err), err);
    return Promise.reject(err);
    // response.send(400);
  }
};

module.exports = {
  encrypt,
  decrypt,
  feBeEncDecFuntion,
};
