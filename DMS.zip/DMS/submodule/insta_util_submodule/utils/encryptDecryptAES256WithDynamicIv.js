const crypto = require('crypto');

const Logger = require('./logger');

const logger = new Logger();
const {
  ENTERING_TO, UTIL_METHOD, METHOD, FILES,
} = require('../../insta_constants_submodule/constants/constantLogger');
const configEnc = require('../../../submodule/insta_config_submodule/config/environConfig');

const key = configEnc.DATA_ENCRYPTION_KEY256;
const CONSTANTS = require('../../insta_constants_submodule/constants/constant');

const encrypt256 = (data,key, iv) => {
  logger.debug(`${ENTERING_TO} ${FILES.ENCRYPT_DECRYPT} ${UTIL_METHOD} ${METHOD.ENCRYPT_DATA}`);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
  let encrypted;
  if (typeof data === 'object') {
    encrypted = cipher.update(JSON.stringify(data));
  } else {
    encrypted = cipher.update(data);
  }
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  logger.debug(`ENCRYPTED DATA RESULT FROM UTIL: ${encrypted.toString('base64')}`);
  return new Promise((resolve) => resolve({ iv: iv.toString('base64'), encryptedData: encrypted.toString('base64') }));
};


const decrypt256 = (data, aes256Key, ivKey) => {
  let iv = Buffer.alloc(16);
  let decryptionKey = key;
  if (aes256Key && aes256Key.aes_key) {
    decryptionKey = aes256Key.aes_key;
  }

  if (ivKey) {
    iv = ivKey;
    logger.debug(`ivKey | inside if ${ivKey}`);
  }
  logger.debug(`ivKey | outside if  ${ivKey} | iv | ${iv} | data | ${JSON.stringify(data)}`);
  const encryptedText = Buffer.from(data, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(decryptionKey), iv);

  logger.debug(`DECYPHER: ${decipher}`);
  let decrypted = decipher.update(encryptedText);
  logger.debug(`DECYPHER decypted data: ${decrypted}`);

  decrypted = Buffer.concat([decrypted, decipher.final()]);

  // logger.debug(`DECRYPT DATA RESULT FROM UTIL : ${decrypted.toString()}`);
  return new Promise((resolve) => resolve({ decryptedData: decrypted.toString() }));
};

const generateEncrpytedPayload = (keyVal, data) => {
  const payload = {
    requestId: '',
    service: '',
    encryptedKey: keyVal,
    oaepHashingAlgorithm: CONSTANTS.NONE,
    iv: '',
    encryptedData: data,
    clientInfo: '',
    optionalParam: '',
  };

  return payload;
};
module.exports = {
  decrypt256,
  encrypt256,
  generateEncrpytedPayload,
};
