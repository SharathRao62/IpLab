const requestWithPromise = require('request-promise');
const mockResponse = require('../utils/mockResponse');
const Logger = require('./logger');
const restAPICall = async (options, mock) => {
  const logger = new Logger();
  var mockData = null;
  if (mock) {
    mockData = await mockResponse.mockResponse(mock);
    logger.debug(`restAPICall | mockData | ${JSON.stringify(mockData)}`);
  }
  if (mockData && mockData.mock_status == true) {
    return mockData;
  }
  else
    return await requestWithPromise(options);
}

module.exports = {
  restAPICall,
};