/* eslint-disable import/order */
const configEnc = require('../../../submodule/insta_config_submodule/config/environConfig');
const crypto = require('crypto');

const key = configEnc.DATA_ENCRYPTION_KEY256;
const iv = Buffer.alloc(16);


const maskdata = (data) => {
  if (!data) {
    return '';
  }
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
  let encrypteddata;
  if (typeof data === 'object') {
    encrypteddata = cipher.update(JSON.stringify(data));
  } else if (typeof data === 'number') {
    encrypteddata = cipher.update(JSON.stringify(data));
  } else {
    encrypteddata = cipher.update(data);
  }
  encrypteddata = Buffer.concat([encrypteddata, cipher.final()]);
  return encrypteddata.toString('base64');
};

const mask = (value) => {
  let maskedValue = '';
  if (value && value.length) {
    for (let i = 0; i < value.length; i += 1) {
      maskedValue += '*';
    }
  }
  return maskedValue;
};


module.exports = {
  maskdata, mask,
};
