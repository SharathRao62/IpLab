const bunyan = require("bunyan");
const properties = require("../../../package.json");
const env = process.env.NODE_ENV;
const bformat = require("bunyan-format");

const formatOut = bformat({
  outputMode: "long",
  color: true,
  stream: process.stdout,
});

const { LoggingBunyan } = require("@google-cloud/logging-bunyan");

const loggingBunyan = new LoggingBunyan();

// 202120 logger optimization fixes starts
const envCondition = ["PRODUCTION", "production", "pre_prod", "prod-beta"].includes(env);

// Logs Condition
const streamConditions =
envCondition
  ? [{ stream: env ? process.stdout : formatOut, level: "info" }]
  : [
      { stream: env ? process.stdout : formatOut, level: "debug" },
    ];
// 202120 logger optimization fixes ends

const logger = bunyan.createLogger({
  // The JSON payload of the log as it appears in Stackdriver Logging
  // will contain "name": "my-service"
  name: "icici-logging <INSTA>",
  level: envCondition ? "info" : "debug",
  streams: [
    // Log to the console at 'info' and above
    ...streamConditions,
    // And log to Stackdriver Logging, logging at 'info' and above
    // loggingBunyan.stream("info"),
  ],
});

class Logger {
  constructor(fnName, leadId, trace) {
    this.updateInfo(fnName, leadId, trace);
  }

  updateInfo(fnName, leadId, trace) {
    this.fnName = fnName;
    this.leadId = leadId;
    this.trace = trace;

    if (fnName || leadId || trace)
      this.info('BEGIN');
  }

  info(...msg) {
    let logMsg = `Micro : ${properties.name} |`;
    if (this.fnName) {
      logMsg = `${logMsg} ${this.fnName} | `;
    }

    if (this.leadId) {
      logMsg = `${logMsg} ${this.leadId} | `;
    }

    if (this.trace) {
      logMsg = `${logMsg} ${this.trace} | `;
    }

    msg[0] = `${logMsg} ${msg[0]}`;
    logger.info(...msg);
  }

  debug(...msg) {
    let logMsg = '';
    if (this.fnName) {
      logMsg = `${this.fnName} | `;
    }

    if (this.leadId) {
      logMsg = `${logMsg} ${this.leadId} | `;
    }

    if (this.trace) {
      logMsg = `${logMsg} ${this.trace} | `;
    }

    msg[0] = `${logMsg} ${msg[0]}`;
    logger.debug(...msg);
  }

  error(...msg) {
    let logMsg = '';
    if (this.fnName) {
      logMsg = `${this.fnName} | `;
    }

    if (this.leadId) {
      logMsg = `${logMsg} ${this.leadId} | `;
    }

    if (this.trace) {
      logMsg = `${logMsg} ${this.trace} | `;
    }
    msg[0] = `${logMsg} ${msg[0]}`;
    logger.error(...msg);
  }
}

module.exports = Logger;
