const Logger = require('./logger');
const env = process.env.NODE_ENV || 'development';
const dataEncrypt = require('./encryptDecryptAES256');
const mockService = require('../api/service/mockService')
const fs = require('fs');

const mockResponse = async (data) => {
    const logger = new Logger(`mockResponse | person_id | ${data.person_id}`)
    try{
        const userQuery = 'select c.mobile_personal, product_name from person p join contact c on p.person_id = c.person_id join `lead` l on p.lead_id=l.lead_id join products pr on pr.product_id = l.account_type where p.person_id=:person_id';
        const formCondition = {
            person_id:data.person_id
        }
        const formData = await mockService.getALLDetails(userQuery,formCondition)
        logger.debug(`formData | ${JSON.stringify(formData)}`);
        if(formData && formData[0]){
           const mockData=formData[0];
           var mockMobile = mockData.mobile_personal;
           if(mockMobile && isNaN(mockMobile)){
                const decryptedMobileData = await dataEncrypt.decrypt256(mockMobile);
                if(decryptedMobileData && decryptedMobileData.decryptedData)
                    mockMobile = decryptedMobileData.decryptedData;
           }
                
           logger.debug(`mockMobile | ${mockMobile}`);
           const mockTableData ={
                api_name:data.api_name,
                product:mockData.product_name,
                mobile_no:mockMobile,
                env:env
           }
    
           const mockConfigData = await mockService.getMockConfig(mockTableData);
           logger.debug(`mockConfigData | ${JSON.stringify(mockConfigData)}`);
           if(mockConfigData && mockConfigData.json_file){
                const fileName = mockConfigData.json_file;
    
                const file_data = fs.readFileSync(`${__dirname}/../../../mock_responses/${fileName}`,{encoding:'utf8', flag:'r'})
                const file_data_json = JSON.parse(file_data);
                return{
                    mock_status:true,
                    data: file_data_json[mockConfigData.response_object]
                }
           }
           else{
            return{
                mock_status:false
            }
           }
        }
        else{
            return{
                mock_status:false
            }
        }
    }catch(error){
        logger.error(`error occured | ${JSON.stringify(error)} | ${error}`);
        return{
            mock_status:false
        }
    }
};

const mockObject = async (data) => {
    const logger = new Logger(`mockObject | person_id | ${data.person_id}`)
    try{
        const userQuery = 'select c.mobile_personal, product_name from person p join contact c on p.person_id = c.person_id join `lead` l on p.lead_id=l.lead_id join products pr on pr.product_id = l.account_type where p.person_id=:person_id';
        const formCondition = {
            person_id:data.person_id
        }
        const formData = await mockService.getALLDetails(userQuery,formCondition)
        logger.debug(`formData | ${JSON.stringify(formData)}`);
        if(formData && formData[0]){
           const mockData=formData[0];
           var mockMobile = mockData.mobile_personal;
           if(mockMobile && isNaN(mockMobile)){
                const decryptedMobileData = await dataEncrypt.decrypt256(mockMobile);
                if(decryptedMobileData && decryptedMobileData.decryptedData)
                    mockMobile = decryptedMobileData.decryptedData;
           }
                
           logger.debug(`mockMobile | ${mockMobile}`);
           const mockTableData ={
                api_name:data.api_name,
                product:mockData.product_name,
                mobile_no:mockMobile,
                env:env
           }
    
           const mockConfigData = await mockService.getMockConfig(mockTableData);
           logger.debug(`mockConfigData | ${JSON.stringify(mockConfigData)}`);
           if(mockConfigData && mockConfigData.json_file){
                const fileName = mockConfigData.json_file;
    
                const file_data = fs.readFileSync(`${__dirname}/../../../mock_responses/${fileName}`,{encoding:'utf8', flag:'r'})
                const file_data_json = JSON.parse(file_data);
                return{
                    mock_status:true,
                    data: file_data_json[mockConfigData.response_object]
                }
           }
           else{
            return{
                mock_status:false
            }
           }
        }
        else{
            return{
                mock_status:false
            }
        }
    }catch(error){
        logger.error(`mockResponse error | lead_id | ${data.lead_id} | ${JSON.stringify(error)} | ${error}`);
        return{
            mock_status:false
        }
    }
};


module.exports = { mockResponse, mockObject };