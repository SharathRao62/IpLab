const sysConfig = require('./systemConfigUtils');
const Logger = require('./logger');
const masterService = require('../api/service/masterService');
const Sequelize = require('sequelize');
const { Op } = Sequelize;
// 209585 Panchami Journeywise
const fetchBasedOnJourneyId = async(productName, journeyId, leadId)=> {
  const logger = new Logger(`fetchBasedOnJourneyId | lead_id: ${leadId} | product: ${productName} | journey_id: ${journeyId}`);
  const sysConf = await sysConfig.fetchMultipleSystemConfigurations(productName, ['ENABLE_JOURNEY_BASED_MASTER_DATA'], journeyId);
  logger.info(`sysconfig | ${JSON.stringify(sysConf)}`);

  let condition = {};
  if (sysConf && sysConf['ENABLE_JOURNEY_BASED_MASTER_DATA']) {
    condition = { journey_id: journeyId ? journeyId.toString() : null };
    logger.info(` fetchBasedOnJourneyId_true | ${JSON.stringify(condition)}`);
  } else {
    condition.journey_id = null;
    logger.info(` fetchBasedOnJourneyId_false | ${JSON.stringify(condition)}`);
  }
  
  let productData = await masterService.getProductName({product_name: productName}
  );

  if (!condition.journey_id && productData.product_id) {
    condition.product_id = productData.product_id;
  }
  logger.info(` fetchBasedOnJourneyId | ${JSON.stringify(condition)}`);

  if (!condition.journey_id && !productData.product_id) {
    condition.product_id = null;
    return Promise.reject({ status: 400, message: 'BAD_REQUEST' });
  }

  return condition;
}// Panchami 209585_Journey

  module.exports = {
    fetchBasedOnJourneyId,
  };
  