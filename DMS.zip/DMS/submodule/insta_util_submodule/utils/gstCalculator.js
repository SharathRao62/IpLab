const Logger = require('./logger');
const { errorFormat } = require('./errorFormat');

const logger = new Logger();

const gstCalculate = async (fees, gst) => {
  logger.debug(`gstCalculate | ${errorFormat(fees)} | ${errorFormat(gst)}`);
  return new Promise((resolve, reject) => {
    if ((fees === null || isNaN(fees)) || gst === null || isNaN(gst)) {
      logger.error(`gstCalculate | parameter is not a number | ${errorFormat(fees)} | ${errorFormat(gst)}`);
      throw new Error('gstCalculate | parameter is not a number');
    }
    try {
      const amount = (fees * (1 + gst / 100)).toFixed(3);
      logger.debug(`gstCalculate | amount ${errorFormat(amount)}`);
      resolve(amount);
    } catch (error) {
      logger.error(`gstCalculate | Received error while calculating gst: ${errorFormat(error)}`);
      reject(Error('Error in gstCalculate method'));
    }
  });
};

module.exports = {
  gstCalculate,
};
