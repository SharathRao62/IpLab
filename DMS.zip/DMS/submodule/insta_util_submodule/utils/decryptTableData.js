/* eslint-disable no-restricted-syntax */
/* eslint-disable guard-for-in */
/* eslint-disable no-prototype-builtins */
/* eslint-disable prefer-const */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-param-reassign */
/* eslint-disable no-lone-blocks */
/* eslint-disable max-len */

const Logger = require('./logger');
const {
  ENTERING_TO, BUSINESS_LOGIC_METHOD,
} = require('../../insta_constants_submodule/constants/constantLogger');
const datdecryptAES256 = require('./encryptDecryptAES256');

// function to decrypt data that is stored encrypted in tables used for raw queries.
const decryptTableData = async (packet) => {
  const logger = new Logger('decryptTableData', '', '');
  logger.debug(`${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} BEFORE DECRYPTION ${JSON.stringify(packet)}`);
  let res;
  let resValue;
  for (const key in packet) {
    logger.debug(`KEY ${JSON.stringify(key)}`);
    if (packet.hasOwnProperty(key)) {
      if ((packet[key] !== 'null' || packet[key] !== null || packet[key] !== '' || packet[key] !== undefined) && (typeof packet[key] === 'string')) {
        try {
          res = await datdecryptAES256.decrypt256(packet[key]);
          logger.debug(`RES  ${JSON.stringify(res)}`);
          resValue = res.decryptedData;
        } catch (err) {
          resValue = packet[key];
        }
        packet[key] = resValue;
      }
    }
  }
  logger.debug(`DECRYPTED PACKET ${packet}`);
  return packet;
};

module.exports = {
  decryptTableData,
};
