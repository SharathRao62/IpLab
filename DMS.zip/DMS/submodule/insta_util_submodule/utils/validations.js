const mobileNumberValidation = (mobNo) => {
    const regx = /^[6-9][0-9]{9}$/;
    if (mobNo.match(regx)) {
        return true;
    }
    return false;
};

const panValidation = (pan) => {
    try {
        const regx = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
        if (pan.match(regx)) {
            return true;
        }
        return false;
    } catch (error) {
        console.log('error', error);
        return false;
    }
};

module.exports = {
    mobileNumberValidation, panValidation
};
