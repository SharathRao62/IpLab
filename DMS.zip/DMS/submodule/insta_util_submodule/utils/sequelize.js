const { decrypt256, encrypt256 } = require('./encryptDecryptAES256');
const { errorFormat } = require('./errorFormat');
const { isNil, isEmptyArray } = require('./helpers');

module.exports.decryptColumns = async (columns, list, logger, lead_id = null) => {
    await Promise.all(list.map(async (data) => {
        await Promise.all(columns.map(async (key) => {
            if (data[key]) {
                try {
                    data[key] = (await decrypt256(data[key])).decryptedData;
                } catch (error) {
                    logger.error(`key ${key} | lead ${lead_id} | error ${errorFormat(error)}`);
                }
            }
        }));
    }));
}

/**
 * 
 * @param {Object | Object[]} data 
 * @param {string[]} columns 
 * @returns {Promise}
 * can be used to encrypt the data in beforeCreate and beforeUpdate hooks.
 * applicable for both single object and array of objects.
 * @example 
 * address.beforeCreate(async data => await encryptColumns256(data, columns)); 
 * address.beforeBulkCreate(async data => await encryptColumns256(data, columns));
 * address.beforeUpdate(async data => await encryptColumns256(data, columns));
 * 
 * For bulkUpdate please pass data as data.attributes as shown below
 * address.beforeBulkUpdate(async data => await encryptColumns256(data.attributes, columns));
 * 
 * can also be used with beforeFind Hook for simple where conditions as shown below
 * address.beforeFind(async data =>  await encryptColumns256(data.where, columns));
 * here data should be passed as data.where.
 * 
 */
module.exports.encryptColumns256 = async (data, columns) => {
  if (!data || isEmptyArray(data)) return;

  const uniqueColumns = [...new Set(columns)]; // removing duplicate columns from the list.
  const dataArray = Array.isArray(data) ? data : [data];

  return Promise.all(dataArray.map(async item => {
    return await Promise.all(uniqueColumns.map(async column => {
      if (!isNil(item[column])) {
        item[column] = (await encrypt256(item[column])).encryptedData;
      }
      return null;
    }));
  }));
};

/**
 * 
 * @param {Object | Object[]} data 
 * @param {string[]} columns 
 * @returns {Promise}
 * can be used to decrypt the SQL query results.
 * applicable for both single object and array of objects (findOne and findAll method).
 * @example 
 * address.afterFind(async data => await decryptColumns256(data, columns));
 */
module.exports.decryptColumns256 = async (data, columns) => {
  if (!data || isEmptyArray(data)) return;

  const uniqueColumns = [...new Set(columns)]; // removing duplicate columns from the list.
  const dataArray = Array.isArray(data) ? data : [data];

  return Promise.all(dataArray.map(async item => {
    return await Promise.all(uniqueColumns.map(async column => {
      if (item[column]) {
        item[column] = (await decrypt256(item[column])).decryptedData;
      }
      return null;
    }));
  }));
};