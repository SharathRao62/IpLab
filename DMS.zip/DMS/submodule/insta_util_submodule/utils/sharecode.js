const getSixDigitNumericOtp = (lead_id) => {
    return 100000 + Math.floor(Math.random() * 900000);
}

const getSixDigitAlphanumericTransactionId = () => {
    let result = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for ( let i = 0; i < 6; i++ ) {
        result += characters.charAt(Math.floor(Math.random()*characters.length));
    }
    return result;
}

module.exports = { getSixDigitNumericOtp, getSixDigitAlphanumericTransactionId };
