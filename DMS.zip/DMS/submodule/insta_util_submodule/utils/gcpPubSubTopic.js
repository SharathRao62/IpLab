/* eslint-disable prefer-promise-reject-errors */
/**
 * TODO(developer): Uncomment these variables before running the sample.
 */
// Imports the Google Cloud client library
const { PubSub } = require('@google-cloud/pubsub');
const Logger = require('./logger');
const environConfig = require('../../insta_config_submodule/config/environConfig');
// Creates a client; cache this for further use
const pubSubClient = new PubSub();

const safePublishMessage = async (data, logger, logData) => {
  const topicNameOrId = environConfig.GCP_PUB_SUB_TOPIC_ID;
  if (logData) {
    logger.debug(`publishMessage data ${data}`);
  } else {
    logger.debug(`publishMessage data`);
  }
  
  // Publishes the message as a string, e.g. "Hello, world!" or JSON.stringify(someObject)
  const dataBuffer = Buffer.from(data);

  try {
    // Configure flow control
const publisherOptions = {
  batching: {
    maxMessages: 100,  // Maximum number of messages in a single batch // 500 - 1000 for high traffic
    maxMilliseconds: 100,  // Maximum delay before sending a batch //low latency - 10-100
  },
  flowControl: {
    maxOutstandingMessages: 1000,  // Max number of messages sent without confirmation // 1000 for more throughput
    maxOutstandingBytes: 5 * 1024 * 1024,  // Max size of messages sent without confirmation //1MB
  }
};
    return pubSubClient
      .topic(topicNameOrId,publisherOptions)
      .publishMessage({ data: dataBuffer }).then((messageId) => {
        logger.debug(`Message ${messageId} published.`);
        return Promise.resolve(true);
      }).catch((error) => {
        logger.error(`error ${error}`)
        return Promise.reject(error);
      });
  } catch (error) {
    logger.error(`Received error while publishing: ${error.message}`);
    return Promise.reject(true);
  }
};


module.exports.publishMessage = async (data, logger, logData = true) => {
  logger.info(`entering to publish message ${logData} `)
  const maxRetries = 5;
  let attempt = 0;

  while (attempt < maxRetries) {
    try {
      const res = await safePublishMessage(data, logger, logData);
      return res;  // Message published successfully
    } catch (error) {
      attempt++;
      if (error.code === 'MaxOutstandingElementCountReachedException' || 
          error.code === 'MaxOutstandingRequestBytesReachedException') {
        logger.info(`Flow control limit reached, retrying... (${attempt})`);
        await delay(1000 * attempt);  // Exponential backoff
      } else {
        throw error;  // Handle other errors
      }
    }
  }
  logger.info('Failed to publish message after retries.');
}
