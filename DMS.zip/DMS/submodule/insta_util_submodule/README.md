# ao_insta_util


## Overview
This microservice is used as a common submodule for all the other microservice. It contains commonly used logics and utils by all the micros. 

It has 4 apis 
Handle Error Code: This api fetched the error code from the error_code table with Error message given as an input. Obtained code is given to front end

Internal Api Status Flag : stores the flag status

# Event Tracker:
add the entries to the lead_attribute table.
PAYLOAD: 
{
 eventCode
 value
 addToOtherTable
 mob
 lead
}

Eg: 

const updateFreezeCodeToEvent = await eventTrackerLog.addEvent('ISFREEZECODEENABLED', '1', '', '', leadId);


RESPONSE: {
 200  (SUCCESS)
 500  (INTERNAL ERROR)
}

NOTE: eventCode sent must be present in master_event_code table. Else it will throw an error of validation failed with INTERNAL ERROR of 500.

# INTERNAL API STATUS FLAG: 
add the entries to the internal_api_status table.

PAYLOAD: 
{
 api_name: 'ISSAVINGS_EXIST_FLAG',
 lead_id: '59wymb5tkh33bng8',
 mobile_no: '9999999990',
 flag: 1,
}

RESPONSE: 
{
 200  (SUCCESS)
 500  (INTERNAL ERROR) 
}

Eg:     
const apiStatusFlagData = {
 api_name: 'ISSAVINGS_EXIST_FLAG',
 lead_id: '59wymb5tkh33bng8',
 mobile_no: '9999999990',
 flag: 1,
}          
updateFlagResult = await internalApiStatusFlagBusiness.addInternalApiStatusFlagBusiness(apiStatusFlagData);


RESPONSE: {
 200  (SUCCESS)
 500  (INTERNAL ERROR)
}

NOTE: api_name sent must be present in master_event_code table. Else it will throw an error for validation failed with INTERNAL ERROR of 500.

# API STATUS FLAG: 
add the entries to the external_api_status table.

PAYLOAD: 
{
 api_name: string,
 lead_id: string,
 mobile_no: string,
 flag: integer,
}

RESPONSE: 
{
 200  (SUCCESS)
 500  (INTERNAL ERROR) 
}

Eg:     
const apiStatusFlagData = {
 api_name: 'ISSAVINGS_EXIST_FLAG',
 lead_id: '59wymb5tkh33bng8',
 mobile_no: '9999999990',
 flag: 1,
}          
updateFlagResult = await internalApiStatusFlagBusiness.addInternalApiStatusFlagBusiness(apiStatusFlagData);


RESPONSE: {
 200  (SUCCESS)
 500  (INTERNAL ERROR)
}

NOTE: api_name sent must be present in master_event_code table. Else it will throw an error for validation failed with INTERNAL ERROR of 500.


## external-service:
EXTERNAL API CALL:
PAYLAOD :
{
dataInput: {
 url: string
 headers: object
isEncrypt: boolean
 },
 externalDataVal: {
     payload: object,
 },
 tableData; {
     data: object,
 }
}

Eg1: ( to call third party api)
  const extData = {
    url: config.THIRD_PARTY_URL,
    headers: {
      'content-type': 'application/json',
      apikey: configEnc.apiKey,
      ProductID: accountData.product,
      ChannelID: CONSTANTS.CHANNELID,
    },
    isEncrypt: true,
  };
const payload = {
    MobileNumber: mobileNumber,
  };

  const tableData = {
    tableName: CONSTANTS.LOG_TABLE.TABLE_NAME,
    person_id: personId,
    source: callfrom,
    lead_id: leadId
  };  

    const Response = await extService.extCall(extData, payload, tableData);

Eg2: ( to call internal api)
  const extData = {
    url: config.THIRD_PARTY_URL,
    headers: {
      'content-type': 'application/json',
    },
    isEncrypt: false,
  };
const payload = {
    MobileNumber: mobileNumber,
  };

  const tableData = ''; 
const Response = await extService.extCall(extData, payload, tableData);

## utils

# decrypt table data

PAYLOAD:
{
    data: object
}

RESPONSE:

DECRYPTED RESPONSE

Eg:
    const decData = await decryptVal.decryptTableData(queryResp[0]);

# encrypt decrypt:
It is used to encrypt/decrpyt the third party payload

PAYLOAD : {
    externaDataVal: object,
    env: string

Eg: dataEncryptDecrypt.encryptData(externalDataVal, env)

# encrypt decrypt aes256:
It is used to encrypt or decrypt 256 table data

PAYLOAD : {
data: string
}

Eg:
    const mobile_no = await datdecryptAES256.encrypt256(tableValue.mobile_no);

# feBe encryption decryption
 1. use to encrypt/ decrypt the data from the frontend
 2. Used in index file where the apis are called from fe


# fetch error code:
It has 2 functions
1. sendErrorCode:

Payload: {
errorcode: string,
leadId: string,
personId: string
}
2. fetchErrorCode: It is called internally from sendErrorCode method

# Handle error Code:
It is used to get the error code from the master error code table using the error message passed
Payload: {
errorcode: string,
leadId: string,
personId: string
}

# Isg Security

It is used to Block server from then unknown source which is not whitelisted. It is used in index.js file

Constants, Models and service file: Used for above mentioned APis
Utils consists  commonly used logic by all micros

### Running the server

There is no pipeline present for this micro. Any changes present has to be added and pushed 

In the parents microservice changes in the submodules can be reflected using below command

sh ../checkout/checkout development


## Method errorFormat
This method is used to format the error while displaying in logger.
This reduces effort to check if error thrown was object or string and deciding whether we had to stringify or not.
This method accepts error and return error as a string.
example:
logger.error('SOMETHING WENT WRONG WHILE FETCHING CONFIGURATION DATA',`${errorFormat(error)}`);
