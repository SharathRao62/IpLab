const fs = require('fs').promises;
const path = require('path');

const submodulePackageJsonPath = path.resolve(__dirname, 'package.json');
const mainPackageJsonPath = path.resolve(__dirname, '../../package.json');

async function updateMainPackageJson() {
  try {
    const submoduleData = await fs.readFile(submodulePackageJsonPath, 'utf8');
    const submodulePackageJson = JSON.parse(submoduleData);
    const submoduleDependencies = submodulePackageJson.dependencies || {};

    const mainData = await fs.readFile(mainPackageJsonPath, 'utf8');
    const mainPackageJson = JSON.parse(mainData);
    mainPackageJson.dependencies = mainPackageJson.dependencies || {};

    for (const [dep, version] of Object.entries(submoduleDependencies)) {
      mainPackageJson.dependencies[dep] = version;
    }

    await fs.writeFile(mainPackageJsonPath, JSON.stringify(mainPackageJson, null, 2));
    console.log('Updated main package.json with submodule dependencies:', submoduleDependencies);
  } catch (err) {
    console.error(`Error: ${err}`);
    process.exit(1);
  }
}

updateMainPackageJson();
