const isTig = process.env.TIG || false;
const { errorFormat } = require("../../insta_util_submodule/utils/errorFormat");
const Logger = require('../../insta_util_submodule/utils/logger');
const dbconfigenv = require('../../insta_config_submodule/config/econfig/dbconfig.json'); 
const logger = new Logger();
// logger.info(`isTig tigconfig | ${JSON.stringify(isTig)}`);
// console.log('Line 7 tig file',isTig);

let config = {
    qa: {
      readWrite: {
        database: 'savings_account_qa_db',
        username: 'root',
        password: 'buyqa@adminPass347',
        host: '127.0.0.1',
        port: '3306',
        dialect: 'mysql',
      },
      replica: {
        database: 'savings_account_qa_db',
        username: 'root',
        password: 'buyqa@adminPass347',
        host: '127.0.0.1',
        port: '3307',
        dialect: 'mysql',
      },
      redis:{
        REDIS_HOST:'',
        REDIS_PORT:'',
        REDIS_PASSWORD:''
      }
    },
    development: {
      readWrite: {
        database: 'dms', // **********CHANGEEEEEEEEEEEEEEEEEEEEE
        username: 'Sharath',
        password: 'password',
        host: '127.0.0.1',
        port: '3306',
        dialect: 'mysql',
      },
      replica: {
        database: 'icici_bank_database',
        username: 'admin',
        password: 'icici_admin@123',
        host: '127.0.0.1',
        port: '3307',
        dialect: 'mysql',
      },
      redis:{
        REDIS_HOST:'10.130.65.3',
        REDIS_PORT:'6379',
        REDIS_PASSWORD:'6e1866ff-9bbd-487a-8b39-95f85f96ad4c'
      }
    },
    staging: {
      readWrite: {
        database: 'savings_account_staging_db',
        username: 'admin',
        password: 'Gcpdbpoctemp',
        host: '10.229.88.27',
        port: '3307',
        dialect: 'mysql',
      },
      replica: {
        database: 'savings_account_staging_db',
        username: 'icici_user_23',
        password: '&FN&k7*VZyuZ+=Y',
        host: '127.0.0.1',
        port: '3308',
        dialect: 'mysql',
      },
      redis:{
        REDIS_HOST:'10.174.225.4',
        REDIS_PORT:'6379',
        REDIS_PASSWORD:'a97ab010-f9dc-4dd5-8fc0-5bd7e2816e9e'
      }
    },
    pre_prod: {
      readWrite: {
        database: 'new_icici_bank_db',
        username: 'root',
        password: 'admin',
        host: 'localhost',
        dialect: 'mysql',
      },
      replica: {
        database: 'new_icici_bank_db',
        username: 'root',
        password: 'admin',
        host: 'localhost',
        dialect: 'mysql',
      },
    },
    production: {
      readWrite: {
        database: 'new_icici_bank_db',
        username: 'root',
        password: 'admin',
        host: 'localhost',
        dialect: 'mysql',
      },
      replica: {
        database: 'new_icici_bank_db',
        username: 'root',
        password: 'admin',
        host: 'localhost',
        dialect: 'mysql',
      },
    },
  };


  const environment = process.env.NODE_ENV || "development";
  if ((isTig === true || isTig === 'true')) {
   config = JSON.parse(process.env.DB_CONFIG);
   logger.info(`dbconfig Data ENVFILE | ${errorFormat(JSON.stringify(config))}`);
  } else {
    config = config[environment];
    // logger.info(`dbconfig Data ENVFILE ELSE | ${errorFormat(JSON.stringify(config))}`);
 }

  module.exports = config;

