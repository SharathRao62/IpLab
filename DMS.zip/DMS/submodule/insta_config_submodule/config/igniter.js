const isTig = process.env.TIG || false;
const fs = require("fs");
const path = require("path");
const { errorFormat } = require("../../insta_util_submodule/utils/errorFormat");
const Logger = require("../../insta_util_submodule/utils/logger");
const dbConfig = process.env.SECRET_CONFIG || null;
const name = process.env.SECRET_NAME || null;

const writeEnv = async () => {
  const logger = new Logger("WriteFile | TIG");
  logger.info('Line 10 Writefile of Igniter');
  const filePath = path.join(__dirname, "./econfig/environconfig.json");
  logger.info(`filePath | ${errorFormat(filePath)}`);
  const dataEnv = await igniterManager(false);
  process.env.ENV_CONFIG = JSON.stringify(dataEnv);

};

const writeEnvdb = async () => {
  const logger = new Logger("WriteFile DB | TIG");
  const filePath = path.join(__dirname, "./econfig/dbconfig.json");
  logger.info(`filePath DB  | ${errorFormat(filePath)}`);
  const dataEnv = await igniterManager(true);
  process.env.DB_CONFIG = JSON.stringify(dataEnv);

  
};

async function igniterManager(config) {
  const logger = new Logger("igniterManager |");
  try {
    logger.info(dbConfig, "check me")
    logger.info(`Name | ${errorFormat(name)}`);

    let configName = null;
    if (config) {
      configName = dbConfig;
    } else {
      configName = name;
    }

    if (isTig == true || isTig == "true") {
      const {
        SecretManagerServiceClient,
      } = require("@google-cloud/secret-manager");
     
    const client = new SecretManagerServiceClient();
    
    if (client) {
      logger.info(`fetching data`)  
      const [version] = await client.accessSecretVersion({
          name: configName,
        });
        logger.info(`Entry into the function`);
      if (version && version.payload) {
        const payload = version.payload;
        if (payload.data) {
          const data = payload.data;
          const bufferOriginal = Buffer.from(data);
          const envjson = JSON.parse(bufferOriginal.toString("utf8"));
          return envjson;
        } else {
          logger.info("Payload data is null or undefined");
          return null;
        }
      } else {
        logger.info("First version Payload is null or undefined");
        return null;
      }
    } else {
      logger.info("Client is null, accessSecretVersion cannot be called");
      return null;
    }
  }
  } catch (error) {
    logger.error(`Catch Error Igniter | ${errorFormat(error)}`);
    throw error;
  }
}

module.exports = {
  igniterManager,
  writeEnv,
  writeEnvdb,
};
