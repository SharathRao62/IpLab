const redis = require("redis");
const isTig = process.env.TIG || false
const Logger = require('../insta_util_submodule/utils/logger');
const logger = new Logger('redisconfig');
const configFile = ( isTig == true || isTig == 'true' ) ? require('../insta_config_submodule/config/tigConfigfile.js'): require('../insta_config_submodule/config/configfile.js');
const environment = process.env.NODE_ENV || 'development';
let redisHost = configFile[environment].redis.REDIS_HOST;
let redisPort = configFile[environment].redis.REDIS_PORT;
let redisPassword = configFile[environment].redis.REDIS_PASSWORD;

const client = redis.createClient({
    socket: {
        port: redisPort,
        host: redisHost,
        reconnectStrategy() {
            logger.info(`reconnectStrategy | ${redisHost}:${redisPort}`);
            return 5000;
        }
    },
    password: redisPassword
});
client.on('error', err => console.error('client err', err));
(async () => {
    // Connect to redis server
    await client.connect().then(() => {
        logger.info('redis connection success')
    }).catch(error => {
        logger.error(`redis connection error | ${error} | ${JSON.stringify(error)}`)
    });
})();

client.on("connect", function () {
    logger.info("Connection Successful!!");
});

// Close the connection when there is an interrupt sent from keyboard
process.on('SIGINT', () => {
    client.quit();
    logger.info('redis client quit');
    process.exit(0);
});

module.exports = {
    client,
}
