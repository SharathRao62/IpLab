# insta config submodule

## Overview
This microservice contains db setup file, environment file with sensitive information, all the encrypted file. 

It Includes API Keys of all environment, Encrypt, Decrypt Url and keys, Email details , karza key. 

PS: Always empty the environment file while checking in and push the encrypted files

### Running the server

There is no pipeline present for this micro. Any changes present has to be added and pushed 

In the parents microservice changes in the submodules can be reflected using below command

sh ../checkout/checkout development