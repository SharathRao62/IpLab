const Sequelize = require('sequelize');
const Logger = require('../insta_util_submodule/utils/logger');
// const CONSTANTS = require('../../constants/constant');
const DBCONSTANTS = require('../insta_constants_submodule/constants/dbConstant');
const CONSTANTS = require('../insta_constants_submodule/constants/constant');

const logger = new Logger();
const environment = process.env.NODE_ENV || 'development';

let dbConfig;
const dbData = process.env.DB_DATA || 'readWrite';

// Function to determine pool size based on load level
const getPoolConfig = (loadLevel) => {
  const poolConfig = DBCONSTANTS.POOL_CONFIG;

  switch (loadLevel) {
    case 'too-low':
      return { max: poolConfig.TOO_LOW.MAX, min: poolConfig.TOO_LOW.MIN };
    case 'low':
      return { max: poolConfig.LOW.MAX, min: poolConfig.LOW.MIN };
    case 'medium':
      return { max: poolConfig.MEDIUM.MAX, min: poolConfig.MEDIUM.MIN };
    case 'high':
    default:
      return { max: poolConfig.HIGH.MAX, min: poolConfig.HIGH.MIN };
  }
};

const readWriteFunction = (dbConfigValue, loadLevel = 'high') => {
  switch (environment) {
    case 'development':
      if (dbData === 'replica') {
        dbConfig = dbConfigValue.replica;
      } else {
        dbConfig = dbConfigValue.readWrite;
      }
      break;
    case 'qa':
      if (dbData === 'replica') {
        dbConfig = dbConfigValue.replica;
      } else {
        dbConfig = dbConfigValue.readWrite;
      }
      break;
    case 'staging':
      if (dbData === 'replica') {
        dbConfig = dbConfigValue.replica;
      } else {
        dbConfig = dbConfigValue.readWrite;
      }
      break;
    default:
      if (dbData === 'replica') {
        dbConfig = dbConfigValue.replica;
      } else {
        dbConfig = dbConfigValue.readWrite;
      }
      break;
  }

  const poolConfig = getPoolConfig(loadLevel);

  const sequelize = new Sequelize(
    dbConfig.database,
    dbConfig.username,
    dbConfig.password,
    {
      logging: (msg) => logger.debug(msg),
      host: dbConfig.host,
      port: dbConfig.port,
      dialect: dbConfig.dialect,
      useUTC: false,
      timezone: '+05:30',
      pool: {
        max: poolConfig.max || 100,
        min: poolConfig.min || 20,
        acquire: DBCONSTANTS.ACQUIRE || 60000, // 1 Minute
        idle: DBCONSTANTS.IDLE || 10000, // 10 Seconds
      },
      retry: {
        max: 3,
        match: [
          /ConnectionError/,
          /SequelizeConnectionError/,
          /SequelizeConnectionRefusedError/,
          /SequelizeHostNotFoundError/,
          /SequelizeHostNotReachableError/,
          /SequelizeInvalidConnectionError/,
          /SequelizeConnectionTimedOutError/,
          /SequelizeConnectionAcquireTimeoutError/,
          /Connection terminated unexpectedly/,
        ],
      }
    },
  );

  sequelize
    .authenticate()
    .then(() => {
      logger.info('Connection has been established successfully.');
      console.log("++++++++++++++++++++++++++++++++")
      
    })
    .catch((err) => {
      logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} INDEX READ WRITE | Error occured while connecting to database ...!`);
      logger.error(err);
    });

  return sequelize;
};

module.exports = { readWriteFunction };

