const jwt = require('jsonwebtoken');
const { customAlphabet } = require('nanoid');

const secretKey = 'sdeddevew3dmkm';

// Generate a unique lead ID using nanoid
function getUniqueLeadId() {
  const generate = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 13);
  return generate();
}

// Sign JWT with a payload and optional expiration (default: 40 minutes)
const jwtSign = (payload, expiresIn = 60 * 40) => {
  return jwt.sign(payload, secretKey, { expiresIn });
};

// Verify JWT token
const jwtVerify = (token) => {
  try {
    return jwt.verify(token, secretKey);
  } catch (error) {
    console.error('JWT verification failed:', error.message);
    return null;
  }
};

// Decode JWT token (without verifying)
const jwtDecode = (token) => {
  return jwt.decode(token);
};

module.exports = { jwtSign, jwtVerify, jwtDecode, getUniqueLeadId };




// const jwt = require('jsonwebtoken');
// const nanoid = require('nanoid');

// const secretKey = 'sdeddevew3dmkm';

// function getUniqueLeadId() {
//   const { customAlphabet } = nanoid;
//   const generate = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 13);
//   return generate();
// }


// const jwtSign = (payload, expiresIn = 60 * 40) => {
//   return jwt.sign(payload, secretKey, { expiresIn });
// };


// const jwtVerify = (payload) => {
//   console.log('oooooooooo');
//   return jwt.verify(payload, secretKey);
// };

// const jwtDecode = (payload) => {
//   return jwt.decode(payload)
// }


// const payload = {
//   lead_id: getUniqueLeadId(),
//   role: 'admin'
// };

// // Generate token
// // const token = jwtSign(payload);

// // Print token
// // console.log("Generated JWT Token:\n", token);

// // Optionally decode or verify
// // const decoded = jwtDecode(token);
// // console.log("\n Decoded Token:\n", decoded);

// // const verified = jwtVerify(token);
// // console.log("\n Verified Token:\n", verified);

// module.exports = { jwtSign, jwtVerify, jwtDecode };
