const Logger = require('../utils/logger');
const jwt = require('../utils/jwt');

// const METHOD = { VERIFY_TOKEN: 'VERIFY_TOKEN' };
// const STATUS_CODE = { FORBIDDEN: 403, JWT_TOKEN_EXPIRED: 401 };
// const SUCCESS_MESSAGE = { VERIFY_TOKEN: 'Token verified successfully' };
// const ERROR_CODE = { API_INTERNAL: 'API_INTERNAL_ERROR' };
// const ERROR_MESSAGE = { VERIFY_TOKEN: 'Token verification failed' };
// const TOKEN_EXPIRED_ERROR = 'TokenExpiredError';

// const verifyToken = async (req, res, next) => {
//   const logger = new Logger(METHOD.VERIFY_TOKEN, 'AUTHORIZATION', JSON.stringify(req.headers.authorization));

//   try {
//     const { authorization } = req.headers;
//     logger.info(`REQUEST HEADER: ${JSON.stringify(req.headers)}`);

//     if (!authorization || !authorization.startsWith('Bearer ')) {
//       logger.info('INVALID HEADER: Missing or malformed Authorization');
//       return res.status(STATUS_CODE.FORBIDDEN).send({ error: 'Invalid authorization header' });
//     }

//     const token = authorization.split(' ')[1];
//     const decoded = jwt.jwtVerify(token);

//     if (!decoded || !decoded.lead_id) {
//       logger.info('INVALID USER: Token payload missing lead_id');
//       return res.status(STATUS_CODE.FORBIDDEN).send({ error: 'Invalid token' });
//     }

//     // ✅ Attach verified user data to request
//     req.body = {
//       lead_id: decoded.lead_id.toString(),
//     };

//     logger.info(SUCCESS_MESSAGE.VERIFY_TOKEN);
//     next();
//   } catch (error) {
//     logger.error(`${ERROR_CODE.API_INTERNAL} | VERIFY | ${ERROR_MESSAGE.VERIFY_TOKEN} | ${JSON.stringify(error)} | ${error.message}`);

//     if (error.name === TOKEN_EXPIRED_ERROR) {
//       return res.status(STATUS_CODE.JWT_TOKEN_EXPIRED).send({ error: 'Token expired' });
//     }

//     return res.status(STATUS_CODE.FORBIDDEN).send({ error: 'Token verification failed' });
//   }
// };

// module.exports = { verifyToken };

// const jwt = require('../utils/jwt');

// const verifyToken = async (req, res, next) => {
//   try {
//     const { authorization } = req.headers;

//     if (!authorization || !authorization.startsWith('Bearer ')) {
//       return res.status(403).send({ error: 'Invalid authorization header' });
//     }

//     const token = authorization.split(' ')[1];
//     const decoded = await jwt.jwtVerify(token); // Your JWT verify function

//     console.log("Decoded JWT:", decoded); // 👈 Debug line

//     if (!decoded || !decoded.lead_id) {
//       return res.status(403).send({ error: 'lead_id missing from token' });
//     }

//     // ✅ Attach decoded info to req.user (NOT req.body)
//     req.user = {
//       lead_id: decoded.lead_id,
//       journey_id: decoded.journey_id // If needed
//     };

//     next();
//   } catch (error) {
//     console.error("JWT Verification Error:", error); // 👈 Debug line
//     return res.status(401).send({ error: 'Token verification failed' });
//   }
// };

// module.exports = { verifyToken };
// ;

// const Logger = require('../utils/logger');
// const jwt = require('../utils/jwt');

const METHOD = { VERIFY_TOKEN: 'VERIFY_TOKEN' };
const STATUS_CODE = { FORBIDDEN: 403, JWT_TOKEN_EXPIRED: 401 };
const SUCCESS_MESSAGE = { VERIFY_TOKEN: 'Token verified successfully' };
const ERROR_CODE = { API_INTERNAL: 'API_INTERNAL_ERROR' };
const ERROR_MESSAGE = { VERIFY_TOKEN: 'Token verification failed' };
const TOKEN_EXPIRED_ERROR = 'TokenExpiredError';

const verifyToken = async (req, res, next) => {
  const logger = new Logger(METHOD.VERIFY_TOKEN, 'AUTHORIZATION', JSON.stringify(req.headers.authorization));

  try {
    const { authorization } = req.headers;
    logger.info(`REQUEST HEADER: ${JSON.stringify(req.headers)}`);

    if (!authorization || !authorization.startsWith('Bearer ')) {
      logger.info('INVALID HEADER: Missing or malformed Authorization');
      return res.status(STATUS_CODE.FORBIDDEN).send({ error: 'Invalid authorization header' });
    }

    const token = authorization.split(' ')[1];
    const decoded = await jwt.jwtVerify(token);

    if (!decoded || !decoded.lead_id) {
      logger.info('INVALID USER: Token payload missing lead_id');
      return res.status(STATUS_CODE.FORBIDDEN).send({ error: 'Invalid token' });
    }

    // Attach decoded values to req.user (not req.body)
    req.user = { lead_id: decoded.lead_id };
    console.log(req.user, 'ooooooooooooooooooooooooooooooooooooooooooooooooooooo');

    logger.info(SUCCESS_MESSAGE.VERIFY_TOKEN);
    next();
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | VERIFY | ${ERROR_MESSAGE.VERIFY_TOKEN} | ${JSON.stringify(error)} | ${error.message}`);
    if (error.name === TOKEN_EXPIRED_ERROR) {
      return res.status(STATUS_CODE.JWT_TOKEN_EXPIRED).send({ error: 'Token expired' });
    }
    return res.status(STATUS_CODE.FORBIDDEN).send({ error: 'Token verification failed' });
  }
};

module.exports = { verifyToken };
