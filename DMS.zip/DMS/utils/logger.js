const bunyan = require("bunyan");
const properties = require("../package.json");
const env = process.env.NODE_ENV;
const bformat = require("bunyan-format");
const moment = require("moment-timezone");

function getISTTime() {
    return moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
}

const formatOut = bformat({
    outputMode: "long",
    color: true,
    stream: process.stdout,
});

const envCondition = ["PRODUCTION", "production", "pre_prod", "prod-beta"].includes(env);

// Logs Condition
const streamConditions = envCondition
    ? [{ stream: process.stdout, level: "info" }]
    : [{ stream: formatOut, level: "debug" }];

const logger = bunyan.createLogger({
    name: "dms-logging <DMS>",
    streams: streamConditions,
});

class Logger {
    constructor(fnName, leadId, trace) {
        this.updateInfo(fnName, leadId, trace);
    }

    updateInfo(fnName, leadId, trace) {
        this.fnName = fnName;
        this.leadId = leadId;
        this.trace = trace;
        if (fnName || leadId || trace) {
            this.info('BEGIN');
        }
    }

    formatMessage(level, msg) {
        const timestamp = getISTTime();
        let logMsg = `[${timestamp}] Micro : ${properties.name} |`;

        if (this.fnName) logMsg += ` Method: ${this.fnName} |`;
        if (this.leadId) logMsg += ` LeadID: ${this.leadId} |`;
        if (this.trace) logMsg += ` Trace: ${this.trace} |`;

        return `${logMsg} ${msg}`;
    }

    info(...msg) {
        msg[0] = this.formatMessage("INFO", msg[0]);
        logger.info(...msg);
    }

    debug(...msg) {
        msg[0] = this.formatMessage("DEBUG", msg[0]);
        logger.debug(...msg);
    }

    error(...msg) {
        msg[0] = this.formatMessage("ERROR", msg[0]);
        logger.error(...msg);
    }
}

module.exports = Logger;
