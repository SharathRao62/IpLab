const nodemailer = require('nodemailer');
const { EMAIL } = require('../config/environConfig');

// const sendRegistrationEmail = (userName, email, reqId, deviceName, logger) => {
//     if (!email) {
//         logger.error("No email provided for sending registration email.");
//         return;
//     }

//     var transporter = nodemailer.createTransport({
//         host: "smtp.gmail.com",
//         port: 587,
//         secure: false,
//         auth: {
//             email: EMAIL.EMAIL_USER,
//             password: EMAIL.EMAIL_PASSWORD
//         },
//         tls: {
//             rejectUnauthorized: false
//         }
//     });

//     const mailOptions = {
//         from: EMAIL.EMAIL_USER,
//         to: email,
//         subject: "Device Request Confirmation",
//         text: `Dear ${userName},\n\nYour device request for :${deviceName} has been successfully received. Your Request Id is: ${reqId}.\n\nWe will process your request and update you shortly.\n\nThank you for choosing our service!\n\nBest regards,\nMphasis`
//     };


//     // transporter.sendMail(mailOptions, (error, info) => {
//     //     if (error) {
//     //         logger.error(`Email sending failed: ${error.message}`);
//     //     } else {
//     //         logger.info(`Email sent successfully: ${info.response}`);
//     //     }
//     // });

//     transporter.sendMail(mailOptions, async (error, info) => {
//         if (error) {
//             logger.error(`Email sending failed: ${error.message}`);
//         } else {
//             logger.info(`Email sent successfully: ${info.response}`);
//             if (info.response && info.response.includes("OK")) {                    // Gmail usually returns '250' or 'OK'
//                 try {
//                     console.log('ooooooooooooooooooooo');
//                 } catch (error) {
//                     logger.error(`Failed to update employee record: ${error.message}`);
//                 }
//             }
//         }
//     });
// };

// module.exports = { sendRegistrationEmail }


const sendRegistrationEmail = (userName, email, reqId, deviceName, logger) => {
    if (!email) {
        logger.error("No email provided for sending registration email.");
        return;
    }

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: EMAIL.EMAIL_USER,
            pass: EMAIL.EMAIL_PASSWORD
        }
    });

    const mailOptions = {
        from: EMAIL.EMAIL_USER,
        to: email,
        subject: "Device Request Confirmation",
        text: `Dear ${userName},\n\nYour device request for ${deviceName} has been successfully received. Your Request Id is: ${reqId}.\n\nWe will process your request and update you shortly.\n\nThank you for choosing our service!\n\nBest regards,\nMphasis`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            logger.error(`Email sending failed: ${error.message}`);
        } else {
            logger.info(`Email sent successfully: ${info.response}`);
        }
    });
};

module.exports = { sendRegistrationEmail };
