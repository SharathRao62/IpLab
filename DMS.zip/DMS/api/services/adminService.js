const device = require('../../models/device'); // Make sure it's "devices" if that's your model name
const user_requested_device = require('../../models/user_requested_device'); // Make sure it's "devices" if that's your model name
const device = require('../../models/device'); // Make sure it's "devices" if that's your model name
const Sequelize = require('sequelize');
const { Op } = Sequelize;

const deleteDevice = async (condition, logger) => {
    try {
        logger.info(`deleteDevice: condition = ${JSON.stringify(condition)}`);

        // Optional: Fetch the device before deleting (for logging or return)
        const deviceData = await device.findOne({
            where: condition,
            raw: true,
        });

        if (!deviceData) {
            logger.warn(`Device not found for condition: ${JSON.stringify(condition)}`);
            return null;
        }

        // Delete the device
        await device.destroy({
            where: condition,
        });

        logger.info(`Device deleted: ${JSON.stringify(deviceData)}`);
        return deviceData; // Return deleted device info if needed

    } catch (error) {
        logger.error(`deleteDevice | error | ${error}`);
        throw error;
    }
};



const getAllDevices = (condition, columns, logger) => {
    logger.info(`getAllDevices: ${JSON.stringify(condition)}`);
    return device.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getAllDevices | error | ${error}`);
    });
};
module.exports = {
    deleteDevice,
    getAllDevices,

}