const db = require('../../models');
const auth = db['auth'];

const authData = (authToken, logger) => {
    return auth.create(authToken)
        .then((newRequest) => {
            return newRequest;
        }).catch((error) => {
            logger.error(`authData | error | ${error}`);
        });
};

module.exports = { authData }