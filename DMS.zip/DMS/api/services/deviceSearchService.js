const device = require('../../models/device'); // Make sure it's "devices" if that's your model name
const user_requested_device = require('../../models/user_requested_device'); // Make sure it's "devices" if that's your model name
const Sequelize = require('sequelize');
const { Op } = Sequelize;
// const getDeviceData = (condition, columns, logger) => {
//     logger.info(`getDeviceData: ${JSON.stringify(condition)}`);    // Log the condition properly
//     return device.findAll({
//         attributes: columns,
//         where: condition,
//         raw: true,
//     }).catch((error) => {
//         logger.error(`getDeviceData | error | ${error}`);
//     });
// };


const getDeviceData = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);
    const searchConditions = columns
        .filter(column => typeof column === 'string') // Safety check
        .map(column => ({
            [column]: { [Op.like]: `%${condition}%` }
        }));

    return device.findAll({
        attributes: columns,
        where: {
            [Op.or]: searchConditions
        },
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
        return []; // Ensure it doesn't break if there's an error
    });
};


const getDeviceDetails = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);
    return user_requested_device.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
    });
};


const updateDeviceService = (condition, updateData, logger) => {
    return user_requested_device.update(updateData,
        {
            where: condition,
            individualHooks: true,
        }
    ).catch((error) => {
        logger.error(`updateDeviceService | error | ${error}`);
    });
};


const createDeviceService = (payload, logger) => {
    return user_requested_device.create(payload)
        .then((newRequest) => {
            return newRequest;
        }).catch((error) => {
            logger.error(`createDeviceService | error | ${error}`);
        });
};




module.exports = {
    getDeviceData,
    getDeviceDetails,
    updateDeviceService,
    createDeviceService,
}