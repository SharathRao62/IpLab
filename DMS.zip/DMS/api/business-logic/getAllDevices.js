const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');

const getAllDevices = require('../services/adminService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');

const Logger = require('../../utils/logger');

module.exports.getUserDetail = async (req) => {
    const logger = new Logger(`Product: DMS | Method: getUserDetail`);

    try {
        logger.info(`Entering ${BUSINESS_LOGIC_METHOD} | METHOD: getUserDetail | ${JSON.stringify(req)}`);

        const userData = await getAllDevices.getAllDevices(logger);
        logger.info(`Fetched all devices: ${JSON.stringify(userData)}`);

        return {
            status: STATUS_CODE.SUCCESS,
            message: 'User Data Updated Successfully',
            data: userData,
        };

    }
    catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.GET_USER_DETAILS_API_FAILED,
        };
    }
};