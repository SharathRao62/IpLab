const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const adminService = require('../services/adminService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const Sequelize = require('sequelize');
const { Device } = require('../../models'); // Sequelize model

module.exports.deviceExtend = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceExtend`);
    logger.info(`${ENTERING_TO} ${BUSINESS_LOGIC_METHOD.deviceExtend}`);

    try {
        const { deviceId, modelNo } = req.body;

        // Check if at least one identifier is provided
        if (!deviceId && !modelNo) {
            return {
                status: STATUS_CODE.BAD_REQUEST,
                message: "Either deviceId or modelNo must be provided.",
                error: ERR_MESSAGE.INVALID_INPUT
            };
        }

        // Build condition for deletion
        const condition = deviceId
            ? { id: deviceId }
            : { model_no: modelNo };

        // Delete device
        const userData = await adminService.deleteDevice(condition, logger);
        logger.info(`Deleted device data: ${JSON.stringify(userData)}`);


        if (deletedCount === 0) {
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: "Device not found.",
                error: ERR_MESSAGE.DEVICE_NOT_FOUND
            };
        }

        return {
            status: STATUS_CODE.SUCCESS,
            message: "Device deleted successfully."
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceExtend | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};
