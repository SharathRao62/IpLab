const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE, UNAUTHORIZED } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const loginService = require('../services/loginService');
const authDataService = require('../services/authService');


const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const bcrypt = require('bcrypt');
const { jwtSign, getUniqueLeadId, jwtDecode } = require('../../utils/jwt');


module.exports.registrationUser = async (req) => {
    const logger = new Logger(`Product: EMS | Method: registrationUser`);

    try {
        logger.info(` ${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_LOGIN} | request |  ${JSON.stringify(req)}`);
        // console.log(req.body.lead_id, 'oooooooooooooo');

        const condition = { email: req.email };

        // Check if the email is already in use
        let emailData = await loginService.userRegistration(condition, ['email'], logger);
        logger.info(`emailData | ${JSON.stringify(emailData)}`);

        if (emailData && emailData.email === req.email) {
            return {
                status: STATUS_CODE.CONFLICT,
                message: 'Email already used',
            };
        }

        let hashedPassword;
        if (req.password) {
            const saltRounds = 10;
            hashedPassword = await bcrypt.hash(req.password, saltRounds);
        }

        let key = {
            email: req.email,
            password: hashedPassword
        };

        const payload = {
            lead_id: getUniqueLeadId(),
            // role: req.role,
        };

        const token = jwtSign(payload);

        const tokenDecode = jwtDecode(token)
        console.log(tokenDecode, 'fffffffffffffff');

        let authToken = {
            auth: token,
            lead_id: tokenDecode.lead_id
        }

        let authData = await authDataService.authData(authToken, logger);
        logger.info(`authData | ${JSON.stringify(authData)}`);

        let employeeData = await loginService.registerUser(key, logger);
        logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

        return {
            status: STATUS_CODE.SUCCESS,
            message: 'User Registration Successfully',
            data: token
        };
    } catch (error) {
        // Catch and log any errors
        logger.error(`${ERROR_CODE.API_INTERNAL} | userLogin | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.USER_LOGIN_API_FAILED,
        };
    }
};
