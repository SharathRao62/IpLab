const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const deviceSearchService = require('../services/deviceSearchService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const Sequelize = require('sequelize');

module.exports.deviceSearch = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceSearch`);

    try {
        
        logger.info(` ${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} | METHOD : deviceSearch | ${JSON.stringify(req)}`);

        const condition = req.search_key;

        // Construct condition for searching either make_oem or model_number
        if (condition.length < 3) {
            return {
                status: STATUS_CODE.BAD_REQUEST,
                message: "Search key must be at least 3 characters.",
            };
        }

        let deviceData = await deviceSearchService.getDeviceData(condition, ['make_oem', 'model_number', 'global_rnd_no', 'category'], logger);
        deviceData = deviceData.map(device => ({
            device_name: device.make_oem,
            model_number: device.model_number,
            global_rnd_no: device.global_rnd_no,
            category: device.category
        }));
        logger.info(`deviceData | ${JSON.stringify(deviceData)}`);

        if (!deviceData || deviceData.length === 0) {
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: "No devices found",
                // data: []
            };
        }

        return {
            status: STATUS_CODE.SUCCESS,
            message: "Device Found Successful",
            data: deviceData
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceSearch | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.DEVICE_SEARCH_API_FAILED
        };
    }
};
