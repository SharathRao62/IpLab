const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const deviceSearchService = require('../services/deviceSearchService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const Sequelize = require('sequelize');



module.exports.deviceExtend = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceExtend`);

    try {
        logger.info(` ${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} | METHOD : deviceExtend | ${JSON.stringify(req.body)}`);

        const { rental_id, requested_extension_until } = req.body;

        // Step 1: Fetch the device and user from the DeviceRentals table
        const rental = await DeviceRentals.findOne({
            where: { rental_id, status: 'rented' },
            attributes: ['device_id', 'user_id', 'rental_end_date']
        });

        if (!rental) {
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: "Rental record not found or not rented",
                data: []
            };
        }

        // Step 2: Validate extension date
        if (new Date(requested_extension_until) <= new Date(rental.rental_end_date)) {
            return {
                status: STATUS_CODE.BAD_REQUEST,
                message: "Requested extension date must be after the current rental end date",
                data: []
            };
        }

        // Step 3: Check if the device is already booked for that period
        const conflictingRental = await DeviceRentals.findOne({
            where: {
                device_id: rental.device_id,
                status: 'rented',
                rental_start_date: { [Sequelize.Op.lte]: requested_extension_until }
            }
        });

        if (conflictingRental) {
            return {
                status: STATUS_CODE.BAD_REQUEST,
                message: "Device is already booked for the requested extension period",
                data: []
            };
        }

        // Step 4: Update rental request with the requested extension
        await DeviceRentals.update(
            { requested_extension_until, status: 'extension_pending' },
            { where: { rental_id } }
        );

        logger.info(`Device extension request submitted for rental_id: ${rental_id}`);
        return {
            status: STATUS_CODE.SUCCESS,
            message: "Device extension request submitted, awaiting admin approval",
            data: []
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceExtend | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};
