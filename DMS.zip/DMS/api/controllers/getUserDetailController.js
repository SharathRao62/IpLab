const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD,METHOD } = require('../../constants/constantLogger');
const getUserDetailBusiness = require('../business-logic/getUserDetailBusiness');
const logger = new Logger(`Product : DMS | Method : DMS_DETAILS `);
logger.info('DMS Enter')

const getUserDetail = async (req, res) => {

    const logger = new Logger('Device Details');
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.REQUEST_DEVICE} | request ${JSON.stringify(req.body)}`);

    await getUserDetailBusiness.getUserDetail
        (req.body).then(response => {
            writeJson(res, response)
        })
}
module.exports = { getUserDetail }

