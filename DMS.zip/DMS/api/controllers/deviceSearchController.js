const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const deviceSearchBusiness = require('../business-logic/deviceSearchBusiness');
const utils = require("../../submodule/insta_util_submodule/utils/writer");

// const deviceSearch = async (req, res) => {
//     const logger = new Logger();

//     logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.DEVICE_SEARCH} | lead_id: ${req.user.lead_id} | request: ${JSON.stringify(req.body)}`);
//     console.log(req.user, 'oooooooooooooo');

//     try {
//         const response = await deviceSearchBusiness.deviceSearch(req.body);
//         writeJson(res, response);
//     } catch (err) {
//         logger.error(`DEVICE_SEARCH_FAILED: ${err}`);
//         res.status(500).send({ error: "Internal server error" });
//     }
// };


// const deviceSearch = async (req, res) => {
//     const leadId = req.user?.lead_id;

//     if (!leadId) {
//         return res.status(400).send({ error: 'lead_id missing from token' });
//     }

//     const response = await deviceSearchBusiness.deviceSearch(req.body, { leadId });
//     res.json(response);
// };


// const deviceSearch = async (req, res) => {
//     const logger = new Logger();
//     logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.DEVICE_SEARCH} | request ${JSON.stringify(req.body)}`);

//     // ✅ Use req.user.lead_id (not req.body.lead_id)
//     const leadId = req.user?.lead_id;
//     if (!leadId) {
//         return res.status(403).json({ error: 'Missing lead_id in verified token' });
//     }

//     try {
//         const response = await deviceSearchBusiness.deviceSearch(leadId);
//         writeJson(res, response);
//     } catch (error) {
//         logger.error(`Error in deviceSearch: ${error.message}`);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };


// module.exports = { deviceSearch };

// module.exports = { deviceSearch };




module.exports.deviceSearch = (req, res) => {
  const logger = new Logger('GENERATE_MIS_HOMELOAN_REPORT', req.body?.lead_id, `${METHOD.GENERATE_MIS_HOMELOAN_REPORT}`);
  logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} | request | ${JSON.stringify(req.body)}`);

  deviceSearchBusiness.deviceSearch(req.body?.lead_id).then((result) => {
    logger.info(`lead id | ${req.body?.lead_id} | success |  ${JSON.stringify(result)}`);
    res.status(200).json(result); // ✅ added missing response
  })
  .catch((error) => {
    logger.info(`lead id | ${req.body?.lead_id} | failed | ${JSON.stringify(error)} | ${error}`);
    logger.error(`GENERATE_MIS_HOMELOAN_REPORT_FAILED | failed | ${JSON.stringify(error)} | ${error}`);
    res.status(500).json({
      status: 500,
      message: "Internal Error",
      error: "DEVICE_SEARCH_API_FAILED",
    }); // ✅ added missing error response
  });
};
