// const jwt = require('jsonwebtoken');

// const secretKey = 'sdeddevew3dmkm';
// // const secretKey = 'd9f638abe8e9e5'


// const jwtSign = (payload, expiresIn = 60 * 40) => {
//   return jwt.sign(payload, secretKey, { expiresIn });
// };


// const jwtVerify = (payload) => {
//   // new Logger(`${ENTERING_TO} ${FILES.JWT} ${UTIL_METHOD} ${METHOD.JWT_VERIFY}`);
//   console.log('oooooooooo');

//   return jwt.verify(payload, secretKey);
// };

// // 171901 start jan 16 2023
// const jwtDecode = (payload) => {
//   return jwt.decode(payload)
// }
// // 171901 end jan 16 2023



// module.exports = { jwtSign, jwtVerify, jwtDecode };


// jwtUtil.js

const jwt = require('jsonwebtoken');

const secretKey = 'sdeddevew3dmkm'; // Replace with process.env.JWT_SECRET in real use


const jwtSign = (payload, expiresIn = 60 * 40) => {
  return jwt.sign(payload, secretKey, { expiresIn });
};


const jwtVerify = (token) => {
  return jwt.verify(token, secretKey);
};

const jwtDecode = (token) => {
  return jwt.decode(token);
};

module.exports = { jwtSign, jwtVerify, jwtDecode };
