
module.exports = (sequelize, DataTypes) => {
    const login = sequelize.define("user_login", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        email: DataTypes.STRING,
        password: DataTypes.STRING,
        createdTime: DataTypes.DATE,
        updatedTime: DataTypes.DATE,
    },
        {
            updatedAt: 'updatedTime',
            createdAt: 'createdTime',
            freezeTableName: true,
        });

    return login;
}