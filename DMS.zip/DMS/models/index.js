const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const dbValue = require('../submodule/insta_config_submodule/indexReadWriteOperation');
const dbConfigValue = require('../submodule/insta_config_submodule/config/configfile.js');

const environment = process.env.NODE_ENV || 'development';
console.log(`ENVIRONMENT | ${environment}`);
const modelFilesOfSubmodel = require('../submodule/insta_model_submodule/models/index.js');

const basename = path.basename(__filename);

let db = {};
const sequelize = dbValue.readWriteFunction(dbConfigValue);

const dbSubmodule = modelFilesOfSubmodel.indexModel();

fs.readdirSync(__dirname)
  .filter(
    (file) => file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js',
  )
  .forEach((file) => {
    // const model = sequelize.import(path.join(__dirname, file));
    const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model;
  });

dbSubmodule.forEach((file) => {
  // const model = sequelize.import(path.join(file));
  const model = require(path.join(file))(sequelize, Sequelize.DataTypes);
  db[model.name] = model;
});

Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
