
module.exports = (sequelize, DataTypes) => {
    const device = sequelize.define("device", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        item_barcode: DataTypes.STRING,
        global_rnd_no: DataTypes.STRING,
        bond_no: DataTypes.STRING,
        hp_id: DataTypes.STRING,
        serial_number: DataTypes.STRING,
        model_number: DataTypes.STRING,
        project_name: DataTypes.STRING,
        make_oem: DataTypes.STRING,
        phase: DataTypes.STRING,
        family: DataTypes.STRING,
        category: DataTypes.STRING,
        owner: DataTypes.STRING,
        owner_employee: DataTypes.STRING,
        user: DataTypes.STRING,
        received_date: DataTypes.DATE,
        status: DataTypes.STRING,
        last_tested: DataTypes.DATE,
        toner_avl: DataTypes.STRING,
        location_rack: DataTypes.STRING,
        floor: DataTypes.INTEGER,
        remarks: DataTypes.STRING,
        createdTime: DataTypes.DATE,
        updatedTime: DataTypes.DATE
    },
        {
            updatedAt: 'updatedTime',
            createdAt: 'createdTime',
            freezeTableName: true,
        });

    return device;
}