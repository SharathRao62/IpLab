
module.exports = (sequelize, DataTypes) => {
    const auth = sequelize.define("auth", {
        id: {
            primaryKey: true,
            type: DataTypes.INTEGER,
            autoIncrement: true,
        },
        lead_id: DataTypes.STRING,
        auth: DataTypes.STRING,
        createdTime: DataTypes.DATE,
        updatedTime: DataTypes.DATE
    },
        {
            updatedAt: 'updatedTime',
            createdAt: 'createdTime',
            freezeTableName: true,
        });


    return auth;
}